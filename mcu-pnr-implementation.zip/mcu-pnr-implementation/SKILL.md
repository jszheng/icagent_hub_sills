---
name: mcu-pnr-implementation
description: Run floorplanning, place and route (Innovus; ICC2 flow supported but templates not bundled), and GDS export for an MCU SoC design. Generates execution scripts from templates, invokes PnR tools, parses results, and reviews implementation risks. Use when a synthesis netlist is ready for physical implementation, or when PnR reports need interpretation.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU PnR Implementation

Use this skill to run physical implementation and review results. Covers MMMC setup, floorplan, placement, CTS, routing, filler insertion, GDS export, and QoR analysis.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify RTL or synthesis netlist. Optimization feeds back upstream. (Companion skills: `mcu-rtl-development`, `mcu-synthesis-planning`)
- Do **not** run signoff tools (STA, extraction, DRC, LVS). (Companion skill: `mcu-signoff-review`)
- Do **not** run equivalence checking. (Companion skill: `mcu-equivalence-review`)

## Good Outcome

Produce:

- MMMC view file and floorplan/PnR scripts generated from templates
- floorplanned and routed design with timing closure
- post-route netlist, DEF, SDC, and GDS
- implementation reports (timing, area, power, congestion, DRC)
- risk assessment with closure priorities

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `eda_env.json` | From EDA env setup if available | Yes |
| `doc/spec.md` | User-provided or from spec planning stage | Yes (die size, macro info) |
| Synthesis netlist | From synthesis stage | Yes |
| Synthesis SDC | From synthesis stage | Yes |
| Equivalence PASS | From equivalence stage if available | Recommended |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| MMMC view | `scripts/mmmc.view` | Generated MMMC setup |
| Floorplan script | `scripts/innovus_fp.tcl` | Generated from template |
| PnR script | `scripts/innovus_pnr.tcl` | Generated from template |
| GDS script | `scripts/innovus_gds.tcl` | Generated from template |
| Post-route netlist | `output/pnr/<design>_final.v` | Gate-level after routing |
| Post-route DEF | `output/pnr/<design>_final.def` | Physical layout |
| Post-route SDC | `output/pnr/<design>_final.sdc` | Propagated constraints |
| GDS | `output/gds/<design>.gds` | Layout for signoff |
| Reports | `rpt/pnr_timing.rpt`, `pnr_area.rpt`, `pnr_power.rpt`, etc. | PnR QoR reports |

## Input Validation

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.pnr` | Not null, one of: innovus, icc2. Bundled templates cover Innovus only; ICC2 requires user-supplied scripts | Template and command selection |
| `pdk.tech_lef` or `pdk.tech_file` | Path exists | Technology for init_design |
| `libraries.std_cell.ss.lib` | At least SS corner .lib files | MMMC setup timing |
| `libraries.std_cell.ff.lib` | At least FF corner .lib files | MMMC hold corner |
| `pdk.tlu_plus_max` or `pdk.qrc_tech_max` | Path exists (TLU+ or QRC techfile) | RC corner worst. Note: some PDKs have TLU+ syntax errors (IMPEXT-2715) — use QRC techfile as alternative |
| `pdk.tlu_plus_min` or `pdk.qrc_tech_min` | Path exists (TLU+ or QRC techfile) | RC corner best |

### From synthesis outputs

| Required | What to check | Used for |
|---|---|---|
| `output/syn/<design>_syn.v` | Exists | Design netlist for init |
| `output/syn/<design>_syn.sdc` | Exists | Constraint mode |

## Workflow

### Step 1: Generate MMMC view

Read `scripts/innovus_mmmc_template.view`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{SS_LIB_FILES}}` | eda_env.json → libraries.std_cell.ss.lib |
| `{{FF_LIB_FILES}}` | eda_env.json → libraries.std_cell.ff.lib |
| `{{RC_WORST_OPTION}}` | `-qrc_tech` if QRC techfile available (preferred); `-cap_table` for TLU+ (fallback) |
| `{{RC_TECH_MAX}}` | eda_env.json → pdk.qrc_tech_max or pdk.tlu_plus_max |
| `{{RC_BEST_OPTION}}` | Same as `{{RC_WORST_OPTION}}` |
| `{{RC_TECH_MIN}}` | eda_env.json → pdk.qrc_tech_min or pdk.tlu_plus_min |
| `{{SDC_FILES}}` | `output/syn/<design>_syn.sdc` |

Write to `scripts/mmmc.view`.

### Step 2: Generate floorplan script

Read `scripts/innovus_fp_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{LEF_FILE_LIST}}` | eda_env.json → tech_lef + cell LEF + macro LEF |
| `{{SYN_NETLIST}}` | `output/syn/<design>_syn.v` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{MMMC_FILE}}` | `scripts/mmmc.view` |
| `{{DIE_WIDTH}}` / `{{DIE_HEIGHT}}` | spec.md → die dimensions |
| `{{TAP_CELL}}`, `{{ENDCAP_LEFT}}`, `{{ENDCAP_RIGHT}}` | eda_env.json → physical_cells |
| `{{MACRO_PLACEMENT_CMDS}}` | Project-specific SRAM placement (from spec macro info) |
| `{{RING_H_LAYER}}`, `{{RING_V_LAYER}}` etc. | PDK metal stack (from tech file or user) |

Write to `scripts/innovus_fp.tcl`.

### Step 3: Execute floorplan

```
innovus -batch -files scripts/innovus_fp.tcl -log rpt/innovus_fp 2>&1 | tee rpt/innovus_fp.log
```

Check for `INNOVUS_FLOORPLAN_COMPLETE` in log. If LSF available, submit via `bsub`.

### Step 4: Generate PnR script

Read `scripts/innovus_pnr_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{DB_DIR}}` | `output/innovus` |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{FILLER_CELLS}}` | eda_env.json → physical_cells.filler |
| `{{BLACK_BOX_CTS_CMDS}}` | See "Behavioral memory and black-box CTS handling" below |
| `{{RPT_DIR}}`, `{{OUTPUT_DIR}}`, `{{PROJ_HOME}}` | Project paths |

Write to `scripts/innovus_pnr.tcl`.

### Step 5: Execute PnR

```
innovus -batch -files scripts/innovus_pnr.tcl -log rpt/innovus_pnr 2>&1 | tee rpt/innovus_pnr.log
```

Check log for these markers:

| Marker | Meaning | Action |
|---|---|---|
| `INNOVUS_CTS_COMPLETE` | CTS succeeded, clock propagated | Continue to routing |
| `INNOVUS_CTS_FAILED` | CTS failed or clock still ideal | Stop. Diagnose clock spec, black-box dont_touch, and MMMC setup. Do not proceed to routing — hold results under ideal clock are meaningless |
| `INNOVUS_PNR_COMPLETE` | Full PnR flow completed | Proceed to QoR parse |
| `INNOVUS_PNR_QOR_FAIL` | Timing not converged (setup or hold) | Netlist/DEF/SDC saved for debug but GDS not exported. Iterate optimization or roll back |

### Step 6: Parse results

Extract from reports:

| Metric | Source | Pass criteria |
|---|---|---|
| CTS status | log marker | `INNOVUS_CTS_COMPLETE` present, no `INNOVUS_CTS_FAILED` |
| Clock mode | `rpt/pnr_clock_skew.rpt` | `Clock Network Latency` must NOT show `(Ideal) 0.000` |
| WNS (setup) | `rpt/pnr_timing.rpt` | >= 0 ns |
| WHS (hold) | `rpt/pnr_hold_timing.rpt` | >= 0 ns (only valid if CTS completed) |
| Utilization | `rpt/pnr_area.rpt` | 65-75% typical |
| Congestion overflow | `rpt/pnr_congestion.rpt` | 0 |
| DRC | `rpt/pnr_check_drc.rpt` | 0 violations |

### Step 7: GDS export (conditional)

Only if **all** of the following are true:
- `INNOVUS_CTS_COMPLETE` present in PnR log (clock tree built, not ideal)
- WNS >= 0 (setup met)
- WHS >= 0 (hold met — only valid after real CTS)
- No `INNOVUS_PNR_QOR_FAIL` marker

If any condition fails, do **not** export GDS. The template script enforces this gate automatically via `exit 1` on QoR failure, but if running manually, verify before proceeding.

Read `scripts/innovus_gds_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{DB_DIR}}` | `output/innovus` |
| `{{GDS_DIR}}` | `output/gds` |
| `{{DESIGN}}` | spec.md → design name |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{LAYER_MAP_CMD}}` | `-mapFile <path>` if eda_env.json → pdk.layer_map exists; empty string if not available |
| `{{MERGE_GDS_FILES}}` | eda_env.json → std cell GDS + macro GDS file paths. Must include all cell GDS — otherwise Calibre reports undefined cells |

Write to `scripts/innovus_gds.tcl`. Execute:

```
innovus -batch -files scripts/innovus_gds.tcl -log rpt/innovus_gds 2>&1 | tee rpt/innovus_gds.log
```

### Step 8: Route result

| Result | Route to | Action |
|---|---|---|
| Timing met, 0 DRC, GDS exported | `mcu-signoff-review` | Proceed to signoff |
| WNS/WHS < 0 after 3 opt iterations | `INNOVUS_PNR_QOR_FAIL` | Script already tried 3 rounds (setup+hold → hold-focused → drv cleanup). Review iter reports in `rpt/pnr_opt_iter*` to see if slack is improving. If stagnant, roll back upstream |
| WNS < 0 (large) or congestion | `mcu-synthesis-planning` | May need constraint or RTL change |
| Floorplan issues | Adjust macro placement, die size | Iterate floorplan step |

## PnR Quality Rules

### Implementation hotspot patterns

- Macro placement creates routing choke points — channel width often matters more than route retries
- Clock root choices amplify skew or buffering pressure
- Reset or control networks create unexpected fanout stress near macros
- Power planning assumptions conflict with placement reality
- Bus and control logic adjacent to macros can create repeated localized congestion overflow

### Behavioral memory and black-box CTS handling

When the design contains behavioral memory models (e.g. boot_rom, sram_ctrl with Verilog `reg` arrays), these modules have no physical cells for Innovus to place. CTS must still run — it just needs to exclude these instances.

**Generating `{{BLACK_BOX_CTS_CMDS}}`:**

For each behavioral or black-boxed module in the netlist, emit:

```tcl
# Exclude behavioral memory from CTS optimization
set_db [get_db insts -if {.base_cell.name == <module_name>}] .dont_touch true
```

Example for a design with boot_rom and sram_ctrl:

```tcl
set_db [get_db insts -if {.base_cell.name == boot_rom}] .dont_touch true
set_db [get_db insts -if {.base_cell.name == sram_ctrl}] .dont_touch true
```

If the module has **no instances** in the post-synthesis netlist (already flattened or optimized away), the `get_db` returns empty and the command is harmless. Do **not** skip CTS just because behavioral models exist — the `dont_touch` exclusion is sufficient.

### CTS failure diagnosis

When `INNOVUS_CTS_FAILED` appears, check in order:
1. Clock definition — is `create_clock` present in the SDC for all intended clocks?
2. Black-box `dont_touch` — are clock sink pins inside black boxes excluded correctly via `{{BLACK_BOX_CTS_CMDS}}`?
3. MMMC view — are both setup and hold analysis views defined with valid libraries?
4. Clock pin connectivity — does the netlist actually connect the clock port to FF clock pins?
5. Behavioral models — were they excluded with `dont_touch` rather than causing CTS to be skipped entirely?

Do not attempt to route or export GDS until CTS succeeds. Hold results under ideal clock are meaningless.

### Rollback signals

Roll back to an upstream stage when:
- Severe timing spread is caused by unrealistic synthesis constraints — fix constraints first
- Congestion is caused by architecture-level hierarchy or floorplan assumptions — adjust floorplan or RTL
- Repeated CTS instability is tied to unresolved clock intent — clarify clock architecture

### Black-box and macro handling

- Treat SRAM macros and protected IP as placement-shaping objects, not ordinary logic
- Keep `dont_touch` intent explicit for blocks that should not be reshaped by optimization
- Watch for routing choke points and skew pressure around macro channels
- If macro placement dominates critical paths, prefer floorplan adjustment before broad route retries
- Long control paths around macros often show up later as signoff timing surprises

## Bundled References

- [floorplan-input-validation.md](references/floorplan-input-validation.md) — input completeness
- [engineering-thresholds.md](references/engineering-thresholds.md) — utilization and congestion bands

## Bundled Assets

- [pnr-review-template.md](assets/pnr-review-template.md) — PnR review output format
- [example-pnr-review.md](assets/example-pnr-review.md) — sample PnR review output
- [sample-pnr-hotspots.json](assets/sample-pnr-hotspots.json) — structured hotspot example

## Bundled Scripts

- [innovus_fp_template.tcl](scripts/innovus_fp_template.tcl) — floorplan template (verified against MCP server)
- [innovus_pnr_template.tcl](scripts/innovus_pnr_template.tcl) — P&R template (verified against MCP server)
- [innovus_gds_template.tcl](scripts/innovus_gds_template.tcl) — GDS export template
- [innovus_mmmc_template.view](scripts/innovus_mmmc_template.view) — MMMC view template
- [parse_congestion_summary.py](scripts/parse_congestion_summary.py) — congestion report parser

> **Note:** All script templates above target Innovus. ICC2 is a supported PnR option, but equivalent ICC2 templates are not bundled. If `selected_tools.pnr` is `icc2`, the user must supply equivalent TCL scripts.

## Completion Gate

- MMMC view and all scripts generated from templates with project-specific values
- Floorplan executed, `INNOVUS_FLOORPLAN_COMPLETE` in log, database saved
- Placement completed, `INNOVUS_PLACEMENT_COMPLETE` in log
- CTS succeeded, `INNOVUS_CTS_COMPLETE` in log, clock propagated (not ideal)
- Routing completed, post-route timing report generated
- Post-route optimization ran (up to 3 iterations), timing converged (WNS >= 0, WHS >= 0)
- Filler cells inserted, `ecoRoute -fix_drc` run
- Timing/area/power/congestion/DRC reports generated
- Post-route netlist, DEF, SDC exported
- GDS exported only if all QoR checks pass (`INNOVUS_PNR_COMPLETE` in log)
- QoR assessed with next-step routing to `mcu-signoff-review`

## Decision Rules

- Do not treat repeated congestion symptoms as isolated local noise.
- Call out upstream causes early when placement trouble is structural.
- If utilization > 80%, flag as high risk — may need die size increase or RTL optimization.
- Back up previous PnR outputs before re-running.

