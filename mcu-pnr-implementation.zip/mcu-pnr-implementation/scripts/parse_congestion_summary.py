import json
import re
import sys


def main() -> int:
    text = sys.stdin.read()

    # Extract overflow count
    overflow_match = re.search(r"overflow[^0-9]*([0-9]+)", text, re.I)
    overflow = int(overflow_match.group(1)) if overflow_match else None

    # Extract congestion hotspot mentions
    hot_match = re.search(r"hotspot|congestion", text, re.I)

    # Extract utilization percentage
    util_match = re.search(r"utilization[^0-9]*([0-9]+(?:\.\d+)?)\s*%", text, re.I)
    utilization = float(util_match.group(1)) if util_match else None

    # Extract DRC violation count from PnR check
    drc_match = re.search(r"(?:DRC|violation)[^0-9]*([0-9]+)", text, re.I)
    drc_count = int(drc_match.group(1)) if drc_match else None

    payload = {
        "overflow_count": overflow,
        "mentions_hotspot": bool(hot_match),
        "utilization_pct": utilization,
        "drc_violations": drc_count,
    }
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
