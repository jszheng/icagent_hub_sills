# {{GENERATED_BY}}
# Cadence Innovus GDS Export Script
# Design: {{DESIGN}}

restoreDesign {{DB_DIR}}/pnr_db.dat {{TOP_MODULE}}

# GDS stream out
# {{LAYER_MAP_CMD}} is either "-mapFile <path>" or empty if no layer map available
set streamOutMode -specifyViaName default
streamOut {{GDS_DIR}}/{{DESIGN}}.gds \
    {{LAYER_MAP_CMD}} \
    -libName {{DESIGN}} \
    -structureName {{TOP_MODULE}} \
    -merge {{{MERGE_GDS_FILES}}} \
    -mode ALL \
    -stripes 1 \
    -units 1000

puts "INNOVUS_GDS_EXPORT_COMPLETE"
exit
