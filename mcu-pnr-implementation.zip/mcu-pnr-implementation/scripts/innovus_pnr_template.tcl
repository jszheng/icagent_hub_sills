# {{GENERATED_BY}}
# Innovus Place & Route Script — generated from innovus_pnr_template.tcl
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-pnr-implementation skill
# Verified against MCP server innovus.mjs

set PROJ_HOME "{{PROJ_HOME}}"

#-------------------------------------------------------------------------------
# Restore Floorplanned Design
#-------------------------------------------------------------------------------
restoreDesign {{DB_DIR}}/fp_db.dat {{TOP_MODULE}}

#-------------------------------------------------------------------------------
# Placement
#-------------------------------------------------------------------------------
puts "INFO: Starting placement..."
set_db place_detail_legalization_inst_gap 1
place_opt_design

report_timing -max_paths 5 > {{RPT_DIR}}/pnr_post_place_timing.rpt
reportCongestion > {{RPT_DIR}}/pnr_post_place_congestion.rpt

saveDesign {{DB_DIR}}/placed_db
puts "INNOVUS_PLACEMENT_COMPLETE"

#-------------------------------------------------------------------------------
# Clock Tree Synthesis
#-------------------------------------------------------------------------------
puts "INFO: Starting clock tree synthesis..."
set_db cts_target_max_transition_time 0.15
set_db cts_target_skew 0.1

# Exclude black box / behavioral memory instances from CTS
{{BLACK_BOX_CTS_CMDS}}

set_ccopt_property update_io_latency false
create_ccopt_clock_tree_spec
set_ccopt_property target_max_trans 0.15
set_ccopt_property target_skew 0.1

if {[catch {clock_opt_design} cts_err]} {
  puts "ERROR: CTS failed: $cts_err"
  puts "INNOVUS_CTS_FAILED"
  saveDesign {{DB_DIR}}/pnr_cts_fail_db
  exit 1
}

# Verify clock is propagated (not ideal) after CTS
report_clock_timing -type skew > {{RPT_DIR}}/pnr_clock_skew.rpt
set cts_skew_rpt [report_clock_timing -type skew -return_string]
if {[string match "*\(Ideal\)*" $cts_skew_rpt] || [string length [string trim $cts_skew_rpt]] == 0} {
  puts "ERROR: Clock still ideal after CTS — tree not built"
  puts "INNOVUS_CTS_FAILED"
  saveDesign {{DB_DIR}}/pnr_cts_fail_db
  exit 1
}
puts "INNOVUS_CTS_COMPLETE"

report_timing -max_paths 5 > {{RPT_DIR}}/pnr_post_cts_timing.rpt
saveDesign {{DB_DIR}}/cts_db

#-------------------------------------------------------------------------------
# Routing
#-------------------------------------------------------------------------------
puts "INFO: Starting routing..."
setNanoRouteMode -quiet -drouteEndIteration 30
set_db route_design_with_timing_driven true
set_db route_design_with_si_driven true
routeDesign -globalDetail

report_timing -max_paths 5 > {{RPT_DIR}}/pnr_post_route_timing.rpt
saveDesign {{DB_DIR}}/routed_db

#-------------------------------------------------------------------------------
# Post-Route Optimization — iterative convergence (up to 3 rounds)
#-------------------------------------------------------------------------------
puts "INFO: Starting post-route optimization..."
set_db timing_analysis_type ocv

set max_opt_iter 3
set converged 0

for {set iter 1} {$iter <= $max_opt_iter} {incr iter} {
  puts "INFO: Post-route optimization iteration ${iter}/${max_opt_iter}"

  if {$iter == 1} {
    # Round 1: joint setup + hold
    if {[catch {optDesign -postRoute -setup -hold} opt_err]} {
      puts "WARNING: Optimization iteration ${iter} failed: $opt_err"
    }
  } elseif {$iter == 2} {
    # Round 2: hold-focused with higher effort
    if {[catch {optDesign -postRoute -hold -expandedViews} opt_err]} {
      puts "WARNING: Optimization iteration ${iter} failed: $opt_err"
    }
  } else {
    # Round 3: incremental with drv cleanup
    if {[catch {optDesign -postRoute -setup -hold -drv} opt_err]} {
      puts "WARNING: Optimization iteration ${iter} failed: $opt_err"
    }
  }

  # Check if timing converged after this round
  set chk_setup [report_timing -max_paths 1 -return_string]
  set chk_hold  [report_timing -early -max_paths 1 -return_string]

  set setup_ok 1
  set hold_ok  1
  if {[regexp {Slack Time\s+(-[0-9.]+)} $chk_setup -> s_val]} {
    puts "INFO: Iter ${iter} setup WNS = ${s_val} (violated)"
    set setup_ok 0
  }
  if {[regexp {Slack Time\s+(-[0-9.]+)} $chk_hold -> h_val]} {
    puts "INFO: Iter ${iter} hold WHS = ${h_val} (violated)"
    set hold_ok 0
  }

  if {$setup_ok && $hold_ok} {
    puts "INFO: Timing converged after iteration ${iter}"
    set converged 1
    break
  }

  # Save intermediate report per iteration
  report_timing -max_paths 5 > {{RPT_DIR}}/pnr_opt_iter${iter}_timing.rpt
  report_timing -early -max_paths 5 > {{RPT_DIR}}/pnr_opt_iter${iter}_hold.rpt
}

if {!$converged} {
  puts "WARNING: Timing not converged after ${max_opt_iter} optimization rounds"
}

#-------------------------------------------------------------------------------
# Filler Cells
#-------------------------------------------------------------------------------
puts "INFO: Inserting filler cells..."
addFiller -cell {{{FILLER_CELLS}}} -prefix FILLER
checkFiller

# Fix DRC caused by filler insertion
ecoRoute -fix_drc

#-------------------------------------------------------------------------------
# Final Reports
#-------------------------------------------------------------------------------
report_timing -max_paths 10 > {{RPT_DIR}}/pnr_timing.rpt
report_timing -early -max_paths 10 > {{RPT_DIR}}/pnr_hold_timing.rpt
report_area > {{RPT_DIR}}/pnr_area.rpt
report_power > {{RPT_DIR}}/pnr_power.rpt
reportCongestion > {{RPT_DIR}}/pnr_congestion.rpt
report_design > {{RPT_DIR}}/pnr_design_summary.rpt

# DRC checks
verify_drc > {{RPT_DIR}}/pnr_check_drc.rpt
verifyConnectivity > {{RPT_DIR}}/pnr_check_conn.rpt

#-------------------------------------------------------------------------------
# QoR Gate — block GDS export if timing not converged
#-------------------------------------------------------------------------------
set setup_rpt [report_timing -max_paths 1 -return_string]
set hold_rpt  [report_timing -early -max_paths 1 -return_string]

set qor_pass 1
if {[regexp {Slack Time\s+(-[0-9.]+)} $setup_rpt -> wns_val]} {
  puts "ERROR: Setup violated (WNS=${wns_val}) after ${max_opt_iter} iterations, skipping GDS export"
  set qor_pass 0
}
if {[regexp {Slack Time\s+(-[0-9.]+)} $hold_rpt -> whs_val]} {
  puts "ERROR: Hold violated (WHS=${whs_val}) after ${max_opt_iter} iterations, skipping GDS export"
  set qor_pass 0
}

if {!$qor_pass} {
  puts "INNOVUS_PNR_QOR_FAIL"
  saveDesign {{DB_DIR}}/pnr_db
  saveNetlist {{OUTPUT_DIR}}/{{DESIGN}}_final.v
  write_sdc {{OUTPUT_DIR}}/{{DESIGN}}_final.sdc
  defOut -floorplan -netlist -routing {{OUTPUT_DIR}}/{{DESIGN}}_final.def
  puts "INFO: Netlist/DEF/SDC saved for debug, but GDS not exported"
  exit 1
}

#-------------------------------------------------------------------------------
# Export Deliverables
#-------------------------------------------------------------------------------
saveNetlist {{OUTPUT_DIR}}/{{DESIGN}}_final.v
write_sdc {{OUTPUT_DIR}}/{{DESIGN}}_final.sdc
defOut -floorplan -netlist -routing {{OUTPUT_DIR}}/{{DESIGN}}_final.def

#-------------------------------------------------------------------------------
# Save Design
#-------------------------------------------------------------------------------
saveDesign {{DB_DIR}}/pnr_db

puts "INNOVUS_PNR_COMPLETE"
exit
