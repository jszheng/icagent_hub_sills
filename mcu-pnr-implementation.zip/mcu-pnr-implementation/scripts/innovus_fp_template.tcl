# {{GENERATED_BY}}
# Innovus Floorplan Script — generated from innovus_fp_template.tcl
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-pnr-implementation skill
# Verified against MCP server innovus.mjs

set PROJ_HOME "{{PROJ_HOME}}"

#-------------------------------------------------------------------------------
# Design Import
#-------------------------------------------------------------------------------
set init_lef_file [list \
{{LEF_FILE_LIST}}
]

set init_verilog {{SYN_NETLIST}}
set init_design_netlisttype Verilog
set init_design_settop 1
set init_top_cell {{TOP_MODULE}}
set init_pwr_net VDD
set init_gnd_net VSS
set init_mmmc_file {{MMMC_FILE}}

#-------------------------------------------------------------------------------
# Initialize Design
#-------------------------------------------------------------------------------
init_design

# Power connections
globalNetConnect VDD -type pgpin -pin VDD -inst * -override
globalNetConnect VSS -type pgpin -pin VSS -inst * -override

#-------------------------------------------------------------------------------
# Floorplan
#-------------------------------------------------------------------------------
floorPlan -site core -d {{DIE_WIDTH}} {{DIE_HEIGHT}} {{CORE_MARGIN}} {{CORE_MARGIN}} {{CORE_MARGIN}} {{CORE_MARGIN}}

#-------------------------------------------------------------------------------
# Macro Placement (project-specific, fill per design)
#-------------------------------------------------------------------------------
{{MACRO_PLACEMENT_CMDS}}

#-------------------------------------------------------------------------------
# Power Planning - Rings
#-------------------------------------------------------------------------------
addRing -nets {VDD VSS} -type core_rings \
  -layer {top {{RING_H_LAYER}} bottom {{RING_H_LAYER}} left {{RING_V_LAYER}} right {{RING_V_LAYER}}} \
  -width {top 3 bottom 3 left 3 right 3} \
  -spacing {top 1.5 bottom 1.5 left 1.5 right 1.5} \
  -offset {top 2 bottom 2 left 2 right 2}

#-------------------------------------------------------------------------------
# Power Planning - Stripes
#-------------------------------------------------------------------------------
addStripe -nets {VDD VSS} \
  -layer {{STRIPE_V_LAYER}} -direction vertical \
  -width 1.5 -spacing 0.5 -set_to_set_distance 50 \
  -start_from left -start_offset 25

addStripe -nets {VDD VSS} \
  -layer {{STRIPE_H_LAYER}} -direction horizontal \
  -width 1.5 -spacing 0.5 -set_to_set_distance 50 \
  -start_from bottom -start_offset 25

# Special route for power connections
sroute -connect {blockPin padPin padRing corePin floatingStripe} \
  -nets {VDD VSS} \
  -layerChangeRange {{{ROUTE_LAYER_RANGE}}} \
  -blockPinTarget nearestTarget \
  -padPinPortConnect allPort \
  -allowJogging 1 \
  -crossoverViaLayerRange {{{ROUTE_LAYER_RANGE}}}

#-------------------------------------------------------------------------------
# Well Taps and Endcaps
#-------------------------------------------------------------------------------
addWellTap -cell {{TAP_CELL}} -cellInterval 30 -prefix WELLTAP

setEndCapMode -leftEdge {{ENDCAP_LEFT}} -rightEdge {{ENDCAP_RIGHT}}
addEndCap -prefix ENDCAP

#-------------------------------------------------------------------------------
# Reports and Save
#-------------------------------------------------------------------------------
report_design > {{RPT_DIR}}/fp_summary.rpt
checkFPlan > {{RPT_DIR}}/fp_check.rpt

saveDesign {{DB_DIR}}/fp_db

puts "INNOVUS_FLOORPLAN_COMPLETE"
