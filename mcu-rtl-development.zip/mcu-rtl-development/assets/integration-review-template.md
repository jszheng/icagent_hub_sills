# Integration Review: [Project Name]

## Scope and reviewed modules

List every module reviewed in this pass. Include hierarchy level (leaf / mid / top).

| Module | Hierarchy | Files reviewed |
|--------|-----------|----------------|
| cortex_m3_wrapper | mid | rtl/core/cortex_m3_wrapper.v |
| ahb_interconnect | mid | rtl/bus/ahb_interconnect.v |
| ... | ... | ... |

## Stable interfaces

List interfaces that are confirmed correct and consistent with the spec. These are safe to build upon.

For each stable interface, state:
- Which two modules it connects
- Protocol (AHB-Lite / APB / custom)
- Key signals verified (port widths, naming, reset polarity)

## Unstable interfaces

List interfaces with known issues or ambiguities. Each entry must include:

| Interface | Issue | Severity | Affected modules |
|-----------|-------|----------|-----------------|
| UART IRQ output | Combined vs split mode ambiguous in spec | Medium | uart.v, mcu_top.v |
| ... | ... | ... | ... |

Severity levels: **Blocker** (must fix before compile), **Medium** (should fix before verification), **Low** (cosmetic or future risk).

## Recommended integration order

Numbered list of stabilization steps. Follow the standard sequence:
1. Freeze CPU wrapper ports and top-level reset polarity
2. Freeze bus address decode and peripheral select
3. Freeze interrupt numbering and tie-off strategy
4. Stabilize peripheral register interfaces
5. Rebuild filelist from module ownership, not trial-and-error

For each step, note what is already done vs. what remains.

## Blockers before verification

Bullet list of issues that **must** be resolved before the design can be compiled and simulated. Each blocker should reference:
- Which module(s) are affected
- What the issue is
- What action is needed (RTL fix, spec clarification, or user decision)

If there are no blockers, explicitly state: "No blockers identified — design is ready for compilation."
