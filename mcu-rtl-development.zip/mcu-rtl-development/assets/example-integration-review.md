# Integration Review: cortex_m3_mcu

## Scope and reviewed modules

| Module | Hierarchy | Files reviewed |
|--------|-----------|----------------|
| cortex_m3_wrapper | mid | rtl/core/cortex_m3_wrapper.v |
| ahb_interconnect | mid | rtl/bus/ahb_interconnect.v |
| default_slave | leaf | rtl/bus/default_slave.v |
| ahb_to_apb_bridge | mid | rtl/bus/ahb_to_apb_bridge.v |
| gpio | mid | rtl/peripheral/gpio.v |
| uart | mid | rtl/peripheral/uart.v |
| clk_manager | leaf | rtl/clk_rst/clk_manager.v |
| reset_controller | leaf | rtl/clk_rst/reset_controller.v |
| cortex_m3_mcu_top | top | rtl/top/cortex_m3_mcu_top.v |

## Stable interfaces

- **cortex_m3_wrapper ↔ ahb_interconnect**: AHB-Lite master interface. Port widths (32-bit HADDR/HWDATA/HRDATA, 2-bit HTRANS, 3-bit HSIZE) verified. HREADY feedback path connected. Naming follows ARM convention.
- **reset_controller → all modules**: Single async_rst_n input, sync_rst_n output per clock domain. Active-low polarity consistent across all instantiations.
- **Interrupt fan-in → cortex_m3_wrapper**: gpio_irq and uart_irq routed through centralized IRQ vector before entering wrapper. IRQ numbers match spec interrupt map (GPIO=0, UART=1).

## Unstable interfaces

| Interface | Issue | Severity | Affected modules |
|-----------|-------|----------|-----------------|
| ahb_interconnect → peripheral HREADY | GPIO returns HREADY=1 combinationally; UART registers it, adding 1-cycle latency. Mux in interconnect does not account for per-slave HREADY timing. | **Blocker** | ahb_interconnect.v, gpio.v, uart.v |
| uart IRQ output | Spec is ambiguous: single combined irq_uart vs separate irq_uart_tx / irq_uart_rx. RTL currently uses combined, but interrupt map table shows two entries. | **Medium** | uart.v, cortex_m3_mcu_top.v |
| ahb_to_apb_bridge PSEL decode | Bridge decodes PADDR[11:8] for peripheral select, but GPIO and UART both have 256-byte register space — only PADDR[11:8] gives 16 slots of 256 bytes, which is correct, but the decode constants are defined as magic numbers (4'h0, 4'h1) without linking back to spec base addresses. | **Low** | ahb_to_apb_bridge.v |
| filelist.f ordering | uart.v appears before uart_regs.v in filelist even though uart.v instantiates uart_regs. Compilation succeeds only because VCS resolves forward references, but other tools (Genus, Formality) may fail. | **Medium** | rtl/filelist.f |

## Recommended integration order

1. **Freeze CPU wrapper ports and top-level reset polarity** — Done. Wrapper ports match ARM Cortex-M3 DS integration guide. Reset is active-low throughout.
2. **Freeze bus address decode and peripheral select** — Partially done. Interconnect slave_sel assignments match spec memory map, but APB bridge decode uses magic numbers. Action: replace with localparam referencing spec base addresses.
3. **Freeze interrupt numbering and tie-off strategy** — Blocked. UART IRQ split vs combined must be resolved with spec owner before freezing. GPIO IRQ numbering is stable.
4. **Stabilize peripheral register interfaces** — Not started. GPIO register file exists but UART register file is a stub with placeholder read mux.
5. **Rebuild filelist from module ownership** — Not started. Current filelist was built by trial-and-error compilation. Action: regenerate from bottom-up hierarchy.

## Blockers before verification

- **HREADY mux inconsistency**: ahb_interconnect does not properly mux per-slave HREADY signals. If GPIO responds in the same cycle but UART inserts a wait state, the interconnect may forward the wrong HREADY to the master. Fix: ensure interconnect selects HREADY from the active slave only, and drives HREADY=1 during idle (no slave selected).
- **UART IRQ ambiguity**: Cannot finalize top-level interrupt wiring until spec clarifies combined vs split mode. Action: escalate to spec owner for clarification before proceeding with verification.
