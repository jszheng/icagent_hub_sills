# Bus Protocol Templates

## AHB-Lite Slave Interface

```verilog
module ahb_slave_example (
  input  wire        HCLK,
  input  wire        HRESETn,
  input  wire        HSEL,
  input  wire [31:0] HADDR,
  input  wire        HWRITE,
  input  wire [ 1:0] HTRANS,
  input  wire [ 2:0] HSIZE,
  input  wire [31:0] HWDATA,
  output reg  [31:0] HRDATA,
  output wire        HREADY,
  output wire        HRESP
);
  // Address phase capture
  reg [31:0] addr_q;
  reg        wr_q;
  reg        valid_q;

  always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
      addr_q  <= '0;
      wr_q    <= 1'b0;
      valid_q <= 1'b0;
    end else if (HREADY) begin
      addr_q  <= HADDR;
      wr_q    <= HWRITE;
      // HTRANS[1] filters to NONSEQ (2'b10) and SEQ (2'b11) only.
      // IDLE (2'b00) and BUSY (2'b01) are excluded — a BUSY beat
      // means the master is not ready to transfer, so the slave
      // must not treat it as a valid transaction.
      valid_q <= HSEL && HTRANS[1];
    end
  end

  assign HREADY = 1'b1;  // No wait states
  assign HRESP  = 1'b0;  // Always OKAY
  // Data phase: register read/write logic goes here
endmodule
```

## APB Slave Interface

```verilog
module apb_slave_example (
  input  wire        PCLK,
  input  wire        PRESETn,
  input  wire        PSEL,
  input  wire        PENABLE,
  input  wire        PWRITE,
  input  wire [11:0] PADDR,
  input  wire [31:0] PWDATA,
  output reg  [31:0] PRDATA,
  output wire        PREADY,
  output wire        PSLVERR
);
  assign PREADY  = 1'b1;  // No wait states
  assign PSLVERR = 1'b0;

  // APB has two phases per transfer:
  //   Setup phase:  PSEL=1, PENABLE=0 — address and control are valid
  //   Access phase: PSEL=1, PENABLE=1 — data transfer occurs
  //
  // Write condition (access phase): PSEL && PENABLE && PWRITE
  // Read  condition (access phase): PSEL && PENABLE && !PWRITE
  //   PRDATA must be valid by the end of the access phase.
  //   For zero-wait-state slaves (PREADY=1), drive PRDATA
  //   combinationally from PADDR during the access phase.

  always @(posedge PCLK or negedge PRESETn) begin
    if (!PRESETn) begin
      // reset writable registers
    end else if (PSEL && PENABLE && PWRITE) begin
      // register write logic using PADDR and PWDATA
    end
  end

  // Read mux — active during access phase
  always @(*) begin
    if (PSEL && !PWRITE)
      PRDATA = 32'h0; // replace with address-based read mux
    else
      PRDATA = 32'h0;
  end
endmodule
```

## AHB-to-APB Bridge (Key Signals)

- Converts AHB single-cycle address phase to APB two-cycle (setup + access)
- Generates PSEL per peripheral from address decode
- Holds HREADY low during APB access phase to insert wait state on AHB side
- Bridge must register HADDR/HWRITE during AHB address phase and replay them as PADDR/PWRITE in APB setup phase

## Address Decode Constraints

### Alignment rules

- Each slave's base address must be naturally aligned to its address space size. For example, a 4KB slave (size = 0x1000) must have a base address that is a multiple of 0x1000.
- Alignment enables simple decode: `assign sel = (HADDR[31:ADDR_MSB] == BASE[31:ADDR_MSB]);` — no subtraction needed.
- If the spec provides a misaligned base address, flag it as a spec error; do not work around it in RTL.

### Overlap detection

- No two slaves may have overlapping address ranges. When generating the interconnect, verify: for every pair (A, B), either `A.base + A.size <= B.base` or `B.base + B.size <= A.base`.
- Unmapped address ranges must route to a default slave that returns an error response.

### Decode implementation

```verilog
// One-hot slave select from address — must be mutually exclusive
assign slave_sel[0] = (HADDR[31:16] == 16'h0000);  // Boot ROM: 0x0000_0000
assign slave_sel[1] = (HADDR[31:16] == 16'h2000);  // SRAM:     0x2000_0000
assign slave_sel[2] = (HADDR[31:12] == 20'h40000);  // GPIO:     0x4000_0000
// ...
assign default_sel  = ~|slave_sel;                   // Default slave for unmapped
```

### Common mistakes to avoid

- Decoding too few address bits: causes aliasing (same slave responds at multiple addresses).
- Decoding too many address bits: causes holes within the slave's intended range.
- Forgetting the default slave: unmapped accesses hang the bus (no HREADY response).

## Wait-State and Error Response Rules

### AHB-Lite wait states

- A slave inserts wait states by holding `HREADY` low. The master and all other slaves freeze until `HREADY` goes high.
- Every slave **must** eventually assert `HREADY` — an unconditional `HREADY = 0` will deadlock the bus.
- For peripherals with variable latency (e.g., flash controller), implement a timeout counter that forces `HREADY` high and asserts `HRESP = 1` (ERROR) if the operation takes too long.

### AHB-Lite error response

- AHB-Lite uses a **single-cycle** error response: drive `HRESP = 1` and `HREADY = 1` in the same cycle. (Note: full AHB uses a two-cycle error response where HREADY is driven low for one cycle then high — AHB-Lite simplifies this to one cycle.)
- The default slave must always return ERROR for any access (it catches unmapped addresses).
- A slave that receives an unsupported HSIZE (e.g., word access to a byte-only peripheral) should return ERROR.

### APB wait states

- A slave inserts wait states by holding `PREADY` low during the access phase (PSEL=1, PENABLE=1).
- Like AHB, every APB slave **must** eventually assert `PREADY` — implement a timeout if needed.
- `PSLVERR` is sampled at the rising edge when both `PENABLE` and `PREADY` are high.

### APB error response

- Drive `PSLVERR = 1` in the same cycle as `PREADY = 1` to signal an error.
- Use for: access to reserved address offsets, write to RO register (optional — can also silently ignore).
