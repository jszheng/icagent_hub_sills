# Peripheral Register Pattern

Standard pattern for generating a peripheral with register file and control logic.

## Structure

```
peripheral_<name>/
  <name>_regs.v      — Register file (address decode + read/write)
  <name>_ctrl.v      — Control/datapath logic
  <name>.v           — Top wrapper (regs + ctrl + bus interface)
```

## Register File Template

For each register defined in spec:

```verilog
// Address: OFFSET, Width: WIDTH, Reset: RESET_VAL, Access: R/W
localparam ADDR_<REG_NAME> = 12'h<OFFSET>;

reg [WIDTH-1:0] <reg_name>_q;

// Write
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    <reg_name>_q <= <RESET_VAL>;
  else if (wr_en && (addr == ADDR_<REG_NAME>))
    <reg_name>_q <= wdata[WIDTH-1:0];
end

// Read mux entry
ADDR_<REG_NAME>: rdata = {{(32-WIDTH){1'b0}}, <reg_name>_q};
```

## Access Type Variations

| Access | Write behavior | Read behavior | Side-effect risk |
|--------|---------------|---------------|------------------|
| R/W | Normal write | Return current value | None |
| RO | Ignore writes | Return hardware-driven value | None |
| W1C | Clear bits where wdata=1 | Return current value | Write must use read-modify-write carefully; concurrent HW set vs SW clear is a race — use single-cycle priority (HW set wins or SW clear wins, pick one and document) |
| WO | Normal write | Return 0 | Reading returns stale/zero, not actual state |
| RC | Ignore writes | Return and clear | **Destructive read** — debug reads will clear status bits; consider providing a separate non-destructive alias register for debug |

### W1C Implementation

```verilog
// W1C: software clears by writing 1, hardware sets
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    status_q <= '0;
  else
    // HW set has priority over SW clear to avoid losing events
    status_q <= (status_q & ~(wr_en_w1c ? wdata : {WIDTH{1'b0}})) | hw_set_pulse;
end
```

### RC (Read-Clear) Implementation

```verilog
// RC: value clears when read
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    rc_reg_q <= '0;
  else if (rd_en && (addr == ADDR_RC_REG))
    rc_reg_q <= '0;        // clear on read
  else
    rc_reg_q <= rc_reg_q | hw_event;  // accumulate events
end
```

## Byte Enable Support

When the bus supports byte-level writes (e.g., AHB HSIZE < word), the register file must handle partial writes:

```verilog
// Byte-enable write for a 32-bit register
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    reg_q <= RESET_VAL;
  else if (wr_en && (addr == REG_ADDR)) begin
    if (byte_en[0]) reg_q[ 7: 0] <= wdata[ 7: 0];
    if (byte_en[1]) reg_q[15: 8] <= wdata[15: 8];
    if (byte_en[2]) reg_q[23:16] <= wdata[23:16];
    if (byte_en[3]) reg_q[31:24] <= wdata[31:24];
  end
end
```

If the design does not need sub-word access, document this explicitly and tie byte_en to 4'hF.

## Interrupt Register Set

Standard 3-register interrupt pattern:
- `INT_STATUS` (W1C) — hardware sets, software clears by writing 1
- `INT_ENABLE` (R/W) — mask per interrupt source
- `INT_RAW` (RO) — raw interrupt state before masking

```verilog
assign irq = |(int_status_q & int_enable_q);
```

## Spec-to-RTL Consistency Checklist

When generating or reviewing register files, verify each register against the spec:

| Check | What to verify |
|-------|---------------|
| Address | RTL localparam matches spec offset exactly |
| Width | Register width in RTL matches spec (do not silently widen to 32) |
| Reset value | RTL reset value matches spec reset column |
| Access type | RTL write/read behavior matches spec access type (R/W, RO, W1C, etc.) |
| Reserved bits | Reserved fields are read-as-zero, writes ignored (not writable) |
| Field ordering | Bit positions in RTL match spec bit-field table (MSB/LSB alignment) |
| Register count | Total number of registers in RTL matches spec register map — no extra, no missing |

If any mismatch is found, flag it as a potential spec-RTL inconsistency and do not silently "fix" it — the spec may need updating first.
