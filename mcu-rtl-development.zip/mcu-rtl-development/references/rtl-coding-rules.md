# RTL Coding Rules

## Synthesizable Conventions

- Use Verilog-2001 or SystemVerilog (match customer's tool capability)
- No `initial` blocks in synthesizable modules
- Explicit port declarations with direction and width
- No implicit wires — declare all internal signals
- Use `always_ff` / `always_comb` if SystemVerilog, or `always @(posedge clk)` / `always @(*)` for Verilog-2001

## Naming Conventions

- Module names: lowercase with underscores (e.g. `gpio_ctrl`, `uart_tx`)
- Flopped signals: `_q` suffix (e.g. `data_q`)
- Combinational next-state: `_d` suffix (e.g. `data_d`)
- Active-low signals: `_n` suffix (e.g. `rst_n`)
- Clock signals: `clk` prefix or suffix
- Parameters: UPPER_CASE

## Reset Strategy

- Async assert, sync deassert pattern
- Flops that are part of control paths or whose reset value matters for functional correctness must have explicit reset. Datapath flops that are gated by a valid signal may omit reset if the design ensures they are never read before being written.
- Reset value matches spec register map

## Clock Gating

- Always use library ICG (Integrated Clock Gating) cells for clock gating
- Do **not** infer clock gating with `assign gated_clk = clk & enable;` — this creates glitch-prone gates that cause CTS, DFT, and CDC issues
- If the target library does not provide ICG cells, use a latch-based gating pattern and clearly document it for synthesis tool guidance:

```verilog
// Latch-based clock gating — only use when no ICG cell is available
reg enable_latch;
always @(*) begin
  if (!clk)
    enable_latch = enable_q;
end
assign gated_clk = clk & enable_latch;
```

## Black Box IP

- Instantiate by exact module name from IP documentation
- Do not modify black box internals
- Wrap with SoC-level ports in a dedicated wrapper module

## Register File Pattern

```verilog
always @(posedge clk or negedge rst_n) begin
  if (!rst_n)
    reg_q <= RESET_VALUE;
  else if (wr_en && addr == REG_ADDR)
    reg_q <= wr_data[WIDTH-1:0];
end
assign rd_data = (addr == REG_ADDR) ? reg_q : '0;
```

## CDC (Clock Domain Crossing) Rules

CDC bugs are silent in simulation but cause metastability in silicon. Follow these rules strictly.

### CDC scenarios in a typical MCU

| Scenario | From → To | Typical location |
|----------|-----------|-----------------|
| JTAG ↔ system clock | jtag_tck → sys_clk | Debug access port |
| Async external input | async → sys_clk | GPIO input, UART RX, external IRQ |
| Clock-gated ↔ always-on | gated_clk → sys_clk | Peripheral wakeup signals |
| PLL output change | old_clk → new_clk | Clock switch mux |

### Single-bit crossing: 2FF synchronizer

```verilog
// Synchronizer for a single-bit signal crossing from clk_a to clk_b
reg sig_meta, sig_sync;
always @(posedge clk_b or negedge rst_b_n) begin
  if (!rst_b_n) begin
    sig_meta <= 1'b0;
    sig_sync <= 1'b0;
  end else begin
    sig_meta <= sig_from_clk_a;  // first stage — may go metastable
    sig_sync <= sig_meta;         // second stage — resolved
  end
end
// Use sig_sync in the clk_b domain, NEVER use sig_meta directly
```

### Multi-bit crossing: use gray code or handshake

- **Never** synchronize a multi-bit bus through independent 2FF synchronizers — bits arrive at different times, producing glitch values.
- For counters/pointers (e.g., FIFO rd/wr pointers): convert to Gray code before crossing, synchronize, then convert back.
- For data payloads: use a handshake protocol (req/ack with 2FF sync on each) or an async FIFO.

### Pulse crossing

- A pulse in the source domain may be shorter than the destination clock period and get missed.
- Use a toggle-based pulse synchronizer: source toggles a register on each pulse, destination detects edges on the synchronized toggle signal.

### What NOT to do

- Do not assume two clocks are "close enough in frequency" to skip synchronization.
- Do not use `negedge` tricks to "create half-cycle margin" — this breaks with clock skew.
- Do not mix clock domains in a single `always` block.

## Reset Crossing and Synchronization

### Reset synchronizer (async assert, sync deassert)

Every clock domain needs its own reset synchronizer. Raw async reset must not fan out directly to flops — it must be synchronized to each domain's clock.

```verilog
module reset_sync (
  input  wire clk,
  input  wire async_rst_n,   // raw async reset (active low)
  output wire sync_rst_n      // synchronized reset for this domain
);
  reg [1:0] rst_pipe;
  always @(posedge clk or negedge async_rst_n) begin
    if (!async_rst_n)
      rst_pipe <= 2'b00;      // async assert — immediate
    else
      rst_pipe <= {rst_pipe[0], 1'b1};  // sync deassert — 2 cycles
  end
  assign sync_rst_n = rst_pipe[1];
endmodule
```

### Reset domain rules

- Each clock domain gets its own `reset_sync` instance.
- Reset deassertion order matters: release upstream domains (bus, interconnect) before downstream (peripherals) to avoid spurious transactions during reset exit.
- If a module spans two clock domains, it needs two reset synchronizers — one per domain.
- Never gate reset with combinational logic (e.g., `assign local_rst = global_rst & enable;`) — this creates glitch risk on the reset tree.

## Lint and Synthesis Compatibility

### Common lint violations to avoid

| Lint rule | What it catches | How to fix |
|-----------|----------------|------------|
| Undriven signal | Declared but never assigned | Remove or connect |
| Multi-driven signal | Two `always` blocks drive the same signal | Merge into one block or use separate signals |
| Latch inference | `always @(*)` without full case/default | Add `default` to every `case`, cover all `if` branches |
| Width mismatch | Assigning N-bit value to M-bit signal (N≠M) | Explicit bit-select or zero-extend: `{(M-N){1'b0}, sig}` |
| Sensitivity list | Missing signals in `always @(...)` | Use `always @(*)` or `always_comb` |

### Synthesis compatibility rules

- Do not use `#delay` in synthesizable code — simulatable but ignored by synthesis, creating sim/synth mismatch.
- Do not use `force`/`release` in synthesizable modules — testbench only.
- Avoid `casex` — it treats `x` and `z` as don't-care, which can mask real bugs. Use `casez` if wildcard matching is needed, or `case` with explicit `default`.
- Every `case` statement must have a `default` branch, even if all values are covered — prevents latch inference and satisfies lint.
- Avoid arithmetic on signals wider than needed — synthesis may infer large adders. Use explicit bit-widths.
- `generate` blocks must have unique labels — unnamed generates cause tool warnings and make hierarchy navigation harder.
- Do not use `real` or `shortreal` types — not synthesizable.
