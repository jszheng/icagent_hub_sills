# Incremental Fix Rules

Detailed scope-control reference for incremental fixes. For escalation triggers, backup procedure, and change manifest schema, see the Incremental Fix workflow in SKILL.md.

## Scope Control

When fixing a diagnosed issue, change the minimum set of files needed:

| Diagnosis | Fix scope | Cascade |
|---|---|---|
| Syntax error in one file | Fix that file only | Recompile |
| Port width mismatch between two modules | Fix one side (prefer the leaf module) | Recompile |
| Missing signal connection in top | Fix top-level only | Recompile |
| Missing module | Generate the missing module + update filelist | Recompile + lint |
| Register map mismatch with spec | Fix register file module | Recompile + re-verify |
| Interface protocol error | Fix the offending module's bus logic | Recompile + re-verify |
| Clock/reset wiring error | Fix top-level or clk_rst module | Recompile + re-lint + CDC re-check |

## Fix Strategy by Error Type

### Syntax error
- Read the compiler error message for exact line and token.
- Fix only the syntax — do not refactor surrounding code.

### Port width mismatch
- Compare both sides against the spec. Fix the side that deviates from spec.
- If both sides match spec but disagree with each other, the spec has an inconsistency — escalate.
- Prefer fixing the leaf module over the parent to minimize cascade.

### Missing module
- Generate the module from spec.
- Add to filelist.f in correct compilation order (before any module that instantiates it).
- Run lint after adding.

### Logic bug (from simulation failure)
- Read the diagnostic waveform or checker message to understand expected vs actual behavior.
- Fix the specific logic path. Do not change unrelated logic in the same module.
- If the fix changes observable interface timing, cascade scope becomes full_reverify.

### Lint violation
- Fix the violation directly (width mismatch, latch inference, undriven signal).
- If the lint rule is a false positive due to tool limitation, add a waiver comment with justification, not a code change.
