---
name: mcu-rtl-development
description: Three modes — (1) Generate synthesizable Verilog RTL from architecture spec when no RTL exists yet. (2) Review integration contracts and filelist of existing RTL. (3) Apply targeted RTL fixes from verification triage diagnostics. Do NOT use for compilation, simulation, testbench generation, SDC constraints, or lint/CDC checks.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU RTL Development

Use this skill for all RTL-related engineering: generating modules from the architecture spec, reviewing integration contracts, wiring the top-level, and applying incremental fixes based on verification feedback.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** compile or simulate. (Companion skill: `mcu-compile-sim-run`)
- Do **not** generate testbenches. (Companion skill: `mcu-tb-development`)
- Do **not** generate SDC constraints. (Companion skill: `mcu-synthesis-planning`)
- Do **not** run lint or CDC checks. (Companion skill: `mcu-formal-and-assertion` or `mcu-verification-triage`)

## Three Modes

### Full Generation

Triggered when: architecture spec exists but RTL files do not. Generates all modules, top-level, and filelist.

### Integration Review

Triggered when: RTL files exist and need structural review — module boundaries, interface contracts, filelist completeness, integration risks.

### Incremental Fix

Triggered when: a diagnostic result identifies specific RTL modules that need targeted modification. The diagnostic may come from the `mcu-verification-triage` skill or be provided directly by the user (e.g., compiler error log, lint report).

## Good Outcome

Produce:

- synthesizable Verilog (.v) source files for all MCU subsystems
- top-level module wiring all components
- `filelist.f` in correct compilation order
- integration review with risk list and blocker identification
- change manifest (for incremental fix mode)

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| Architecture spec (spec.md, architecture.md) | User-provided or from `mcu-spec-architecture-planning` if available | Yes (full gen) |
| CPU core RTL or interface definition | Customer IP | Yes |
| Existing RTL files | Project rtl/ directory | Yes (review and fix modes) |
| Diagnostic result | User-provided (error log, lint report) or from `mcu-verification-triage` if available | Yes (incremental fix) |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| RTL modules | `rtl/**/*.v` | Synthesizable Verilog source files |
| Top-level module | `rtl/top/<top_module>.v` | Top-level integration |
| Filelist | `rtl/filelist.f` | Compilation order file list |
| Change manifest | `doc/rtl_changes.json` | Files created/modified with timestamps |

## Input Validation

### From spec.md (full generation mode)

| Required section | What to check | Used for |
|---|---|---|
| Module list | At least one module name with hierarchy level | Generating file structure |
| Memory map | Base address + size for each slave, no overlaps | Address decoder in bus interconnect |
| Peripheral register map | Per-register: name, offset, width, reset value, access type (R/W/RO/W1C) | Register file generation |
| Clock domains | Clock name, frequency, source port | Clock/reset module, timescale |
| Reset strategy | Async/sync, active polarity, reset tree | Reset synchronizer generation |
| Interrupt map | IRQ number per peripheral, trigger type | Interrupt routing in top-level |
| CPU core interface | Port list with direction, width, protocol (AHB-Lite/AXI) | CPU wrapper generation |
| Bus architecture | Bus type (AHB/APB/AXI), master-slave topology | Interconnect generation |

### From diagnostic result (incremental fix mode)

| Required field | What to check | Used for |
|---|---|---|
| `source` | Must be "rtl". If "tb", reject — this is a testbench issue, not an RTL issue. Suggest the `mcu-tb-development` skill if available, otherwise inform the user. | Confirming this is an RTL issue |
| `file` | Path to the failing RTL file | Locating file to fix |
| `error_type` | One of: syntax, port_mismatch, missing_module, logic_bug, lint_violation | Selecting fix strategy |
| `line` | Line number (if available) | Locating error position |
| `message` | Compiler or lint error text | Understanding the issue |
| `cascade_hint` | One of: compile_only, compile_and_lint, full_reverify | Determines cascade scope |

If `source` is not "rtl", do not proceed. Inform the user that this diagnostic targets a non-RTL component and is outside this skill's scope.

## Workflow — Full Generation

### Step 0: Safety gate (mandatory)

Before generating any files:

1. Check whether `rtl/` directory already contains `.v` files.
2. If it does, **stop** and ask the user whether to overwrite or switch to Integration Review / Incremental Fix mode.
3. If `rtl/` is empty or does not exist, produce a **dry-run manifest** listing every file that will be created. Each manifest entry must include at minimum: `path` (relative file path), `module` (Verilog module name), `subsystem` (e.g. bus_fabric, peripheral, top), and `description` (one-line purpose).
4. Present the manifest to the user and **wait for explicit confirmation** before writing any files.

### Step 1: Read architecture inputs

Read spec and architecture documents to extract module list, bus architecture, peripheral register maps, clock domains, reset strategy, CPU core interface, memory map, and interrupt assignments.

### Step 2: Generate modules by subsystem

Generate RTL organized by subsystem:

**CPU wrapper**: Wrap the CPU core (black box) with SoC-level ports.

**Bus infrastructure**: Interconnect (address decoder + mux), default slave, protocol bridges.

**Peripherals**: For each peripheral in spec — register file, control logic, bus interface.

**Clock and reset**: Clock gating module (use library ICG cells; never infer `clk & enable` gates), reset synchronizer (async assert / sync deassert), system control registers.

**Memory controllers**: SRAM controller with parameterized depth/width.

### Step 3: Generate top-level

Wire all subsystems into `<top_module>.v` per spec address map and interrupt routing.

### Step 4: Generate filelist.f

Compilation order rules:

1. **Packages and defines first**: `*_pkg.sv`, `*_defines.v`, `` `include`` header files. These define types, parameters, and macros used by downstream modules.
2. **Leaf modules next**: Modules with no sub-module instantiations (register files, simple controllers).
3. **Mid-level modules**: Bus infrastructure (interconnect, bridge, default slave), peripheral wrappers.
4. **CPU wrapper**: Depends on the black-box IP module name being known to the tool.
5. **Top-level last**: Instantiates everything above.

Practical rules:
- If module A instantiates module B, B must appear before A in the filelist.
- If a file uses `` `include "foo.vh" ``, the include path must be set via `-incdir` or `+incdir+` at the top of filelist.f, not by relying on the file appearing earlier.
- Never use filelist ordering to "fix" a missing `include` — add the proper `+incdir+` directive instead.
- Group files by subsystem directory with comments for readability.
- Verify: every `.v` / `.sv` file under `rtl/` must appear exactly once in the filelist — no duplicates, no missing files.

See [sample-filelist-inventory.json](assets/sample-filelist-inventory.json) for a reference grouping.

### Step 5: Write change manifest

Record all files created with cascade scope.

## Workflow — Integration Review

### Step 1: Read existing RTL and filelist

Check module boundaries, port widths, naming consistency, bus protocol compliance.

### Step 2: Review integration contracts

- Are all top-level ports connected?
- Do address ranges match spec memory map?
- Are clock domain crossings properly handled?
- Are black-box IP ports correctly wrapped?

### Step 3: Identify risks and blockers

Produce ranked list of integration issues that should be resolved before compilation.

Common integration risk patterns to check:
- Wrapper port naming differs from architecture summary.
- Address decode constants in RTL disagree with spec memory map.
- Reset polarity or release behavior inconsistent across modules.
- Peripheral interrupt outputs do not match the interrupt-map plan.
- Filelist order hides dependency confusion instead of fixing hierarchy.

### Step 4: Recommend integration order

Follow this sequence for stabilization:
1. Stabilize CPU wrapper and top-level ports.
2. Stabilize bus and address-decode contracts.
3. Integrate clock/reset and system-control logic.
4. Integrate memory and peripheral blocks.
5. Freeze compile order before broad verification debug.

Output format: see [integration-review-template.md](assets/integration-review-template.md) for review structure. See [example-integration-review.md](assets/example-integration-review.md) for a sample review output.

## Workflow — Incremental Fix

### Step 1: Read diagnostic, validate source field

### Step 2: Read only the affected file(s)

### Step 3: Back up modified files

Copy each file to `backup/<timestamp>/<original_filename>` before overwriting. Use ISO-8601 compact format for timestamp: `YYYYMMDD_HHMMSS` (e.g., `backup/20260412_143025/uart_regs.v`). If a backup with the same timestamp already exists, append `_1`, `_2`, etc.

### Step 4: Apply targeted fix (no unrelated refactoring)

### Step 5: Update filelist.f if new files added

### Step 6: Write change manifest with narrow cascade scope

| Change type | Cascade scope |
|---|---|
| Internal logic fix (no interface change) | Recompile only |
| Port/interface change | Recompile + re-lint + re-check top connections |
| New module added | Recompile + update filelist + re-lint |
| Clock/reset logic change | Recompile + re-lint + CDC re-check + re-synthesis |

### Escalation Triggers

Stop and ask the user if:
- Fix requires changing more than 3 files
- Fix changes a module interface used by 5+ instantiations
- Fix contradicts the spec (spec may be wrong)
- Fix involves the black-box CPU core interface
- Fix would change memory map addresses

### Change Manifest Schema

Every incremental fix must update `doc/rtl_changes.json`:

```json
{
  "timestamp": "ISO-8601",
  "trigger": "diagnostic source reference",
  "files_modified": [
    {
      "path": "rtl/peripheral/uart_regs.v",
      "lines_changed": "42-45",
      "change_type": "logic_fix"
    }
  ],
  "cascade_scope": "compile_only | compile_and_lint | full_reverify",
  "notes": "brief description of what changed and why"
}
```

## RTL Coding Conventions

- Synthesizable Verilog-2001 or SystemVerilog
- No `initial` blocks in synthesizable code
- Explicit port declarations, no implicit wires
- Reset: async assert, sync deassert (`always @(posedge clk or negedge rst_n)`)
- Register naming: `_q` suffix for flopped, `_d` for combinational next-state
- Bus interfaces: strict protocol adherence
- Register maps: match spec exactly (address, width, reset value, access type)
- Black box IP: instantiate by module name, do not modify
- Clock gating: always use library ICG cells; do not infer AND-gate clock gating (`clk & enable`) as it causes glitches and DFT/CTS issues

## Bundled References

- [rtl-coding-rules.md](references/rtl-coding-rules.md) — synthesizable coding conventions
- [bus-protocol-templates.md](references/bus-protocol-templates.md) — AHB-Lite and APB interface patterns
- [peripheral-register-pattern.md](references/peripheral-register-pattern.md) — standard register file template
- [incremental-fix-rules.md](references/incremental-fix-rules.md) — fix scoping and cascade rules
- [integration-review-template.md](assets/integration-review-template.md) — review output format
- [example-integration-review.md](assets/example-integration-review.md) — sample review output
- [sample-filelist-inventory.json](assets/sample-filelist-inventory.json) — example filelist structure by subsystem

## Completion Gate

Full generation: all modules have .v files, top-level wired, filelist.f complete, user confirmed dry-run manifest.

Integration review: risks ranked, blockers identified, filelist validated.

Incremental fix: diagnosed error addressed, no unrelated changes, change manifest updated, backup created.

## Decision Rules

- In incremental mode, never regenerate files not in the diagnostic.
- If fix requires changing >3 files or altering an interface used by 5+ modules, escalate to user.
- Always back up modified files before overwriting.
- If register map changes are needed, flag that spec may need updating first.
- In full generation mode, never overwrite existing RTL without explicit user confirmation.
