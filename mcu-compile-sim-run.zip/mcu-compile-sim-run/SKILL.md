---
name: mcu-compile-sim-run
description: Compile RTL and testbench, run simulation, collect results, and route failures to triage. Use when RTL and testbench files exist and need to be compiled and simulated. Supports full compile, incremental recompile, single test run, and multi-test regression.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Compile Sim Run

Use this skill to execute compilation and simulation using the EDA tools available in the environment. This skill runs tools, collects results, and routes to the appropriate next step.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify RTL or TB source files. (Companion skill: `mcu-rtl-development` / `mcu-tb-development`)
- Do **not** diagnose root causes beyond quick auto-diagnosis. (Companion skill: `mcu-verification-triage`)
- Do **not** run synthesis, PnR, or signoff tools. Only compile + simulate + lint.
- Do **not** plan test structure. (Companion skill: `mcu-tb-development`)

## Execution Modes

### Full Compile + Sim

All RTL and TB files are compiled from scratch, then a specified test is simulated.

### Incremental Recompile + Sim

Only changed files trigger recompilation (if the simulator supports incremental). Used after `mcu-rtl-development` or `mcu-tb-development` applies a targeted fix.

### Single Test Run

Compile (if needed) and run one specific test. Used during debug iteration.

### Regression Run

Compile with coverage enabled, run multiple tests (optionally with multiple random seeds), collect per-test pass/fail, merge coverage databases. Used after `mcu-tb-development` has defined the test list.

### CDC Run

Run clock domain crossing analysis (SpyGlass CDC; Ascent CDC supported but reference doc not bundled) to check synchronization.

### Lint Run

Run static lint analysis (SpyGlass/Ascent) without simulation.

## Good Outcome

Produce:

- compile log with clean compile (0 errors)
- simulation log with pass/fail result
- waveform dump file (for debug if needed)
- lint report (if lint run)
- structured run record for downstream consumption
- clear routing: pass → next stage, fail → `mcu-verification-triage`

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `eda_env.json` | `mcu-eda-env-setup` if available, or user-provided | Yes |
| RTL filelist (`filelist.f`) | User-provided or from RTL development stage | Yes |
| Sim filelist (`filelist_sim.f`) | User-provided or from TB development stage | Yes (for sim) |
| Change manifest | From RTL or TB development stage, if available | Recommended (for incremental) |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Compile log | `sim/compile.log` | Compiler output |
| Simulation log | `sim/sim.log` | Simulation output with pass/fail |
| Waveform | `sim/wave.fsdb` or equivalent | Waveform dump |
| Lint report | `rpt/lint_summary.rpt` | Static analysis results |
| Run record | `doc/run_record.json` | Structured result for downstream |

## Input Validation

Before running, verify required fields exist in upstream artifacts.

### From eda_env.json (produced by `mcu-eda-env-setup`)

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.simulator` | Not null, one of: vcs, xcelium | Compile and simulate command selection |
| `available_tools[]` entry for selected simulator | `path` is not null | Binary location |
| `selected_tools.lint` | Not null if lint run requested | Lint tool selection |
| `selected_tools.waveform` | Name (verdi/simvision/dve) or null | Waveform dump format |

### From filelist.f (produced by `mcu-rtl-development`)

| Required | What to check | Used for |
|---|---|---|
| File exists | `rtl/filelist.f` is present and non-empty | Compile command `-f` argument |

### From filelist_sim.f (produced by `mcu-tb-development`)

| Required | What to check | Used for |
|---|---|---|
| File exists | `sim/filelist_sim.f` is present and non-empty | Compile with TB files |
| References filelist.f | Contains `-f rtl/filelist.f` or equivalent | RTL inclusion |

### From change manifest (optional, produced by `mcu-rtl-development` or `mcu-tb-development`)

| Field | What to check | Used for |
|---|---|---|
| `mode` | "full" or "incremental" | Informational |
| `files_modified` | Array of file paths | Log annotation |
| `cascade` | Array of stage names | Determines if compile is needed |

If change manifest is missing, default to full compile.

## Workflow

### Step 1: Read environment

Read `eda_env.json` to determine:
- Selected simulator (VCS/Xcelium) and its binary path
- Selected lint tool (SpyGlass/Ascent)
- Waveform format (FSDB/SHM/VPD)
- Module load commands (if needed)

Read the tool's execution template from `references/` (e.g., `references/vcs-run.md`, `references/xcelium-run.md`) for exact command syntax.

### Step 2: Backup previous results

Before any run, back up existing logs and coverage:
```
sim/backup/<timestamp>/
  compile.log
  sim.log
  coverage data (if exists)
```

### Step 3: Compile

Construct compile command from the tool template:

**VCS example:**
```
vcs -full64 -sverilog -debug_access+all -f sim/filelist_sim.f \
    -o sim/simv -l sim/compile.log +lint=all,noVCDE -timescale=1ns/1ps
```

**Xcelium example:**
```
xrun -compile -sv -f sim/filelist_sim.f -l sim/compile.log
```

Execute the command. Check result:
- **Success**: `simv` exists (VCS) or no FATAL errors (Xcelium) → proceed to Step 4
- **Failure**: Compile errors → go to Step 6 (route to triage)

### Step 4: Simulate

Construct simulation command:

**VCS:**
```
./sim/simv +fsdbfile+sim/wave.fsdb -l sim/sim.log
```

**Xcelium:**
```
xrun -R -l sim/sim.log
```

Add test selection plusargs if running a specific test.

Execute. Parse result from log:
- **PASS**: Log contains `TEST_PASSED` or `SIM_PASS`
- **FAIL**: Log contains `TEST_FAILED` or `SIM_FAIL` or `UVM_FATAL`
- **TIMEOUT**: Simulation did not complete within expected time
- **UNKNOWN**: No clear pass/fail marker

### Step 5: Write run record

```json
{
  "timestamp": "...",
  "mode": "full | incremental | single_test | lint | cdc | regression",
  "compile": {
    "status": "pass | fail",
    "tool": "vcs",
    "log": "sim/compile.log",
    "errors": 0,
    "warnings": 12
  },
  "simulate": {
    "status": "pass | fail | timeout",
    "test": "test_gpio_basic",
    "log": "sim/sim.log",
    "waveform": "sim/wave.fsdb"
  },
  "routing": {
    "next": "mcu-verification-triage | next-stage",
    "reason": "compile clean, sim passed"
  }
}
```

### Step 6: Route result

| Result | Route to | Action |
|---|---|---|
| Compile PASS + Sim PASS | Next stage (synthesis or more tests) | Proceed |
| Compile PASS + Sim FAIL | `mcu-verification-triage` | Diagnose sim failure |
| Compile FAIL | `mcu-verification-triage` | Diagnose compile error |
| Lint fatals | `mcu-verification-triage` | Diagnose lint issues |

### Lint Workflow

If running lint instead of simulation:

**SpyGlass:**
1. Expand filelist into `read_file` lines (SpyGlass does not support `-f`)
2. Generate project file
3. Run: `spyglass -project <prj> -batch -goals "lint/lint_rtl"`
4. Parse summary: count fatals, errors, warnings

**Ascent:**
1. Run: `hal -f <filelist> -top <top> -goal lint`
2. Parse results

Lint result feeds into run record with `"mode": "lint"`.

### CDC Workflow

**SpyGlass CDC:**
1. Generate project file (same as lint, with CDC goal)
2. Add clock definitions if available from spec
3. Run: `spyglass -project <prj> -batch -goals "cdc/cdc_verify_struct,cdc/cdc_verify"`
4. Parse CDC violation count

CDC result feeds into run record with `"mode": "cdc"`.

### Regression Workflow

Used when multiple tests need to be run with coverage collection.

**Step R1: Compile with coverage**

**VCS:**
```
vcs -full64 -sverilog -debug_access+all -f sim/filelist_sim.f \
    -o sim/simv_cov -l sim/compile_cov.log \
    -cm line+cond+fsm+tgl+branch -timescale=1ns/1ps
```

**Xcelium:**
```
xrun -compile -sv -f sim/filelist_sim.f -l sim/compile_cov.log -coverage all
```

**Step R2: Run test list**

For each test in the test list (from `mcu-tb-development` output or user-specified):

```
# VCS: per-test with unique seed and log
./sim/simv_cov +testname=<test> +ntb_random_seed=<seed> \
    -cm line+cond+fsm+tgl+branch \
    -cm_dir sim/coverage/<test>_seed<seed>.vdb \
    -l sim/logs/<test>_seed<seed>.log

# Xcelium: per-test
xrun -R -svseed <seed> -coverage all \
    -covworkdir sim/coverage/<test>_seed<seed> \
    -l sim/logs/<test>_seed<seed>.log
```

If LSF is available (from `eda_env.json`), submit tests in parallel via `bsub`.
If LSF is unavailable, run tests sequentially.

**Step R3: Collect results**

Parse each test log for pass/fail/timeout. Build regression summary:

```json
{
  "mode": "regression",
  "timestamp": "...",
  "compile": {"status": "pass", "log": "sim/compile_cov.log"},
  "tests": [
    {"name": "test_gpio_basic", "seed": 1, "status": "pass", "log": "sim/logs/test_gpio_basic_seed1.log"},
    {"name": "test_uart_tx",    "seed": 1, "status": "fail", "log": "sim/logs/test_uart_tx_seed1.log"},
    {"name": "test_gpio_basic", "seed": 42, "status": "pass", "log": "sim/logs/test_gpio_basic_seed42.log"}
  ],
  "summary": {"total": 3, "pass": 2, "fail": 1, "timeout": 0},
  "coverage_dir": "sim/coverage/"
}
```

**Step R4: Merge coverage**

**VCS:**
```
urg -dir sim/coverage/*.vdb -dbname sim/coverage/merged.vdb -report sim/coverage/report
```

**Xcelium:**
```
imc -load sim/coverage/* -merge -out sim/coverage/merged
imc -load sim/coverage/merged -report -metrics all -out sim/coverage/report
```

**Step R5: Write regression run record**

Write `doc/regression_record.json` with the structure above. This is consumed by `mcu-regression-and-coverage` for failure clustering and coverage gap analysis.

### Route regression results

| Result | Route to | Action |
|---|---|---|
| All tests pass, coverage target met | Next stage (synthesis) | Proceed |
| Some tests fail | `mcu-regression-and-coverage` | Cluster failures, decide rerun scope |
| All pass but coverage gaps remain | `mcu-regression-and-coverage` | Analyze gaps, decide closure actions |
| Compile fail | `mcu-verification-triage` | Diagnose compile error |

## Auto-Diagnosis on Compile Failure

Before routing to triage, attempt quick auto-diagnosis:

| Pattern in compile.log | Likely cause | Auto-fixable? |
|---|---|---|
| `module not found` | Missing file in filelist | Check filelist, suggest addition |
| `port size mismatch` | Width inconsistency | Report exact ports and widths |
| `syntax error` | Typo or coding issue | Report file:line |
| VCS cache corruption | Stale csrc directory | Auto-fix: delete csrc/, recompile |
| ASLR re-execution | OS memory layout issue | Auto-fix: retry with `-no_save` |

If auto-fixable, retry once. If retry fails, route to triage.

## Bundled References

- [vcs-run.md](references/vcs-run.md) — VCS compile and simulate commands
- [xcelium-run.md](references/xcelium-run.md) — Xcelium compile and simulate commands
- [spyglass-run.md](references/spyglass-run.md) — SpyGlass lint execution
- [auto-diagnosis-patterns.md](references/auto-diagnosis-patterns.md) — compile error patterns and fixes
- [backup-policy.md](references/backup-policy.md) — what to backup before re-running
- [makefile_template.mk](scripts/makefile_template.mk) — templated Makefile for compile/sim/lint/coverage targets

## Completion Gate

- Compile log exists
- Simulation log exists with clear pass/fail/timeout status (if sim was run)
- Run record written with routing decision
- Previous results backed up
- If failure: routed to triage with structured diagnostic context

## Decision Rules

- Always back up before re-running. Never overwrite logs without backup.
- Read `eda_env.json` for tool selection. Do not hardcode tool names or paths.
- If change manifest from `mcu-rtl-development`/`mcu-tb-development` shows only internal logic changes, still do full recompile (incremental compile is unreliable for most EDA tools).
- Do not auto-fix RTL or TB code. Only auto-fix environment issues (cache, ASLR). Code fixes go through triage → gen loop.
- If simulation runs longer than 10x expected time, flag as anomaly but do not kill.
