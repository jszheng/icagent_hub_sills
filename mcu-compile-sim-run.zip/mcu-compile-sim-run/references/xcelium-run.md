# Xcelium Compile and Simulate Commands

## Compile

```
xrun -compile -sv \
     -f <filelist> \
     -l <sim_dir>/compile.log
```

### Optional flags

| Flag | Purpose |
|------|---------|
| `-access +rwc` | Enable waveform probing |
| `-coverage all` | Enable coverage collection |
| `+define+<MACRO>` | Define compile-time macro |
| `-top <module>` | Specify top module |
| `-timescale 1ns/1ps` | Set timescale |

### Compile success check

- `compile.log` does not contain `*F,` (fatal) or `*E,` (error) lines
- No `xrun: *F` messages

## Simulate

```
xrun -R -l <sim_dir>/sim.log
```

### Optional flags

| Flag | Purpose |
|------|---------|
| `-svseed <N>` | Set random seed |
| `-coverage all` | Collect coverage |
| `-input <tcl_file>` | Source TCL for waveform probing |

### Result detection

Same markers as VCS:

| Log pattern | Meaning |
|-------------|---------|
| `TEST_PASSED` or `SIM_PASS` | Simulation passed |
| `TEST_FAILED` or `SIM_FAIL` | Simulation failed |
| `UVM_FATAL` | UVM fatal error |

## Waveform dump (via TCL probe file)

```tcl
database -open waves.shm -default
probe -all -depth all
run
```

Invoke with: `xrun -R -input probe.tcl`

## Coverage report

```
imc -load cov_work/scope/test -report -metrics all -out coverage_txt
```

## Clean

```
rm -rf xcelium.d xrun.* *.log waves.shm cov_work coverage_txt .simvision
```
