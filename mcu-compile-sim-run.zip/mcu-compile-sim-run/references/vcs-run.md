# VCS Compile and Simulate Commands

## Compile

```
vcs -full64 -sverilog -debug_access+all \
    -f <filelist> \
    -o <sim_dir>/simv \
    -l <sim_dir>/compile.log \
    +lint=all,noVCDE \
    -timescale=1ns/1ps
```

### Optional flags

| Flag | Purpose |
|------|---------|
| `-kdb` | Enable Verdi KDB for waveform debug |
| `-cm line+cond+fsm+tgl+branch` | Enable coverage collection |
| `+define+<MACRO>` | Define compile-time macro |
| `-top <module>` | Specify top module explicitly |

### Compile success check

- `simv` executable exists in `<sim_dir>/`
- `compile.log` does not contain `Error-` lines (warnings are acceptable)

## Simulate

```
<sim_dir>/simv \
    +fsdbfile+<sim_dir>/wave.fsdb \
    -l <sim_dir>/sim.log
```

### Optional flags

| Flag | Purpose |
|------|---------|
| `+ntb_random_seed=<N>` | Set random seed |
| `+testname=<test>` | Select test by plusarg |
| `-cm line+cond+fsm+tgl+branch` | Collect coverage during simulation |
| `+fsdb+autoflush` | Flush waveform data periodically |

### Result detection

| Log pattern | Meaning |
|-------------|---------|
| `TEST_PASSED` or `SIM_PASS` | Simulation passed |
| `TEST_FAILED` or `SIM_FAIL` | Simulation failed |
| `UVM_FATAL` | UVM fatal error |
| `$finish` without pass marker | Inconclusive |

## Coverage report

```
urg -dir simv.vdb -format text -report coverage_txt
```

## Clean

```
rm -rf simv csrc simv.daidir *.log *.fsdb novas.* *.vdb coverage_txt ucli.key
```
