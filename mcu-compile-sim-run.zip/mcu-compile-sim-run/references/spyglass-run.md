# SpyGlass Lint and CDC Commands

## Filelist handling

SpyGlass does not support VCS-style `-f filelist`. Expand filelist into individual `read_file` lines in a project file.

### Expansion rules

1. Read `filelist.f` line by line
2. Skip lines starting with `+` or `-` (VCS options)
3. Strip `//` comments
4. Recursively expand nested `-f <file>` includes
5. Convert each remaining line to: `read_file -type verilog <path>`

## Lint run

### Project file format

```
set_option projectwdir <rpt_dir>
set_option top <top_module>
read_file -type verilog <file1.v>
read_file -type verilog <file2.v>
...
```

### Execute

```
spyglass -project <project_file> -batch -goals "lint/lint_rtl"
```

### Result parsing

Parse summary line: `Reported Messages: N Fatals, N Errors, N Warnings`

| Count | Meaning |
|-------|---------|
| 0 fatals | Lint pass (errors from black-box analysis are tolerated) |
| 1+ fatals | Lint fail |

## CDC run

### Project file additions

```
set_option constraint_mode estimate
current_goal cdc/cdc_verify_struct
```

### Execute

```
spyglass -project <project_file> -batch -goals "cdc/cdc_verify_struct,cdc/cdc_verify"
```

### Result parsing

Same summary format. Check for CDC-specific violations.

## Clean

```
rm -rf spyglass_reports sg_work *.log .spyglass
```
