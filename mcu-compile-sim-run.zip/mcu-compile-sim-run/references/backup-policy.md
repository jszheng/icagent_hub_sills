# Backup Policy

## When to Backup

| Scenario | Action |
|----------|--------|
| First run, no previous logs | No backup needed |
| Re-run after code change | Backup previous logs |
| Re-run same code (retry) | Backup previous logs |

## What to Backup

```
sim/backup/<YYYY-MM-DD_HH-MM-SS>/
  compile.log
  sim.log
  coverage data (if exists)
```

## What NOT to Backup

- `simv` / `csrc` / `simv.daidir` (too large, recompilable)
- `xcelium.d` (too large, recompilable)
- Waveform dumps (too large, regenerable)

## Rules

- Never delete backup directories
- Timestamp format: `YYYY-MM-DD_HH-MM-SS`
- If backup fails, stop and report. Do not overwrite without successful backup.
