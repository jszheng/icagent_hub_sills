# Auto-Diagnosis Patterns

Patterns to detect in compile/simulation logs before routing to full triage.

## Compile Errors

| Log pattern | Likely cause | Auto-fixable? | Fix |
|---|---|---|---|
| `module '<name>' not found` | Missing file in filelist | Suggest | Check if .v file exists, suggest filelist update |
| `port size mismatch` | Width inconsistency | No | Report exact module, port, expected vs actual width |
| `syntax error near` | Typo or coding error | No | Report file:line:column |
| `Identifier '<name>' has not been declared` | Missing signal declaration | No | Report signal name and module |
| `csrc/` corruption (VCS) | Stale compile cache | Yes | Delete csrc/ simv.daidir, recompile |
| `ASLR re-execution` (VCS) | OS memory layout | Yes | Retry with -no_save flag |
| `illegal rand` | rand on wrong type | No | Report variable and suggest removing rand |

## Simulation Errors

| Log pattern | Likely cause | Auto-fixable? | Fix |
|---|---|---|---|
| `TEST_FAILED` | Test assertion failure | No | Route to triage with failure context |
| `TEST_TIMEOUT` | Simulation hung | No | Report timeout cycle count |
| `UVM_FATAL` | UVM framework error | No | Report UVM message |
| No pass/fail marker | Missing test verdict | No | Report as UNKNOWN result |
| `$finish called` without TEST_PASSED | Incomplete test | No | Report last $display before $finish |

## Auto-Fix Protocol

1. Detect pattern in log
2. If auto-fixable: apply fix, retry ONCE
3. If retry succeeds: report success
4. If retry fails or not auto-fixable: route to `mcu-verification-triage` with structured context
