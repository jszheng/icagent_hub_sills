# {{GENERATED_BY}}
# Simulation Makefile — generated from makefile_template.mk
# Simulator: {{SIMULATOR}}
# Do not edit manually — regenerate via mcu-compile-sim-run skill

#--------------------------------------------------------------
# Tool Commands (filled from eda_env.json + tool references)
#--------------------------------------------------------------
COMPILE_CMD     = {{COMPILE_CMD}}
COMPILE_COV_CMD = {{COMPILE_COV_CMD}}
RUN_CMD         = {{RUN_CMD}}
RUN_COV_CMD     = {{RUN_COV_CMD}}
COV_REPORT_CMD  = {{COV_REPORT_CMD}}
LINT_CMD        = {{LINT_CMD}}
CDC_CMD         = {{CDC_CMD}}
WAVE_CMD        = {{WAVE_CMD}}
CLEAN_CMD       = {{CLEAN_CMD}}

#--------------------------------------------------------------
# Project
#--------------------------------------------------------------
SIM_FLIST = sim/filelist_sim.f
TOP       = {{TOP_MODULE}}
SEED     ?= random
LOG_DIR   = sim/logs
BACKUP_DIR = sim/backup

#--------------------------------------------------------------
# Targets
#--------------------------------------------------------------
.PHONY: compile compile_cov sim sim_cov regression lint cdc wave coverage backup clean help

compile:
	$(COMPILE_CMD)

compile_cov:
	$(COMPILE_COV_CMD)

sim:
	$(RUN_CMD) $(if $(SEED),{{SEED_FLAG}}$(SEED))

sim_cov:
	$(RUN_COV_CMD) $(if $(SEED),{{SEED_FLAG}}$(SEED))

lint:
	$(LINT_CMD)

cdc:
	$(CDC_CMD)

wave:
	$(WAVE_CMD)

coverage:
	$(COV_REPORT_CMD)

backup:
	@timestamp=$$(date +%Y-%m-%d_%H-%M-%S); \
	mkdir -p $(BACKUP_DIR)/$$timestamp; \
	for f in sim/*.log $(LOG_DIR)/*.log; do \
		[ -f "$$f" ] && cp "$$f" $(BACKUP_DIR)/$$timestamp/; \
	done; \
	echo "Backed up to $(BACKUP_DIR)/$$timestamp"

clean:
	$(CLEAN_CMD)

help:
	@echo "Targets:"
	@echo "  compile      - Compile RTL + TB"
	@echo "  compile_cov  - Compile with coverage"
	@echo "  sim          - Run simulation (SEED=random)"
	@echo "  sim_cov      - Run simulation with coverage"
	@echo "  lint         - Run lint check"
	@echo "  cdc          - Run CDC check"
	@echo "  wave         - Open waveform viewer"
	@echo "  coverage     - Generate coverage report"
	@echo "  backup       - Backup logs"
	@echo "  clean        - Remove generated products"
