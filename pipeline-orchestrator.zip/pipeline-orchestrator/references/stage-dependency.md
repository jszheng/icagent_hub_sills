# Stage Dependency Graph

## Execution Order (Sequential)

```
input_config.json
       │
       ▼
   1. spec-to-testplan
       │  产出: docs/spec_analysis.json
       │        docs/fsm_analysis.json
       │        docs/testplan.json
       ▼
   2. uvm-env-build
       │  产出: uvm_tb/*.sv
       │        sim/flist
       ▼
   3. testcase-build
       │  产出: uvm_tb/*_tests.sv
       │        uvm_tb/*_test_vseqs.sv
       │        sim/testname.f
       ▼
   4. assertion-build
       │  产出: uvm_tb/*_property.sv
       │        uvm_tb/*_bind.sv
       ▼
   5. simulator-setup          （infrastructure，pipeline_status 中无 stage 编号）
       │  产出: sim/Makefile
       │  （需要 sim/flist 已存在）
       ▼
   6. run-and-debug            （= Stage 5 in pipeline_status）
       │  执行: make compile + make run
       │  分析: compile.log + sim.log
       ▼
   7. regression               （= Stage 6 in pipeline_status）
       │  执行: 遍历 testname.f 跑全量
       │  产出: docs/regression_results.json
       ▼
   8. coverage-closure         （= Stage 7 in pipeline_status）
       │  执行: make coverage + 迭代闭环
       │  产出: uvm_tb/*_coverage.sv
       │        uvm_tb/*_closure_tests.sv (if generated)
       │        docs/coverage_triage.json
       │        docs/coverage_report.md
```

## Resume from Stage N

Pipeline can resume from any stage if prior outputs exist:

| Resume from | Requires these files exist |
|-------------|--------------------------|
| stage1 | `input_config.json` |
| stage2 | `docs/spec_analysis.json` |
| stage3 | `docs/testplan.json`, `uvm_tb/*_base_test.sv`, `uvm_tb/*_vseq_base.sv` |
| stage4 | `docs/spec_analysis.json`, `docs/fsm_analysis.json` |
| simulator-setup | `input_config.json`, `sim/flist` |
| stage5 | `sim/Makefile`, `uvm_tb/*.sv`, `sim/flist` |
| stage6 | `simv`, `sim/testname.f` |
| stage7 | `coverage.vdb` |

## Error Handling

```
Stage fails
  → Generate escalation_report.json
  → Pause pipeline
  → User reviews and fixes
  → Resume from failed stage
```
