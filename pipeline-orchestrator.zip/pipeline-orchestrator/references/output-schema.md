# Pipeline Orchestrator Output Schema

## pipeline_status.json

```json
{
  "design_name": "string",
  "simulator": "string",
  "simulator_version": "string — from check_command output",
  "start_time": "ISO-8601",
  "stages": {
    "stage1": {
      "status": "PASS | FAIL | SKIP | NOT_RUN",
      "start_time": "ISO-8601",
      "end_time": "ISO-8601",
      "outputs": ["string — file paths produced"],
      "errors": ["string — error messages if FAIL"]
    },
    "stage2": { "..." },
    "stage3": { "..." },
    "stage4": { "..." },
    "stage5": { "..." },
    "stage6": { "..." },
    "stage7": { "..." }
  },
  "makefile": {
    "generated_from": "string — simulator template file path",
    "simulator": "string",
    "path": "sim/Makefile"
  },
  "current_stage": "string — stage currently executing or last completed",
  "overall_status": "IN_PROGRESS | COMPLETE | BLOCKED",
  "blocked_reason": "string | null"
}
```
