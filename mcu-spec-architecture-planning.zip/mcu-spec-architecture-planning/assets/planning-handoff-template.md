# Spec & Architecture Handoff

## Architecture summary

1-3 sentences describing the design: CPU core, bus architecture, peripheral set, target process/frequency/power. This is the "elevator pitch" for downstream engineers.

## Memory and interrupt decisions

Summarize the finalized memory map and interrupt map. Reference `doc/spec.md` sections for full detail. Call out any decisions that were made during this stage (e.g., "GPIO at 0x4000_0000 per ARM convention" or "UART interrupt split into TX and RX per user confirmation").

## Clock and reset assumptions

State the clock and reset architecture that downstream RTL and verification will rely on:
- Primary clock name and frequency
- Reset polarity and synchronization strategy
- Any clock gating or power domain decisions

## Module ownership notes

List which modules will be implemented vs. which are black-box IP. For each implemented module, note the responsible directory (e.g., `rtl/peripheral/gpio.v`).

## Open questions

Bullet list of items that are **not yet resolved** and may affect downstream stages. For each:
- What is unclear
- What stage is blocked until resolved
- Suggested owner (user, IP vendor, spec author)

## Recommended next skill

State which skill should be invoked next (typically `mcu-rtl-development` for full generation, or a specific stage skill if resuming mid-flow). Note any prerequisites that must be met first.
