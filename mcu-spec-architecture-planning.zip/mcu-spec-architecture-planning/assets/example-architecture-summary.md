## Scope and sources

- Product target: low-power Cortex-M3 MCU for control-heavy embedded use
- CPU core source: protected Cortex-M3 integration note
- Supporting sources: peripheral list draft, clock/reset note, memory-map scratch table

## CPU integration assumptions

- Cortex-M3 is integrated through a wrapper that normalizes clocks, reset, debug, and interrupt fan-in
- CPU instruction/data access shares a system interconnect entry point
- Debug path exists but may remain lightly documented in stage 1

## Memory map draft

| Region | Base | Size | Notes |
| --- | --- | --- | --- |
| Boot ROM | `0x0000_0000` | 64 KB | reset vector space |
| SRAM | `0x2000_0000` | 128 KB | main data memory |
| APB peripherals | `0x4000_0000` | 1 MB window | GPIO, UART, timer, sysctrl |
| Reserved expansion | `0x5000_0000` | 1 MB window | future peripherals |

## Interrupt map draft

| IRQ | Source | Notes |
| --- | --- | --- |
| 0 | GPIO | edge/level behavior to confirm |
| 1 | UART RX/TX | combine or split per final peripheral design |
| 2 | Timer | periodic and one-shot modes |
| 3 | System fault | reserved for safety or watchdog path |

## Clock, reset, and power notes

- One primary system clock
- Optional divided peripheral clock
- Async assert, sync release reset strategy assumed unless contradicted
- Low-power gating intent should remain visible because it affects synthesis and verification later

## Module partitioning

- `rtl/core/` CPU wrapper and core-facing glue
- `rtl/bus/` interconnect and decode
- `rtl/peripheral/` GPIO, UART, timer, sysctrl
- `rtl/clk_rst/` clock/reset and control plumbing
- `rtl/memory/` SRAM or memory controller logic
- `rtl/top/` top-level assembly

## Open questions and next step

- Confirm exact APB/AHB split at the bus boundary
- Confirm debug visibility requirements
- Confirm whether UART interrupt is shared or separated
- Next step: `mcu-rtl-development`
