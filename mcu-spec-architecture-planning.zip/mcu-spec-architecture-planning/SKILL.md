---
name: mcu-spec-architecture-planning
description: Generate or update the specification and architecture documents for an MCU SoC design. Use when the user needs to define or review memory map, interrupts, clock and reset strategy, module partitioning, and produce spec.md and architecture.md as engineering deliverables for downstream RTL and verification.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Spec Architecture Planning

Use this skill to convert design intent into written specification and architecture documents, or to update existing documents when requirements change.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** generate RTL code. (Companion skill: `mcu-rtl-development`)
- Do **not** generate testbenches. (Companion skill: `mcu-tb-development`)
- Do **not** generate SDC constraints. (Companion skill: `mcu-synthesis-planning`)
- Do **not** execute EDA tools.

## Two Modes

### Full Generation Mode

Triggered when: product intent exists but no spec.md or architecture.md has been written yet.

### Update Mode

Triggered when: spec.md or architecture.md already exist and a requirement change, peripheral addition, or review finding requires targeted updates.

## Good Outcome

Produce:

- `doc/spec.md` — complete chip specification with all sections needed by downstream skills
- `doc/architecture.md` — detailed architecture with bus topology, interface definitions, integration notes
- project directory structure (if not already present)
- change manifest (if update mode)

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| Product intent / feature list | Customer or product team | Yes |
| CPU core interface definition | IP vendor datasheet or RTL header | Yes |
| Target process, frequency, power | Customer | Recommended |
| Existing spec.md | Previous run of this skill or user-provided | Yes (update mode) |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Specification | `doc/spec.md` | Complete chip spec |
| Architecture | `doc/architecture.md` | Detailed architecture doc |
| Directory structure | `rtl/`, `tb/`, `sim/`, `scripts/`, `sdc/`, `output/`, `rpt/`, `doc/` | Project directories |
| Change manifest | `doc/spec_changes.json` | Sections created/modified (update mode) |

## Input Validation

### From user/customer inputs (full generation mode)

| Required input | What to check | Used for |
|---|---|---|
| Product intent or feature list | At least one functional requirement stated | Peripheral list, module partitioning |
| CPU core identification | Core name and bus protocol (e.g. AHB-Lite) | CPU wrapper, bus architecture |
| CPU interface definition | Port list or datasheet reference | Wrapper port mapping, interrupt width |
| Target frequency | Numeric value in MHz | Clock architecture, SDC downstream |
| Target power budget | Numeric value in mW (if available) | Power intent notes |
| Process node | Node name (if available) | Architecture decisions |

If CPU interface details are unclear, read the core's RTL header file or datasheet directly rather than assuming port names.

### From existing spec.md (update mode)

| Required | What to check | Used for |
|---|---|---|
| `doc/spec.md` exists | File is readable | Base for incremental update |
| Sections present | At least project overview and memory map exist | Knowing what to preserve vs update |

## Workflow — Full Generation

### Step 0: Safety gate (mandatory)

Before generating spec.md or architecture.md:

1. Check whether `doc/spec.md` or `doc/architecture.md` already exist.
2. If they do, **stop** and ask the user whether to overwrite (switch to Full Generation) or update specific sections (switch to Update Mode).
3. If neither exists, proceed with full generation.

### Step 1: Gather inputs

Read all available design intent:
- Product requirements or feature list
- CPU core datasheet or RTL header (extract port list, bus protocol, interrupt width)
- Target process node, frequency, power budget, supply voltage
- Reference designs or prior SoC material (if available)

### Step 2: Generate doc/spec.md

Write `doc/spec.md` with the following sections. Every section must contain concrete values, not placeholders.

**Project overview**
- Design name, process node, target frequency, power budget, supply voltage
- Top-level block list

**System block diagram**
- ASCII diagram showing: CPU core → bus interconnect → slave peripherals
- Label each connection with bus type (AHB/APB/AXI)

**Memory map**
- Table with columns: Base address, End address, Size, Peripheral name, Bus type
- Verify no address overlaps
- Include default slave region for unmapped addresses

**Clock architecture**
- Primary clock: name, frequency, source port
- Derived clocks: name, source, divider ratio, gating conditions
- Clock domain grouping (for CDC analysis)
- Clock gating strategy

**Reset architecture**
- Reset signal name, active polarity
- Async assert, sync deassert pattern
- Reset tree: which blocks get which reset
- Power-on reset sequence

**Interrupt map**
- Table with columns: IRQ number, Source peripheral, Trigger type (level/edge), Description
- CPU interrupt port width and connection

**Peripheral list**
- Per peripheral: name, bus interface (AHB/APB), base address, register list
- Per register: name, offset, width, reset value, access type (R/W/RO/W1C/WO)

**Module list**
- All RTL modules to be implemented
- Hierarchy: top → subsystem → leaf
- Black box modules (CPU core, hard IP)

### Step 3: Generate doc/architecture.md

Write `doc/architecture.md` with:

**Bus architecture**
- Interconnect topology: how many masters, how many slaves
- Address decode logic description
- AHB-to-APB bridge (if mixed bus)
- Default slave behavior

**CPU wrapper specification**
- CPU core module name (black box)
- Wrapper port mapping: CPU ports → SoC-level ports
- AHB master connection
- Debug interface connection (JTAG/SWD)

**Peripheral interface details**
- Per peripheral: bus interface signals, register access timing, interrupt generation logic

**Clock and reset implementation notes**
- Clock gating cell usage
- Reset synchronizer structure
- Power domain boundaries (if any)

**Integration checklist**
- Signal naming conventions
- Bus protocol compliance requirements
- Lint/CDC analysis expectations

### Step 4: Create project directory structure

If directories do not exist, create:
```
rtl/top/  rtl/core/  rtl/bus/  rtl/peripheral/  rtl/clk_rst/  rtl/memory/
tb/  sim/  scripts/  sdc/  output/syn/  output/pnr/  output/gds/  rpt/  doc/
```

### Step 5: Validate completeness

Check that spec.md contains all sections required by downstream skills:

| Section | Required by |
|---------|-------------|
| Memory map (base address, size, no overlaps) | RTL development (address decoder) |
| Peripheral register map (offset, width, reset, access) | RTL development (register file), TB development (checker) |
| Clock domains (name, frequency, port) | RTL development, TB development, synthesis |
| Reset strategy (polarity, sync/async) | RTL development, TB development |
| Interrupt map (IRQ number, source, trigger) | RTL development (interrupt routing), TB development (interrupt test) |
| CPU interface (ports, protocol) | RTL development (CPU wrapper) |
| Bus architecture (type, topology) | RTL development (interconnect) |
| Module list (hierarchy, black boxes) | RTL development (file structure) |

If any section is missing or incomplete, flag it as an open question rather than guessing.

## Workflow — Update Mode

### Step 1: Read existing spec.md and architecture.md

Understand current content and structure.

### Step 2: Identify what changed

From user request or review finding, determine:
- Which sections need modification
- Is it an addition (new peripheral), change (different address), or removal?

### Step 3: Apply targeted update

Modify only the affected sections. Ensure consistency:
- If a peripheral address changes, update memory map AND peripheral section
- If a new peripheral is added, update memory map, interrupt map, peripheral list, module list
- If clock domain changes, update clock architecture AND CDC notes

### Step 4: Write change manifest

```json
{
  "mode": "update",
  "timestamp": "...",
  "sections_modified": ["memory_map", "peripheral_list", "interrupt_map"],
  "reason": "Added SPI peripheral",
  "cascade": ["rtl_gen", "tb_gen", "synthesis"]
}
```

### Step 5: Back up previous version

```
cp doc/spec.md backup/<timestamp>/doc/spec.md
cp doc/architecture.md backup/<timestamp>/doc/architecture.md
```

## Bundled References

- [architecture-output-template.md](references/architecture-output-template.md) — section structure template
- [planning-handoff-template.md](assets/planning-handoff-template.md) — handoff format
- [example-architecture-summary.md](assets/example-architecture-summary.md) — example output
- [sample-memory-interrupt-map.json](assets/sample-memory-interrupt-map.json) — structured map example

## Completion Gate

Full generation:
- `doc/spec.md` exists with all 8 required sections populated with concrete values
- `doc/architecture.md` exists with bus, wrapper, and integration details
- Project directory structure created
- No unresolved placeholders (open questions are explicitly listed, not hidden)

Update mode:
- Affected sections updated consistently
- Previous version backed up
- Change manifest written with cascade scope

## Spec Quality Rules

### Memory map and interrupt checklist

- Each peripheral must have one clear base address range with no overlaps
- Address ranges must be naturally aligned to their size
- Interrupt ownership must be unambiguous (one source per IRQ number)
- Reserved address ranges and expansion headroom must be called out
- Separate hard facts from placeholder allocations — mark provisional entries explicitly

### Ambiguity handling

- If intent is missing but the stage can still produce a useful draft, mark the result as provisional
- If memory, reset, or interrupt behavior is ambiguous, keep the ambiguity visible — later stages depend on these decisions
- Do not invent fixed addresses, clock ratios, or reset sequencing unless the user asked for a proposal

### Interrupt architecture patterns

- Make interrupt ownership explicit early — shared vs dedicated IRQ per peripheral
- Separate source generation, masking, pending-state behavior, and clear mechanism in the spec
- Flag shared versus split interrupt behavior because it changes both RTL and verification planning
- For each IRQ, specify: trigger type (edge/level), clear mechanism (W1C/auto-clear/software poll), and priority

## Decision Rules

- Expected behavior comes from product intent and spec, not from accidental RTL convention.
- Prefer explicit open questions over hidden assumptions.
- If the CPU core interface is unclear, read the RTL header or datasheet directly rather than guessing port names.
- If a memory map conflict is detected, flag it immediately rather than silently resolving.
- All register definitions must include reset values — if not provided, ask rather than default to 0.
- Back up existing docs before overwriting.
