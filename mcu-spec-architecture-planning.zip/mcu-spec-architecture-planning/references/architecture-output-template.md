# Architecture Output Template

## Scope and sources

State the design target (e.g., "low-power Cortex-M3 MCU for embedded control") and list all input sources used (product requirements doc, CPU datasheet, prior design notes). This establishes traceability.

## CPU integration assumptions

Describe how the CPU core is integrated:
- Core module name (black box)
- Bus protocol (AHB-Lite / AXI)
- Wrapper strategy (what the wrapper normalizes: clocks, reset, debug, interrupt fan-in)
- Any assumptions about CPU behavior that downstream RTL depends on

## Memory map draft

| Region | Base | End | Size | Bus | Notes |
|--------|------|-----|------|-----|-------|
| Boot ROM | 0x0000_0000 | ... | ... | AHB | Reset vector space |
| ... | ... | ... | ... | ... | ... |

Requirements:
- No overlapping address ranges
- Include default slave region for unmapped addresses
- Base addresses must be naturally aligned to region size
- Note any provisional allocations that need user confirmation

## Interrupt map draft

| IRQ | Source | Trigger | Clear mechanism | Notes |
|-----|--------|---------|-----------------|-------|
| 0 | GPIO | Edge/Level | W1C | ... |
| ... | ... | ... | ... | ... |

Requirements:
- Each IRQ has unambiguous ownership (one source per IRQ number)
- Specify trigger type (edge vs level) — this affects RTL and TB
- Specify clear mechanism (W1C, auto-clear, software poll)
- Flag any shared or split interrupt decisions that are still open

## Clock, reset, and power notes

- Primary clock: name, frequency, source
- Derived clocks: divider ratio, gating conditions
- Clock domain list (for CDC analysis downstream)
- Reset: signal name, polarity, async assert / sync deassert
- Reset tree: which domains get which reset
- Power intent: clock gating strategy, power domains (if any)

## Module partitioning

List all RTL modules to be implemented with hierarchy:

| Module | Directory | Hierarchy | Description |
|--------|-----------|-----------|-------------|
| cortex_m3_wrapper | rtl/core/ | mid | CPU black-box wrapper |
| ... | ... | ... | ... |

Include black-box modules (CPU core, hard IP) and mark them as such.

## Open questions and next step

Bullet list of unresolved items. For each:
- What is unclear
- Who needs to decide (user, spec owner, IP vendor)
- What downstream stage is blocked until resolved

State the recommended next step (which stage/skill to proceed to).
