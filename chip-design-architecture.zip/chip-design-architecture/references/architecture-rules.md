# Architecture Rules Reference

This file preserves the original plugin logic while reorganizing it for standalone skill reuse.

## Stage Sequence

`spec_analysis -> arch_exploration -> perf_modelling -> power_area_estimation -> risk_assessment -> arch_signoff`

## Loop-back Rules

- `perf_modelling` fail because throughput misses target -> `arch_exploration` (max 3x)
- `power_area_estimation` fail because power or area exceeds budget -> `arch_exploration` (max 2x)
- `risk_assessment` has unmitigated high risks -> stay in `risk_assessment` (max 2x)
- `arch_signoff` fail because of spec coverage gap -> `spec_analysis` (max 1x)
- `arch_signoff` fail because of PPA gap -> `arch_exploration` (max 2x)

## Stage Rules

### spec_analysis
- classify every requirement: functional, performance, power, area, interface, safety/security
- identify under-specified areas and raise open questions
- map use cases to datapath, control, memory, and IO blocks
- extract all interface protocols and bandwidth requirements
- identify safety or security obligations
- assign priority: must-have, should-have, nice-to-have

**QoR focus**
- all spec sections mapped
- ambiguities recorded explicitly
- interfaces named with protocol and bandwidth

### arch_exploration
- generate at least 3 candidates: conservative, balanced, aggressive
- compare pipeline depth, parallelism, cache hierarchy, interconnect, and IP reuse
- document assumptions for each candidate
- produce a trade-off matrix with one recommended option

**QoR focus**
- at least 3 genuinely distinct candidates
- performance estimate within reasonable range of targets
- one recommendation with quantitative justification

### perf_modelling
- start with analytical models when possible
- use Python, TLM, or gem5 when needed
- model compute, memory, and IO bottlenecks
- sweep important parameters and validate against representative workloads
- include best / typical / worst cases

**QoR focus**
- throughput meets target with margin
- latency meets worst-case target
- bandwidth assumptions do not exceed fabric limits
- modelling confidence is stated explicitly

### power_area_estimation
- use technology scaling data and compiler-backed memory estimates where possible
- dynamic power should be activity-based
- leakage should be estimated separately
- apply realistic design margin
- flag any estimate above 80 percent of budget

**QoR focus**
- area below 80 percent of budget before RTL margin is consumed
- dynamic power below 80 percent of budget
- leakage remains a controlled fraction of total power
- confidence level is stated

### risk_assessment
- cover schedule, feasibility, IP, tool, verification, closure, and yield risks
- score each risk as probability × impact
- any score >= 15 is high risk and needs mitigation before sign-off
- every risk needs an owner

**QoR focus**
- no unmitigated high risks
- mitigation and ownership complete
- schedule risk tied to team capacity and plan realism

### arch_signoff
Sign off only when:
- all must-have requirements are addressed
- performance targets are met with margin
- power and area are within budget
- high risks are mitigated
- interfaces, memory map, clock/reset strategy, DFT strategy, and verification strategy are defined
- the RTL team has a usable handoff package

## Tool Guidance

### Open-source options
- `gem5` for microarchitectural exploration
- `mcpat` for power / area estimation
- `cacti` for memory estimation
- Python-based estimation scripts for quick studies

### Commercial (optional)
- Synopsys Platform Architect
- ARM Performance Models
- Cadence VSP

### Execution
Run tools via Bash. Refer to `tool-config.json` for user-confirmed tool selections; if not configured, detect via `which` and ask user to confirm before use.

## Memory Guidance

Read architecture knowledge before the first stage. On flow termination, append or update one experience record with:
- selected architecture
- estimated frequency
- estimated area
- issues encountered
- fixes applied
- sign-off status

## Standalone Skill Packaging Guidance

In this converted skill:
- the lightweight workflow lives in `SKILL.md`
- domain rules and thresholds live here
- durable lessons live in `references/knowledge.md`
- cross-run QoR analysis lives in `scripts/qor_trends.py`
