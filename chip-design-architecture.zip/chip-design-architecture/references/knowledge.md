# Architecture Knowledge

## Known Failure Patterns

- **Incomplete spec leads to high schedule risk**: when `risk_assessment` goes high on schedule, the real problem is often missing corner-case requirements rather than a bad architecture candidate. Clarify the spec before iterating architecture again.
- **Raw McPAT area numbers are not sign-off quality**: without technology calibration they can be off by roughly thirty percent. Always apply a known scaling factor or explicit uncertainty.
- **gem5 OOO branch predictor defaults can mislead IPC estimates**: for deeply embedded workloads, default predictor settings often need tuning before throughput claims are credible.

## Successful Tool Flags

### Open-source (recommended — all tools in this domain are open-source)

- `gem5` in-order `MinorCPU` models are often good first-pass predictors for in-order pipelines.
- `mcpat --inorder` is more appropriate for in-order designs than the default out-of-order assumptions.
- `cacti -cache_size <N> -block_size <B> -associativity <A>` should specify all key memory parameters explicitly.

## Tool / Environment Quirks

### Commercial (optional)

- **Platform Architect** can appear to hang when the license path is wrong. Check `LM_LICENSE_FILE` and the license server first.
- **Cadence VSP** can fail on TLM model import if the shared library ABI does not match the runtime compiler ABI.

## Usage Guidance

Treat these items as priors, not as substitutes for current project evidence. When a new project contradicts them, record the contradiction rather than silently deleting the old guidance.
