# Architecture Flow Reference

This reference keeps the broader flow narrative from `docs/Architecture_Evaluation_Flow.md` available inside the standalone skill.

## Flow Overview

Input:
- product spec
- performance targets
- power budget
- area budget
- technology assumptions
- representative use cases

Output:
- microarchitecture document
- validated trade-off decision
- RTL handoff package

## Shared State Shape

Typical state tracks:
- design name
- stage status objects
- selected architecture
- trade-off matrix
- overall flow status

## Representative Output Sections

A final microarchitecture document usually includes:
1. design overview
2. block diagram
3. performance summary vs targets
4. power and area summary vs budget
5. block descriptions
6. clock domain architecture
7. reset architecture
8. memory map
9. interface specifications
10. DFT strategy
11. verification strategy
12. risk register summary
13. open items

## Why this file exists

The main `SKILL.md` stays short so it triggers well and remains reusable. This file keeps the larger architecture-flow context available on demand.
