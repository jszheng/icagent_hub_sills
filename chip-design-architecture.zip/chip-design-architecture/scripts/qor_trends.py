#!/usr/bin/env python3
"""
qor_trends.py — Cross-design QoR metric trending for digital chip design agents.

Reads memory/<domain>/experiences.jsonl files and produces a QoR trend table
(and optional matplotlib chart) for a named design across runs.

Usage:
    python3 scripts/qor_trends.py --design <name> [options]

Options:
    --design  NAME      Design name to filter (required)
    --domain  DOMAIN    Limit to one domain (default: all domains)
    --metric  FIELD     Specific metric field to plot (default: all numeric)
    --plot              Emit a matplotlib chart (requires matplotlib)
    --output  FILE      Save chart to FILE instead of displaying (implies --plot)
    --memory-root PATH  Path to the memory/ directory (default: auto-detect)
    --min-runs N        Minimum runs required to include a domain (default: 2)
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

VALID_DOMAINS = [
    "architecture", "compiler", "dft", "firmware", "formal", "fpga",
    "hls", "pd", "rtl-design", "soc", "sta", "synthesis", "verification",
]

NUMERIC_METRICS = {
    "architecture": ["estimated_mhz", "estimated_area_um2"],
    "compiler": ["regression_pass_rate"],
    "dft": ["scan_coverage_pct", "atpg_fault_coverage_pct"],
    "firmware": ["flash_size_kb"],
    "formal": ["proved", "failed", "unknown"],
    "fpga": ["lut_count", "fmax_mhz"],
    "hls": ["latency_cycles", "dsp_count"],
    "pd": ["wns_ns", "drc_violations", "lvs_errors", "gds_area_um2"],
    "rtl-design": ["lint_errors", "cdc_violations"],
    "soc": ["ip_blocks_integrated", "memory_map_conflicts"],
    "sta": ["setup_wns_ns", "hold_wns_ns", "tns_ns", "failing_paths"],
    "synthesis": ["wns_ns", "cells", "area_um2", "lec_unmatched"],
    "verification": ["functional_coverage_pct", "regression_failures", "assertions_triggered"],
}

HIGHER_IS_BETTER = {
    "estimated_mhz", "fmax_mhz", "isa_tests_passed", "regression_pass_rate",
    "scan_coverage_pct", "atpg_fault_coverage_pct", "bsp_tests_passed",
    "proved", "ip_blocks_integrated", "functional_coverage_pct",
    "ii_achieved", "timing_met", "abi_compliant", "simulation_pass",
    "synth_check_pass", "build_pass", "wns_ns", "setup_wns_ns", "hold_wns_ns", "tns_ns",
}


def find_memory_root(script_path: Path) -> Path:
    candidate = script_path.resolve().parent
    for _ in range(5):
        mem = candidate / "memory"
        if mem.is_dir():
            return mem
        candidate = candidate.parent
    raise FileNotFoundError("Could not locate memory/ directory. Use --memory-root to specify it explicitly.")


def load_domain_records(memory_root: Path, domain: str) -> list[dict]:
    jsonl = memory_root / domain / "experiences.jsonl"
    if not jsonl.exists():
        return []
    records = []
    with jsonl.open("r", encoding="utf-8") as fh:
        for lineno, raw in enumerate(fh, 1):
            raw = raw.strip()
            if not raw:
                continue
            try:
                obj = json.loads(raw)
            except json.JSONDecodeError:
                print(f"  [warn] {domain}: malformed JSON on line {lineno}, skipping", file=sys.stderr)
                continue
            if isinstance(obj, dict):
                records.append(obj)
    return records


def filter_by_design(records: list[dict], design_name: str) -> list[dict]:
    name_lower = design_name.lower()
    return [r for r in records if isinstance(r.get("design_name"), str) and r["design_name"].lower() == name_lower]


def extract_series(records: list[dict], domain: str, metric_filter: str | None) -> dict[str, list[tuple[str, float]]]:
    fields = NUMERIC_METRICS.get(domain, [])
    if metric_filter:
        fields = [f for f in fields if f == metric_filter]
    series = defaultdict(list)
    for rec in records:
        ts = rec.get("timestamp", "")
        km = rec.get("key_metrics") or {}
        for field in fields:
            val = km.get(field)
            if isinstance(val, (int, float)):
                series[field].append((ts, float(val)))
    for field in series:
        series[field].sort(key=lambda x: x[0])
    return dict(series)


def detect_regression(field: str, values: list[float]) -> str | None:
    if len(values) < 2:
        return None
    prev, last = values[-2], values[-1]
    if field in HIGHER_IS_BETTER:
        if last < prev:
            return f"REGRESSION: {prev:.3g} -> {last:.3g} (lower is worse)"
    else:
        if last > prev:
            return f"REGRESSION: {prev:.3g} -> {last:.3g} (higher is worse)"
    return None


def print_table(design: str, domain_series: dict[str, dict[str, list[tuple[str, float]]]], min_runs: int) -> int:
    rows = 0
    for domain, series in sorted(domain_series.items()):
        if not series:
            continue
        run_count = max(len(pts) for pts in series.values()) if series else 0
        if run_count < min_runs:
            continue
        print(f"\n{'='*72}")
        print(f"Domain: {domain}  |  Design: {design}  |  Runs: {run_count}")
        print(f"{'='*72}")
        print(f"  {'Metric':<35} {'Min':>10} {'Max':>10} {'Latest':>10}  Alert")
        print(f"  {'-'*35} {'-'*10} {'-'*10} {'-'*10}  -----")
        for field, points in sorted(series.items()):
            values = [v for _, v in points]
            if not values:
                continue
            alert = detect_regression(field, values) or ""
            print(f"  {field:<35} {min(values):>10.4g} {max(values):>10.4g} {values[-1]:>10.4g}  {alert}")
            rows += 1
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="QoR metric trending across chip-design orchestrator runs")
    parser.add_argument("--design", required=True, metavar="NAME")
    parser.add_argument("--domain", metavar="DOMAIN", choices=VALID_DOMAINS, default=None)
    parser.add_argument("--metric", metavar="FIELD", default=None)
    parser.add_argument("--memory-root", metavar="PATH", default=None)
    parser.add_argument("--min-runs", type=int, default=2, metavar="N")
    args = parser.parse_args()

    memory_root = Path(args.memory_root) if args.memory_root else find_memory_root(Path(__file__))
    domains = [args.domain] if args.domain else VALID_DOMAINS
    domain_series = {}
    total_runs = 0
    for domain in domains:
        all_records = load_domain_records(memory_root, domain)
        design_records = filter_by_design(all_records, args.design)
        if not design_records:
            continue
        series = extract_series(design_records, domain, args.metric)
        if series:
            domain_series[domain] = series
            total_runs += len(design_records)
    if not domain_series:
        print(f"No runs found for design '{args.design}'.", file=sys.stderr)
        raise SystemExit(1)
    print("\nQoR Trend Report")
    print(f"Design:      {args.design}")
    print(f"Total runs:  {total_runs}")
    print(f"Domains:     {', '.join(sorted(domain_series))}")
    if args.metric:
        print(f"Metric filter: {args.metric}")
    rows = print_table(args.design, domain_series, args.min_runs)
    if rows == 0:
        print(f"\n[info] No series met the --min-runs={args.min_runs} threshold.")


if __name__ == "__main__":
    main()
