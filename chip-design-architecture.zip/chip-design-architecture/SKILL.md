---
name: chip-design-architecture
description: Use when evaluating chip architecture candidates, decomposing a product spec into hardware requirements, modeling performance, estimating power/area, assessing technical risk, or preparing a microarchitecture handoff package for RTL. Trigger even when the user only asks for architecture tradeoffs, PPA estimation, gem5 modelling, McPAT area estimates, risk review, or a spec-to-microarchitecture workflow.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-architecture: Microarchitecture Evaluation

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. All performance modeling tools (gem5, McPAT, CACTI) are open-source and are the **recommended default**
2. Commercial alternatives (Synopsys Platform Architect, Cadence VSP) are supported but listed as optional — only use when the user explicitly selects them
3. Python-based analytical estimation requires no license and is always available as a baseline
4. Detection order: open-source tool commands are checked before commercial ones

---

## Use Mode

This skill supports two modes:

**Full architecture evaluation flow:**
- Follow the 6-stage orchestrated flow from spec analysis through architecture signoff
- Analyze spec, explore candidates, model performance and PPA, assess risk, sign off
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules when answering targeted questions
- Reference trade-off matrix templates, risk scoring rules, or PPA estimation formulas without running the full flow

**Critical constraints:**
- Do not begin architecture exploration until the requirements breakdown explicitly captures all open questions
- Keep at least three architecture candidates unless the user explicitly narrows scope
- Do not sign off while must-have requirements, PPA budgets, or HIGH-risk mitigations are unresolved

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| perf_model | `gem5`, `mcpat`, `cacti` | Optional (all open-source) |
| python | `python3` | Required (for estimation scripts) |

### Tool Execution

Open-source tools (recommended):

| Tool | Command | Type |
|------|---------|------|
| gem5 | `gem5 <config.py>` | Open-source (recommended) |
| McPAT | `mcpat -infile <xml>` | Open-source (recommended) |
| CACTI | `cacti -infile <cfg>` | Open-source (recommended) |
| Python estimation | `python3 estimate.py` | Open-source (always available) |

Commercial tools (optional — only when user explicitly selects):

| Tool | Command | Type |
|------|---------|------|
| Synopsys Platform Architect | Vendor batch mode | Commercial — optional |
| Cadence VSP | Vendor batch mode | Commercial — optional |

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `perf_model` capability is configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which gem5`, `which mcpat`, `which cacti` first (open-source), then optionally detect commercial tools
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. No tool detected → inform user; this capability is optional, skill can proceed with Python analytical estimation only (no license required)

---

## Stage Workflow

### Stage 1: spec_analysis

Decompose the product specification into explicit architecture requirements before any design work begins.

**Domain Rules:**
1. Classify every requirement: functional, performance, power, area, interface, safety/security
2. Identify under-specified areas — flag as open questions for the product team; do not assume
3. Map each use case to required hardware blocks (datapath, control, memory, IO)
4. Extract all interface requirements with protocols (AXI, PCIe, USB, Ethernet) and bandwidth targets
5. Identify safety/security requirements (ISO 26262, FIPS, CC) if applicable
6. Assign priority: Must-Have / Should-Have / Nice-to-Have
7. Produce structured requirements document before any architecture work begins

**Common Issues & Fixes:**

| Issue | Fix |
|-------|-----|
| Spec section not mapped | Add to open questions; do not assume |
| Interface bandwidth unspecified | Request from product team before proceeding |
| Conflicting requirements | Flag as blocker; request resolution |
| Incomplete spec → HIGH risk_assessment | Request spec clarification before iterating architecture — exploration iterations will not resolve an under-specified schedule risk |

**QoR Metrics:**
- Requirements coverage: 100% of spec sections mapped to at least one requirement
- Ambiguity count: all unresolved items captured in open questions list
- Interface completeness: all external interfaces named with protocol and bandwidth

**Output Required:**
- Structured requirements document (Markdown or JSON)
- Interface list with protocols and bandwidths
- Open questions list

---

### Stage 2: arch_exploration

Generate and compare candidate microarchitectures with distinct trade-off profiles.

**Domain Rules:**
1. Generate minimum 3 candidates: conservative, balanced, aggressive
2. Evaluate pipeline depth trade-offs (deeper = higher frequency, more area/power, more hazard logic)
3. Evaluate parallelism: SIMD, superscalar, spatial unrolling — with area/power cost per option
4. Cache/memory hierarchy: size, associativity, latency vs area trade-off per use case
5. Interconnect topology: bus, crossbar, NoC — evaluate bandwidth vs complexity
6. Consider IP reuse: identify hard macros or licensed IPs before designing custom equivalents
7. Document all assumptions for each candidate explicitly
8. Produce trade-off matrix comparing all candidates quantitatively

**Trade-off Matrix Template:**

| Candidate | Freq Target | Area Est. | Power Est. | Risk  | Notes |
|-----------|-------------|-----------|------------|-------|-------|
| Conservative | 500 MHz | 2 mm² | 150 mW | Low | In-order pipeline, proven IP |
| Balanced | 1 GHz | 4 mm² | 350 mW | Med | OOO 2-wide, custom cache |
| Aggressive | 2 GHz | 8 mm² | 700 mW | High | OOO 4-wide, novel memory subsystem |

**QoR Metrics:**
- Minimum 3 candidates explored with distinct trade-off profiles
- Each candidate: performance estimate within 20% of target
- Single recommended candidate with clear quantitative justification

**Output Required:**
- Trade-off matrix with all candidates
- Recommended candidate with quantitative justification
- Assumptions and risk summary per candidate

---

### Stage 3: perf_modelling

Model performance of the selected architecture candidate against all use-case workloads.

**Domain Rules:**
1. Use analytical models (Amdahl, Roofline) for initial estimates
2. Build TLM/SystemC or Python models for complex pipelines
3. Model all bottlenecks: compute, memory bandwidth, IO throughput
4. Sweep key parameters: clock frequency, parallelism, cache size
5. Validate with representative workloads from the use-case list
6. Include best/typical/worst-case scenarios
7. Flag any model assumption that has not been validated against silicon or simulation

**gem5 Configuration Notes:**
- In-order models (`MinorCPU`) are within 15% of silicon without branch predictor tuning
- OOO models need branch predictor tuning to reach within 15% of silicon: tune `BTBEntries`, `RASSize`, `numThreads` before reporting throughput numbers
- Default LTAGE parameters are often mismatched for deeply embedded workloads

**QoR Metrics:**
- Throughput: meets or exceeds target by ≥ 10% margin
- Latency: meets target at worst-case workload
- Memory bandwidth: does not exceed DRAM/SRAM ceiling
- Model confidence: HIGH / MEDIUM / LOW — must be stated explicitly

**Output Required:**
- Performance model (script or spreadsheet)
- Throughput/latency results per use case
- Sensitivity analysis (key parameter sweeps)
- Comparison table: modelled vs target

---

### Stage 4: power_area_estimation

Estimate power and area for the selected architecture with explicit uncertainty bounds.

**Domain Rules:**
1. Area: use technology library scaling data (gates/mm² at target node); do not use raw McPAT without technology calibration (±30% error without calibration)
2. Dynamic power: P = α × C × V² × f — get activity factor from use-case workloads
3. Leakage: estimate from library characterisation at target Vt mix
4. Memory area: use SRAM compiler estimates for given depth × width
5. IO pad area: per pad ring design rules
6. Apply 15–20% RTL area margin — RTL implementation is never as minimal as architectural estimates
7. Flag immediately if any estimate exceeds 80% of budget

**McPAT / CACTI Usage:**
```bash
# CACTI — always specify all three to avoid defaulting to wrong parameters
cacti -cache_size <N> -block_size <B> -associativity <A>
# McPAT — use --inorder mode for in-order designs (more accurate than default OOO config)
mcpat --inorder
```

**QoR Metrics:**
- Area estimate: < 80% of budget
- Dynamic power: < 80% of budget
- Leakage: < 15% of total estimated power
- Confidence: HIGH / MEDIUM / LOW — stated explicitly with calibration basis

**Output Required:**
- Area breakdown by block
- Power breakdown: dynamic, leakage, per domain
- Margin analysis vs targets
- Uncertainty bounds on all estimates

---

### Stage 5: risk_assessment

Identify, score, and develop mitigation plans for all technical and schedule risks.

**Domain Rules:**
1. Risk categories: schedule, technical feasibility, IP availability, tool support, verification complexity, power closure, manufacturing yield
2. Score every risk: Probability (1–5) × Impact (1–5) = Risk Score
3. Risk score ≥ 15: classified HIGH — must have mitigation plan and owner before sign-off
4. IP risks: verify availability, licensing timeline, silicon-proven status
5. Tool risks: verify EDA tool certification for chosen technology node
6. Verification risks: flag if testbench complexity > 6 months estimated effort
7. Every risk must have an assigned owner

**Risk Score Reference:**
| Score | Classification | Action Required |
|-------|---------------|-----------------|
| ≥ 15 | HIGH | Mitigation plan + owner required before signoff |
| 10–14 | MEDIUM | Mitigation plan recommended; track weekly |
| < 10 | LOW | Monitor; review at each gate |

**Common Issues & Fixes:**

| Issue | Fix |
|-------|-----|
| HIGH schedule risk from spec gaps | Return to `spec_analysis` — additional arch exploration does not resolve under-specified schedule risks |
| Platform Architect hangs at startup (commercial only) | Check `LM_LICENSE_FILE` and run `lmstat -a` before retrying |
| VSP TLM model import fails silently (commercial only) | Rebuild `.so` with `--std=c++14` and matching `-fabi-version` as VSP runtime |

**QoR Metrics:**
- No unmitigated HIGH risks at sign-off
- All risks: assigned owner and mitigation plan
- Schedule risk assessed vs team capacity

**Output Required:**
- Risk register (ID, description, score, mitigation, owner)
- Top 5 risks for management review

---

### Stage 6: arch_signoff

Final review confirming the microarchitecture is ready for RTL handoff.

**Sign-off Checklist:**
- [ ] All Must-Have requirements addressed
- [ ] Performance targets met in model (≥ 10% margin)
- [ ] Power and area within budget (< 80%)
- [ ] All HIGH risks have mitigation plans and owners
- [ ] Interface specifications complete and agreed
- [ ] Memory map defined
- [ ] Clock domains identified; CDC strategy agreed
- [ ] Reset strategy defined
- [ ] DFT strategy agreed
- [ ] Verification strategy agreed
- [ ] RTL coding guidelines documented
- [ ] Hand-off package complete for RTL team

**Output Required:**
- Signed-off microarchitecture document
- Final trade-off decision record
- RTL design guidelines
- Hand-off package (requirements, memory map, interface specs, risk register)

---

## Sign-off Hard Gates

Architecture signoff requires ALL of these conditions:

- `all_mustHave_requirements_covered == true` (spec coverage complete)
- `perf_margin_pct >= 10` (performance meets target with margin)
- `area_budget_pct < 80` (area estimate within budget)
- `power_budget_pct < 80` (power estimate within budget)
- `high_risk_unmitigated_count == 0` (all HIGH risks have owners and plans)

---

## Loop-Back Rules

- `perf_modelling` FAIL (throughput misses target) → return to `arch_exploration` (max 3×)
- `power_area_estimation` FAIL (area or power > 80% budget) → return to `arch_exploration` (max 2×)
- `risk_assessment` HIGH risks unmitigated → retry `risk_assessment` (max 2×)
- `arch_signoff` FAIL (spec coverage gap) → return to `spec_analysis` (max 1×)
- `arch_signoff` FAIL (PPA gap) → return to `arch_exploration` (max 2×)

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and tool quirks. Use this to inform stage decisions — for example, McPAT calibration requirements, gem5 branch predictor tuning for embedded workloads, CACTI parameter specification requirements.

During an architecture flow, it is useful to record key outcomes such as selected architecture, estimated MHz, area, issues encountered, and sign-off status. If the project uses a persistent knowledge system, these can be written out for reuse across related designs. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/architecture-rules.md](references/architecture-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/architecture-flow.md](references/architecture-flow.md) — broader flow narrative
- [scripts/qor_trends.py](scripts/qor_trends.py) — cross-run QoR trend utility (master copy; `python3 scripts/qor_trends.py --design <name>`)
