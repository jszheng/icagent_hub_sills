---
name: chip-design-synthesis
description: Use when preparing synthesis constraints, exploring compile strategies, generating a clean gate-level netlist, checking timing/area/power tradeoffs, running netlist QC or LEC, or deciding synthesis signoff for handoff into STA and physical design. Trigger even if the user only mentions SDC, compile QoR, netlist quality, unmapped cells, or synthesis closure.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-synthesis: Logic Synthesis Flow

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. **Yosys** is the recommended default synthesis tool — supports liberty-based technology mapping via ABC, no license required
2. **Liberty `.lib`** is the open-source standard library format; Yosys reads `.lib` directly. Commercial `.db` format (DC/Genus) is only needed when using commercial tools
3. **Open PDKs** (sky130, GF180, ASAP7) are fully supported with Yosys + open-source flow (ORFS/OpenLane)
4. Commercial tools (Design Compiler, Fusion Compiler, Genus) are supported but listed as optional — only use when the user explicitly selects them
5. Detection order: `yosys` is checked before commercial tool commands

---

## Use Mode

This skill supports two modes:

**Full synthesis flow:**
- Follow the 5-stage orchestrated flow from constraint setup through synthesis signoff
- Explore compile strategies, run final compile, run netlist QC and LEC
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules when answering targeted questions
- Reference SDC rules, compile strategies, or LEC requirements without running the full flow

**Critical constraints:**
- Do not advance to compile_final with unconstrained paths
- Do not proceed to synthesis signoff with WNS < 0 or any LEC unmatched points
- LEC must be run after every netlist change — not just at signoff

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| synthesis | `yosys`, `dc_shell`, `fc_shell`, `genus` | Required (at least one; open-source recommended) |

### Tool Execution

Open-source (recommended):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| Yosys | `yosys -p "synth -top <top>" <files>` | `dfflibmap` + `abc -liberty` for technology mapping; reads `.lib` directly | Open-source (recommended) |

Commercial (optional):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| Design Compiler | `dc_shell -f <script.tcl>` | `-output_log_file <log>` for log capture; requires `.db` format | Commercial — Synopsys |
| Fusion Compiler | `fc_shell -f <script.tcl>` | Combined synthesis + physical guidance | Commercial — Synopsys |
| Genus | `genus -f <script.tcl>` | `-log <logfile>` for log capture | Commercial — Cadence |

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `synthesis` capability is configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which yosys` first (open-source), then `which dc_shell`, `which fc_shell`, `which genus` (commercial)
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. Required capability with no tool detected → inform user and stop; suggest installing Yosys (`apt install yosys` or build from source) as open-source option

---

## Stage Workflow

### Stage 1: pdk_analysis

Analyze the PDK directory structure before generating any synthesis scripts.

**Domain Rules:**
1. Identify all available standard cell libraries: list directory names, distinguish full standard cell libraries from special-purpose libraries (clock-gating-only, ECO, etc.)
2. Identify library file formats: check for `.lib` (liberty text — open-source standard, used by Yosys/OpenSTA directly) and `.db` (binary — DC/Genus only). If using Yosys, `.lib` is sufficient. If using DC and only `.lib` exists, convert with `read_lib` + `write_lib` in dc_shell
3. Identify available PVT corners: parse liberty/db filenames for corner naming patterns (e.g., `ssg0p72v125c` = SS/0.72V/125C, `ffg1p05vm40c` = FF/1.05V/-40C)
4. Identify available Vt flavors: RVT, HVT, LVT — determine which is the primary target
5. Check for LEF files: tech LEF (layer definitions) + cell LEF (standard cell abstracts)
6. Check for memory compiler outputs: `.db`/`.lib` + `.lef` for SRAM macros if design uses memories
7. Verify the primary library contains basic combinational cells (AND, OR, NOR, INV, MUX, AOI, OAI) — clock-gating-only libraries (CG) lack these and will cause compile failures
8. Record findings in a PDK summary before proceeding

**Common Issues & Fixes:**

See [references/synthesis-rules.md](references/synthesis-rules.md) for common PDK analysis issues and fixes.

**QoR Metrics:**
- Primary target library identified with full standard cells confirmed
- At least SS (setup) and FF (hold) corners available
- Library format compatible with synthesis tool (`.lib` for Yosys; `.db` for DC — commercial only)

**Output Required:**
- PDK summary: library names, corners, Vt flavors, file formats, file paths
- Selected target library and link libraries for synthesis

---

### Stage 2: constraint_setup

Define all timing constraints before running any synthesis compile.

**Domain Rules:**
1. `create_clock`: all primary clocks with period, waveform, source pin, name
2. `create_generated_clock`: all derived/divided clocks with correct source
3. `set_clock_uncertainty`: setup = skew + jitter (typically 200–500 ps pre-CTS)
4. `set_input_delay` / `set_output_delay`: all primary IOs constrained
5. `set_false_path`: multi-clock crossings, test modes, async resets
6. `set_multicycle_path`: both setup (`-setup N`) and hold (`-hold 1`) must be set together
7. `set_dont_touch`: IPs, memory macros, hand-crafted cells
8. `set_max_fanout`: per library recommendation (typically 32)
9. `set_max_transition`: per technology DRC rule
10. Operating conditions: explicitly set (never rely on tool defaults)
11. Scan chain false paths must be declared **before** `compile_ultra` — declaring after causes re-optimization breaking chain continuity

**Common SDC Mistakes:**

See [references/synthesis-rules.md](references/synthesis-rules.md) for common SDC mistakes and consequences.

**QoR Metrics:**
- All clocks defined (verify with `report_clocks`)
- All IOs constrained (verify with `report_port -verbose`)
- No unconstrained paths (`report_timing -unconstrained`)

**Output Required:**
- Validated SDC file
- Clock summary
- Constraint QA report

---

### Stage 3: compile_explore

Run a faster exploratory compile to identify optimal compile strategy.

**Domain Rules:**
1. Run at worst-case timing corner (SS, low voltage, high temperature)
2. Try multiple architectures: retiming on/off, datapath options
3. Identify critical paths for human review before final compile
4. Check area estimate vs microarch estimate

**Optimisation Strategy by Priority:**

See [references/synthesis-rules.md](references/synthesis-rules.md) for optimization strategy details per tool.

**Output Required:**
- Exploration report (timing, area, power summary)
- Critical path list for architect review
- Recommended compile strategy for final compile

---

### Stage 4: compile_final

Run full optimized synthesis to produce the sign-off netlist.

**Domain Rules:**
1. Run multi-scenario if available (setup + hold simultaneously)
2. Enable clock gating synthesis for sequential power reduction
3. Preserve hierarchy for blocks with existing placement intent
4. Ungroup small modules for better cross-boundary optimisation
5. Review critical paths manually — restructure RTL if path cannot close
6. Run incremental compile after initial compile to address remaining violations
7. DC/Genus only: after 2 failed `compile_ultra` runs, switch to targeted path optimization (`compile_ultra -only_design_rule` + `optimize_registers`) — further full `ultra` effort yields < 1% improvement at 3–5× runtime cost

**Yosys Sequential Flow — Required Log Review (recommended for open-source flow):**
After a Yosys run, the agent must:
1. Read the Yosys log for `Warning:` / `Error:` lines per pass and final statistics (cells, wires, logic depth)
2. Search for `$`-prefixed cell names in the output netlist (indicates unmapped cells)
3. Verify `synth_netlist.v` exists and is non-empty
4. When used inside ORFS/LibreLane: log at `logs/<platform>/<design>/1_1_yosys.log`

**Recommended Yosys Command (sky130):**
```bash
yosys -p "synth -top <top> -flatten; dfflibmap -liberty <lib.lib>; abc -liberty <lib.lib> -D <period_ps>"
# -flatten required for sky130 hierarchical designs; without it, area overhead ~15-20%
# -D <period_ps> sets the timing target for ABC delay optimization
# Strip pg_pin entries from liberty before passing to ABC:
#   sed '/pg_pin/,/^  }/d' <lib.lib> > lib_nopg.lib
```

**QoR Metrics:**
- WNS: ≥ 0 at worst-case corner for sign-off
- TNS: = 0 for clean sign-off
- Area: within budget
- Power: within budget
- No unmapped cells

**Output Required:**
- Gate-level netlist (`.v`)
- Timing report (setup and hold, all path groups)
- Area report
- Power report
- Synthesis run log

---

### Stage 5: netlist_qc

Verify netlist quality before PD handoff.

**Checks Required:**
1. No black boxes (undefined modules) in netlist
2. No combinational loops (`report_loop`)
3. Scan chains intact (if DFT-enabled compile)
4. Power/ground connections correct (tie cells, well ties)
5. Formal equivalence check (RTL vs netlist): PASS required

**LEC Requirements:**
- Golden: RTL (post-lint, post-CDC-clean)
- Revised: gate-level netlist
- Result: all points EQUIVALENT
- Any UNMATCHED point: must be resolved before PD handoff

**Common Netlist QC Issues:**

See [references/synthesis-rules.md](references/synthesis-rules.md) for common netlist QC issues and fixes.

**QoR Metrics:**
- LEC: 100% EQUIVALENT
- No black boxes
- No combinational loops
- Scan chain integrity: verified

**Output Required:**
- LEC report (pass/fail)
- Netlist QC checklist
- Final gate netlist (ready for PD)
- Back-annotated SDC for PD

---

### Stage 6: synthesis_signoff

Final review and packaging of synthesis results for PD handoff.

**Sign-off Checklist:**
- [ ] WNS ≥ 0 at all required corners
- [ ] TNS = 0
- [ ] Area within budget
- [ ] Power within budget
- [ ] LEC: EQUIVALENT
- [ ] No black boxes
- [ ] No combinational loops
- [ ] Scan chains verified (if DFT)

**Output Required:**
- PD handoff package: netlist, SDC, timing reports, area/power reports

---

## Sign-off Hard Gates

Synthesis signoff requires ALL of these conditions:

- `wns_ns >= 0` (no timing violations at worst-case corner)
- `lec_unmatched_points == 0` (full equivalence confirmed)
- `unmapped_cells == 0` (no technology library gaps)

**Critical note:**
A single unverified netlist change that reaches PD and fails LEC there costs a full PD re-run. Run LEC after every netlist change, not just at signoff.

---

See [references/synthesis-rules.md](references/synthesis-rules.md) for tool-specific flags and command details.

---

## Loop-Back Rules

- `compile_final` FAIL (WNS < 0) → retry `compile_final` (max 3×)
- `compile_final` FAIL (area > budget) → return to `compile_explore` (max 2×)
- `netlist_qc` FAIL (LEC unmatched) → retry `compile_final` (max 2×)
- `netlist_qc` FAIL (unmapped cells) → retry `compile_final` (max 2×)

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and known tool quirks. Use this to inform stage decisions — for example, known sky130 flatten requirements, Genus timing constraint ordering, or liberty compatibility issues.

During a synthesis flow, it is useful to record key outcomes such as WNS/TNS, cell count, area, loop-back counts, and LEC status. If the project uses a persistent knowledge system, these can be written out for reuse across designs. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/synthesis-rules.md](references/synthesis-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/synthesis-flow.md](references/synthesis-flow.md) — broader flow narrative
- [../chip-design-architecture/scripts/qor_trends.py](../chip-design-architecture/scripts/qor_trends.py) — cross-run QoR trend utility (shared)
