# Synthesis Flow Reference

This skill covers the path from constraint setup through compile exploration, final compile, netlist QC, and synthesis signoff.

Core outputs are a trustworthy synthesized netlist and a handoff-ready QoR summary.
