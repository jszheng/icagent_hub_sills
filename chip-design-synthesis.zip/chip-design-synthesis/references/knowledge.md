# Synthesis Domain Knowledge

## Known Failure Patterns

- **Yosys -flatten required for hierarchical sky130 designs**: Yosys synthesis of hierarchical
  designs targeting sky130 PDK requires `-flatten` in the `synth` pass. Without flattening,
  technology mapping fails to optimize across hierarchy boundaries, producing ~15-20% area
  overhead vs. flattened synthesis. Use `synth -top <top> -flatten` for sky130 targets.
- **ABC liberty compatibility**: ABC requires liberty files without `pg_pin` (power/ground pin)
  entries. Strip `pg_pin` blocks from sky130 liberty with `sed '/pg_pin/,/^  }/d'` before passing
  to Yosys/ABC — `pg_pin` entries cause ABC to silently ignore the cell.
- **Scan chain false paths before compile_ultra (commercial only)**: Scan chain false paths must be declared in the
  SDC before `compile_ultra`. Declaring them after causes the tool to re-optimize scan paths,
  breaking chain continuity and requiring LEC re-run.

## Successful Tool Flags

### Open-source (recommended)

- `yosys -p "synth -top <top> -flatten; dfflibmap -liberty <lib.lib>; abc -liberty <lib.lib> -D <period_ps>"` —
  complete Yosys synthesis command for sky130; `-D <period_ps>` sets the timing target for ABC
  delay optimization. Yosys reads `.lib` (liberty text) directly — no format conversion needed.

### Commercial (optional)

- `dc_shell -f <script.tcl> -output_log_file <log>` — always capture the log; `check_design`
  warnings about unresolved references are the most common root cause of synthesis failures.
  DC requires `.db` format — convert from `.lib` with `read_lib` + `write_lib` in lc_shell.
- `genus -legacy_ui -files <script.tcl>` — `--legacy_ui` mode is more stable for scripted flows
  than the default UI mode; avoids interactive prompts that hang batch jobs.

## PDK / Tool Quirks

### Open-source

- **Yosys + sky130 pg_pin issue**: Strip `pg_pin` from liberty before ABC: `sed '/pg_pin/,/^  }/d' <lib.lib> > lib_nopg.lib`.
  This is the most common cause of unmapped cells in Yosys + sky130 flow.

### Commercial (optional)

- **DC requires `.db` format, not `.lib`**: Design Compiler cannot read liberty text format (`.lib`)
  directly as `target_library`. Must use pre-compiled `.db` files.
- **Clock-gating-only (CG) library cannot be used as target_library**: CG libraries only contain
  clock-gating cells (ICG), not basic combinational cells. Use the full standard cell library as
  `target_library`, and optionally add the CG library to `link_library`.
- **`ultra` effort past 2x loop-backs**: `compile_ultra` with `ultra` effort rarely closes WNS
  past 2 loop-back iterations. Switch to targeted path optimization after 2 failed attempts.
- **Genus set_max_area alone does not close WNS**: Always set timing constraints before area
  optimization in Genus.

## Notes

- LEC must be run after every netlist change — not just at signoff. A single unverified netlist
  change that reaches PD and fails LEC there costs a full PD re-run.
