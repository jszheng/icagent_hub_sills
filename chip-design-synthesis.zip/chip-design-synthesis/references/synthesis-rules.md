# Synthesis Rules Reference

## Stage Sequence
`constraint_setup -> compile_explore -> compile_final -> netlist_qc -> synthesis_signoff`

## Loop-back Rules
- final compile timing miss -> rework compile strategy (max 3x)
- area over budget -> return to exploration (max 2x)
- LEC unmatched or unmapped cells -> return to final compile (max 2x)

## High-level Rules
- constraints come before QoR conclusions
- explore first, freeze final compile second
- netlist QC and LEC are separate gates
- PD handoff only accepts timing-clean, netlist-clean output

---

## Common PDK Analysis Issues and Fixes

| Issue | Fix |
|-------|-----|
| Only `.lib` files, no `.db` | Yosys reads `.lib` directly — no conversion needed. For DC only: convert with `read_lib <file.lib>; write_lib <libname> -output <file.db>` in dc_shell |
| CG library used as target_library | CG libraries only contain clock-gating cells — switch to full standard cell library (non-CG) |
| Corner naming unclear | Parse filename pattern: `<process><vt><corner><voltage><temp>.db` |
| Multiple Vt libraries available | Use RVT as primary target; add HVT/LVT to link_library for multi-Vt optimization |

---

## Common SDC Mistakes and Consequences

| Mistake | Consequence |
|---------|------------|
| Missing generated clock | Path unconstrained — may miss timing |
| MCP without hold correction | Hold violations introduced |
| False path too broad | Real timing issues masked |
| No operating conditions set | Wrong library corner used |
| Scan false path declared after compile | Chain continuity broken, requires LEC re-run |

---

## Optimisation Strategy Details per Tool

### Yosys (open-source — recommended)

| Priority | Approach |
|----------|---------|
| Timing | `abc -D <period_ps>` delay-optimized mapping; increase ABC iterations with `-S <N>` |
| Area | `abc -liberty <lib> -G <N>` area-focused mapping; `opt -full` before ABC |
| Power | Clock gating: manual or via `clk2fflogic`; multi-Vt: provide HVT/LVT liberty to ABC |
| Balanced | `synth -top <top> -flatten` + `abc -liberty <lib>` with default settings |

### DC / Genus (commercial — optional)

| Priority | Approach |
|----------|---------|
| Timing | `compile_ultra`, path_group weighting, retiming |
| Area | High area_effort, resource sharing |
| Power | Clock gating insertion, power-aware compile |
| Balanced | `compile_ultra -no_autoungroup` + incremental |

---

## Common Netlist QC Issues and Fixes

| Issue | Fix |
|-------|-----|
| ABC liberty compatibility failure (Yosys) | Strip `pg_pin` blocks from liberty file before Yosys/ABC; `pg_pin` entries cause ABC to silently ignore the cell |
| Genus `set_max_area 0` doesn't close WNS (commercial only) | Always set timing constraints before `compile_ultra`; area optimization runs within the timing budget |
| DC `check_design` unresolved references (commercial only) | Fix in RTL or provide library definitions; most common root cause of synthesis failures |

---

## Tool-Specific Flags and Command Details

### Open-Source (recommended)

**Yosys (recommended):**
```bash
yosys -p "synth -top <top> -flatten; dfflibmap -liberty <lib.lib>; abc -liberty <lib.lib> -D <period_ps>"
```
- `-flatten`: required for sky130 hierarchical designs (without it, area overhead ~15-20%)
- `-D <period_ps>`: sets timing target for ABC delay optimization
- Strip `pg_pin` from liberty before ABC: `sed '/pg_pin/,/^  }/d' <lib.lib> > lib_nopg.lib`
- Check for unmapped cells: search for `$`-prefixed cell names in output netlist
- ORFS/OpenLane integration: log at `logs/<platform>/<design>/1_1_yosys.log`

### Commercial (optional)

**Design Compiler (commercial — Synopsys):**
```bash
dc_shell -f <script.tcl> -output_log_file <log>
```
- Always capture log; `check_design` warnings about unresolved references are most common failure root cause

**Genus (commercial — Cadence):**
```bash
genus -legacy_ui -files <script.tcl>
```
- `--legacy_ui` mode more stable for scripted flows; avoids interactive prompts that hang batch jobs
