// =============================================================================
// SVA Assertion Module Skeleton
// Replace placeholders before use:
//   <DUT_NAME>    - Design name (e.g., apb_uart)
//   <CLK>         - Clock signal name (e.g., PCLK)
//   <RST>         - Active-low reset signal name (e.g., PRESETn)
//   <FSM_STATES>  - Comma-separated FSM state localparams
//   <SIGNALS>     - Observed signal port declarations
// =============================================================================

module <DUT_NAME>_sva (
  input logic <CLK>,
  input logic <RST>,
  <SIGNALS>
);

  // ==========================================================================
  // Local Parameters
  // ==========================================================================

  // FSM state encodings
  <FSM_STATES>

  // Timing constants
  // localparam int TIMEOUT_CYCLES = 1000;

  // ==========================================================================
  // Default Clocking & Disable
  // ==========================================================================
  default clocking cb @(posedge <CLK>); endclocking
  default disable iff (!<RST>);

  // ==========================================================================
  // Protocol Assertions
  // ==========================================================================

  // TODO: Add protocol-level assertions here
  // Example:
  // asp_protocol_rule: assert property ( ... )
  //   else `uvm_error("<DUT_NAME>_SVA", "Protocol rule violated")

  // ==========================================================================
  // FSM Assertions
  // ==========================================================================

  // No X/Z on FSM state
  // asp_fsm_no_x: assert property (
  //   !$isunknown(fsm_state)
  // ) else `uvm_error("<DUT_NAME>_SVA", "FSM state is X/Z")

  // Legal state check
  // asp_fsm_legal: assert property (
  //   fsm_state inside {ST_IDLE, ST_ACTIVE, ...}
  // ) else `uvm_error("<DUT_NAME>_SVA", "FSM in illegal state")

  // ==========================================================================
  // Reset Value Assertions
  // ==========================================================================

  // TODO: Assert that outputs/registers hold correct values after reset
  // asp_reset_val: assert property (
  //   $fell(<RST>) |=> (signal == RESET_VALUE)
  // ) else `uvm_error("<DUT_NAME>_SVA", "Reset value incorrect")

  // ==========================================================================
  // Cover Properties
  // ==========================================================================

  // TODO: Add functional cover properties for interesting scenarios
  // cvp_normal_operation: cover property ( ... );
  // cvp_back_to_back:    cover property ( ... );

endmodule : <DUT_NAME>_sva
