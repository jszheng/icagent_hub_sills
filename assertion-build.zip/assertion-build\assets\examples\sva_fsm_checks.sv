// =============================================================================
// SVA Example: Generic FSM Checks
// These assertions apply to any FSM. Adapt signal names and state encodings
// to match the specific DUT.
// =============================================================================

module sva_fsm_checks #(
  parameter int STATE_WIDTH  = 4,
  parameter int NUM_STATES   = 8,
  parameter logic [STATE_WIDTH-1:0] RESET_STATE = '0
)(
  input logic                     clk,
  input logic                     rst_n,
  input logic [STATE_WIDTH-1:0]   fsm_state,
  // Provide a packed array of all legal state values
  input logic [STATE_WIDTH-1:0]   legal_states [NUM_STATES]
);

  default clocking cb @(posedge clk); endclocking
  default disable iff (!rst_n);

  // -------------------------------------------------------------------------
  // 1. No X/Z on FSM state register
  // -------------------------------------------------------------------------
  asp_no_x: assert property (
    !$isunknown(fsm_state)
  ) else $error("FSM: state register contains X/Z (state=%0b)", fsm_state);

  // -------------------------------------------------------------------------
  // 2. Legal state check -- state must be one of the declared legal values
  //    (Implement with a helper function for flexibility)
  // -------------------------------------------------------------------------
  function automatic bit is_legal_state(
    input logic [STATE_WIDTH-1:0] st,
    input logic [STATE_WIDTH-1:0] valid [NUM_STATES]
  );
    for (int i = 0; i < NUM_STATES; i++) begin
      if (st === valid[i]) return 1'b1;
    end
    return 1'b0;
  endfunction

  asp_legal_state: assert property (
    is_legal_state(fsm_state, legal_states)
  ) else $error("FSM: illegal state detected (state=%0h)", fsm_state);

  // -------------------------------------------------------------------------
  // 3. One-hot encoding check (use when FSM is one-hot encoded)
  //    Uncomment if applicable.
  // -------------------------------------------------------------------------
  // asp_one_hot: assert property (
  //   $onehot(fsm_state)
  // ) else $error("FSM: state is not one-hot (state=%0b)", fsm_state);

  // -------------------------------------------------------------------------
  // 4. Reset state check -- after reset de-assertion, FSM must be in
  //    the defined reset state
  // -------------------------------------------------------------------------
  asp_reset_state: assert property (
    @(posedge clk)
    $rose(rst_n) |-> (fsm_state == RESET_STATE)
  ) else $error("FSM: not in reset state after reset de-assertion (state=%0h, expected=%0h)",
                fsm_state, RESET_STATE);

  // -------------------------------------------------------------------------
  // Cover Properties
  // -------------------------------------------------------------------------
  cvp_all_states: cover property (
    !$isunknown(fsm_state)
  );

  cvp_reset_entry: cover property (
    @(posedge clk) $rose(rst_n) ##0 (fsm_state == RESET_STATE)
  );

endmodule : sva_fsm_checks
