// =============================================================================
// SVA Example: APB Protocol Handshake Checks (Generic)
// These assertions verify standard APB handshake rules per AMBA APB spec.
// Adapt signal names to match specific DUT ports.
// =============================================================================

module sva_apb_handshake #(
  parameter int PREADY_MAX_WAIT = 16   // Max cycles PREADY may stay low
)(
  input logic PCLK,
  input logic PRESETn,
  input logic PSEL,
  input logic PENABLE,
  input logic PWRITE,
  input logic PREADY,
  input logic [31:0] PADDR,
  input logic [31:0] PWDATA
);

  default clocking cb @(posedge PCLK); endclocking
  default disable iff (!PRESETn);

  // -------------------------------------------------------------------------
  // 1. PENABLE must follow PSEL in the next cycle (setup -> access)
  // -------------------------------------------------------------------------
  asp_penable_follows_psel: assert property (
    (PSEL && !PENABLE) |=> PENABLE
  ) else $error("APB: PENABLE did not assert one cycle after PSEL");

  // -------------------------------------------------------------------------
  // 2. Address must remain stable during the access phase
  // -------------------------------------------------------------------------
  asp_addr_stable: assert property (
    (PSEL && PENABLE && !PREADY) |=> $stable(PADDR)
  ) else $error("APB: PADDR changed during access phase");

  // -------------------------------------------------------------------------
  // 3. Write data must remain stable during write access phase
  // -------------------------------------------------------------------------
  asp_wdata_stable: assert property (
    (PSEL && PENABLE && PWRITE && !PREADY) |=> $stable(PWDATA)
  ) else $error("APB: PWDATA changed during write access phase");

  // -------------------------------------------------------------------------
  // 4. PREADY must respond within N cycles (no infinite wait)
  // -------------------------------------------------------------------------
  asp_pready_timeout: assert property (
    (PSEL && PENABLE && !PREADY) |-> ##[1:PREADY_MAX_WAIT] PREADY
  ) else $error("APB: PREADY timeout -- exceeded %0d cycles", PREADY_MAX_WAIT);

  // -------------------------------------------------------------------------
  // 5. PSEL must stay asserted while PENABLE is high
  // -------------------------------------------------------------------------
  asp_psel_during_enable: assert property (
    PENABLE |-> PSEL
  ) else $error("APB: PSEL de-asserted while PENABLE is still high");

  // -------------------------------------------------------------------------
  // Cover Properties
  // -------------------------------------------------------------------------
  cvp_single_wait:    cover property (PSEL && PENABLE && !PREADY ##1 PREADY);
  cvp_zero_wait:      cover property (PSEL && !PENABLE ##1 PENABLE && PREADY);
  cvp_write_access:   cover property (PSEL && PENABLE && PWRITE && PREADY);
  cvp_read_access:    cover property (PSEL && PENABLE && !PWRITE && PREADY);

endmodule : sva_apb_handshake
