# SVA Assertion Patterns

Standards basis: IEEE 1800-2017 Assertions, Sequences/Properties, bind construct.

## 1. Assertion Classification

| Category | Source | Bind location | Priority |
|----------|--------|--------------|----------|
| Protocol compliance | spec_analysis.interfaces timing rules | Interface level | P0 |
| FSM legality | fsm_analysis.states | DUT internal (bind) | P0 |
| Reset values | spec_analysis.registers[].reset_value | DUT internal (bind) | P0 |
| Register access | spec_analysis.registers[].access | DUT internal (bind) | P1 |
| Error handling | spec_analysis.error_conditions | DUT internal (bind) | P1 |
| Data integrity | Scoreboard comparison logic | Scoreboard level | P1 |

## 2. SVA Code Patterns

### Pattern 1: Handshake Timing (any request-response protocol)

```systemverilog
// Applicable: APB, AXI, Wishbone, any req/ack protocol
// MAX_DELAY must be localparam (compile-time constant)
localparam MAX_DELAY = 1;  // APB: 1 cycle; AXI: up to 16

property handshake_response;
  @(posedge clk) disable iff (!rst_n)
  $rose(req) |-> ##[1:MAX_DELAY] ack;
endproperty
assert property (handshake_response)
  else `uvm_error("SVA", "Handshake timeout: ack not received within MAX_DELAY cycles")
```

Example instances:
- APB: req=PSEL, ack=PENABLE, MAX_DELAY=1
- AXI: req=ARVALID, ack=ARREADY, MAX_DELAY=16

### Pattern 2: Signal Stability During Transfer

```systemverilog
// Applicable: signals that must not change during a transfer phase
property signal_stable_during_transfer;
  @(posedge clk) disable iff (!rst_n)
  transfer_active |=> $stable(signal);
endproperty
assert property (signal_stable_during_transfer)
  else `uvm_error("SVA", $sformatf("Signal changed during transfer: %0h -> %0h", $past(signal), signal))
```

Example: APB — PADDR/PWDATA stable while PENABLE=1

### Pattern 3: FSM No-X Check

```systemverilog
// Applicable: any design with state machines
property fsm_no_x;
  @(posedge clk) disable iff (!rst_n)
  !$isunknown(fsm_state);
endproperty
assert property (fsm_no_x)
  else `uvm_error("SVA", "FSM state contains X/Z")
```

### Pattern 4: FSM Legal State Check

```systemverilog
// States list from fsm_analysis.states[] — expand at code generation time
// Cannot use formal argument to pass set; must enumerate
property fsm_legal_state;
  @(posedge clk) disable iff (!rst_n)
  fsm_state inside {STATE_IDLE, STATE_START, STATE_DATA, STATE_STOP};
endproperty
assert property (fsm_legal_state)
  else `uvm_error("SVA", $sformatf("Illegal FSM state: %0b", fsm_state))
```

### Pattern 5: Reset Value Check

```systemverilog
// One assertion per register, from spec_analysis.registers[].reset_value
localparam RESET_VALUE = 8'h00;  // from spec

// Check reset VALUE after reset RELEASE ($rose), not reset assertion ($fell).
// $rose(rst_n) = reset deasserts (0→1), register should hold spec-defined default.
property reg_reset_value;
  @(posedge clk)
  $rose(rst_n) |-> (reg_signal === RESET_VALUE);
endproperty
assert property (reg_reset_value)
  else `uvm_error("SVA", $sformatf("Reset value mismatch: expected=%0h actual=%0h", RESET_VALUE, reg_signal))
```

### Pattern 6: Frame Format (serial protocols)

```systemverilog
// Applicable: UART, SPI, I2C, any serial frame protocol
// FRAME_LEN from spec_analysis.interfaces frame format definition
localparam FRAME_LEN = 10;  // e.g. 1 start + 8 data + 1 stop

property frame_complete;
  @(posedge bit_clk) disable iff (!rst_n)
  start_condition |-> ##FRAME_LEN end_condition;
endproperty
cover property (frame_complete);  // Use cover, not assert — frame timing varies
```

## 3. Bind Construct Pattern

```systemverilog
// Assertion module — standalone, not inside DUT
module dut_sva #(
  parameter NUM_STATES = 4,
  parameter ADDR_WIDTH = 8
)(
  input logic                    clk,
  input logic                    rst_n,
  input logic [NUM_STATES-1:0]   state,
  input logic [ADDR_WIDTH-1:0]   addr
  // ... other observed signals
);

  // === Protocol Assertions ===
  // ... (from patterns above)

  // === FSM Assertions ===
  // ... (from patterns above)

  // === Reset Assertions ===
  // ... (from patterns above)

endmodule

// Bind — attaches assertion module to DUT without modifying RTL
bind target_dut_module dut_sva #(
  .NUM_STATES(4),
  .ADDR_WIDTH(8)
) u_sva (
  .clk(clk),
  .rst_n(rst_n),
  .state(fsm_state_reg),
  .addr(paddr)
);
```

## 4. assert vs cover vs assume Quick Reference

| Keyword | Simulation behavior | Formal behavior | Use for |
|---------|--------------------|-----------------| --------|
| `assert property` | Violation → UVM_ERROR | Prover checks it holds | Rules that must always be true |
| `cover property`  | Records if event occurred | Prover finds witness | Rare events, coverage supplement |
| `assume property` | Same as assert (check) | Constrains input space | Input constraints for formal only |

## 5. Common SVA Pitfalls

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Formal argument for delay | `Error: not a constant` | Use `localparam` instead |
| Missing `disable iff` | False failures during reset | Add `disable iff (!rst_n)` |
| `$isunknown` on multi-bit | Only checks bit-0 in some tools | Use `^fsm_state === 1'bx` or check each bit |
| Assert in `initial` block | Fires at time 0 before reset | Use concurrent assertion with clock |
| Overly complex sequence | Hard to debug, slow simulation | Break into smaller properties |
