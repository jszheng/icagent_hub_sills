# Stage 4 Output Schema

## Generated Files

| File | Content | Validation |
|------|---------|------------|
| `uvm_tb/<project>_property.sv` | SVA assertion module | All properties have `disable iff (!rst_n)` |
| `uvm_tb/<project>_bind.sv` | Bind statements (always separate file — never inline in testbench.sv) | Target module and signals exist in RTL |

## Assertion Summary

After generation, print:

| Category | Count | Priority |
|----------|-------|----------|
| Protocol compliance | N | P0 |
| FSM legality | N | P0 |
| Reset values | N | P0 |
| Register access | N | P1 |
| Error handling | N | P1 |
| Cover properties | N | — |

## Assertion Module Structure

```systemverilog
module <project>_sva #(
  // Parameters derived from spec_analysis
)(
  // Ports: clk, rst_n, observed signals
);

  // --- Protocol Compliance (P0) ---
  // ...

  // --- FSM Legality (P0) ---
  // ...

  // --- Reset Values (P0) ---
  // ...

  // --- Register Access (P1) ---
  // ...

  // --- Error Handling (P1) ---
  // ...

  // --- Cover Properties ---
  // ...

endmodule
```
