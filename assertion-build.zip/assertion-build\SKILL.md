---
name: assertion-build
description: Use when the user needs to generate SystemVerilog Assertions (SVA) for a design. Produces assertion modules using bind construct (non-invasive to RTL). Primary focus is simulation assertions (assert/cover). Formal verification support (assume properties) is available on request but limited to guidance-level -no formal tool integration. Code generation only -compilation is Stage 5.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Assertion Build

Generate SVA assertion module and bind file from spec analysis and FSM analysis products.

## Boundaries

- **Uses bind construct only** -never modifies RTL source files
- **Spec-driven assertions**: properties derived from Spec/protocol behavior, NOT from RTL implementation
- Does not invoke EDA tools -compilation is Stage 5
- Assertion failures are non-fatal by default (UVM_ERROR), unless user requests fatal

## Input

| Item | Required | Source |
|------|----------|--------|
| spec_analysis.json | Yes | Stage 1 output or user-provided |
| fsm_analysis.json | No | Stage 1 output (needed for FSM assertions) |
| RTL source code | No | For confirming bind target module/signal names |

**Standalone mode**: user provides protocol timing rules and FSM structure verbally or in any format.

### Input Validation

Before starting, verify:
- `spec_analysis.json` exists and has:
  - `interfaces[]` array with at least one entry, each having `signals[]` with signal names and directions
  - `clock_reset` object with `clock_name` and `reset_name` (needed for assertion clock/reset binding)
  - `registers[]` array (needed for register access protocol assertions)
- If FSM assertions requested: `fsm_analysis.json` exists and has:
  - `fsm_list[]` array with at least one entry
  - Each FSM has `states[]` (non-empty), `transitions[]`, and `reset_state`
- If any required field is missing, report to user with specific missing field and suggest re-running Stage 1

## Workflow

### Step 0: Standalone Entry Check

If upstream artifacts are absent:
- `spec_analysis.json` missing ->prompt the user for:
  - Protocol timing rules (handshake signals, stability requirements, timing constraints)
  - Register access rules (which registers are RO/RW/WO, reset values)
  - Clock and reset signal names and polarity
- `fsm_analysis.json` missing ->prompt the user for:
  - FSM state names and encoding (if FSM assertions needed)
  - Valid state transitions
  - Reset state
  - Or skip FSM assertions if not needed
- RTL source missing ->prompt the user for:
  - DUT module name (bind target)
  - Signal names to observe (for bind port map)

### Commands

```bash
# Input: docs/spec_analysis.json, docs/fsm_analysis.json
# Output: SVA module in uvm_tb/, bind statements
```

### Step 1: Extract Assertion Requirements from Upstream Products

| Source | Assertion category | Priority |
|--------|-------------------|----------|
| `spec_analysis.interfaces[]` timing rules | Protocol compliance (handshake, signal stability) | P0 |
| `fsm_analysis.states[]` | FSM legality (no-X, legal state check) | P0 |
| `spec_analysis.registers[].reset_value` | Reset value check | P0 |
| `spec_analysis.registers[].access` | Register access rules (RO not writable) | P1 |
| `spec_analysis.error_conditions[]` | Error flag assertions | P1 |
| Scoreboard data path | Data integrity (handled in scoreboard, not here) | -|

### Step 2: Generate SVA Properties

Use patterns from [sva-patterns.md](references/sva-patterns.md). Key rules:

- `property` timing delays must use `parameter`/`localparam` (compile-time constants), NOT formal arguments
- Use `disable iff (!rst_n)` on all assertions to avoid reset-phase false failures
- One assertion module per bind target (typically one per DUT module)

### Step 3: Choose assert / cover / assume

| Keyword | Meaning | Use when |
|---------|---------|----------|
| `assert property` | Must always hold; violation = error | Protocol rules, FSM legality, reset values |
| `cover property` | Verify event happened at least once | Rare paths, corner cases, coverage supplement |
| `assume property` | Input constraint for formal tools (acts as assert in sim) | Formal verification environment only |

### Step 4: Generate Bind File

Use `bind` construct to attach assertions to DUT without modifying RTL:

```systemverilog
// Assertion module (standalone, not inside DUT)
module <dut>_assertions(
  input logic        clk,
  input logic        rst_n,
  input logic [N:0]  fsm_state,
  // ... other observed signals
);
  // All properties and assertions here
endmodule

// Bind statement (in testbench top or separate bind file)
bind <dut_module> <dut>_assertions u_assert(
  .clk(clk),
  .rst_n(rst_n),
  .fsm_state(<rtl_state_signal>),
  // ... port connections
);
```

### Step 5: Formal Verification (out of scope -guidance only)

This skill does **NOT** provide formal verification support. No formal tool integration (VC Formal, JasperGold, Questa Formal), no formal-specific templates, no `assume` property generation, no liveness checking.

If user requests formal verification:
1. Inform user that this skill only generates simulation assertions (`assert property`, `cover property`)
2. Recommend: simulation assertions generated by this skill can serve as a **starting point** for formal -but formal requires additional `assume` constraints and tool-specific setup that are outside this skill's scope
3. Do NOT generate `<project>_formal.sv` -this skill has no formal skeleton or verification flow to produce a meaningful formal file

## Output

| Item | Path |
|------|------|
| Assertion module | `uvm_tb/<project>_property.sv` |
| Bind statements | `uvm_tb/<project>_bind.sv` (always a separate file -never inline in testbench.sv) |

**Bind file decision rule**: Always use a separate `<project>_bind.sv` file, never embed bind statements inside `testbench.sv`. Reasons: (1) bind statements must compile after both RTL and assertion modules; separate file gives explicit compile-order control in `sim/flist`; (2) easier to exclude assertions by removing one file from flist; (3) avoids testbench.sv becoming a dump for unrelated constructs.

## Self-Correction

| Check | Condition | Auto-fix |
|-------|-----------|----------|
| Bind target exists | Module name in bind statement exists in RTL | Flag error if not found |
| Signal name exists | Signals in port map exist in target module | Flag error with suggestions |
| Parameter type | Timing delays use localparam, not formal argument | Replace with localparam |
| Reset guard | Every concurrent assertion has `disable iff` | Add `disable iff (!rst_n)` |
| No duplicate assertions | Same property not asserted twice | Remove duplicate |

**Maximum rounds**: 3 rounds of self-correction. This limit is non-negotiable.

**Escalation trigger**: Produce `escalation_report.json` when ANY of:
- Bind target module not found in RTL (module name mismatch)
- >3 signal names in bind port map not found in target module
- SVA property uses unsupported system function for target simulator

Format follows the unified escalation schema (defined in spec-to-testplan/references/output-schema.md#escalation_reportjson). Human action: verify RTL module names and signal names, confirm SVA compatibility, re-run.

## Standards Reference

- IEEE 1800-2017: Assertions (immediate & concurrent), Sequences, Properties, bind construct
- IEEE 1800-2017: System functions `$onehot`, `$onehot0`, `$isunknown`, `$stable`, `$rose`, `$fell`
- IEEE 1800-2017: `assert`, `cover`, `assume` semantics

## References

- [sva-patterns.md](references/sva-patterns.md) -Read during Step 2 for SVA code patterns: handshake, stability, FSM, reset, frame assertions, and bind construct examples
- [output-schema.md](references/output-schema.md) -Read after generation to verify assertion module structure and summary format
- [sva_module_skeleton.sv](assets/skeletons/sva_module_skeleton.sv) -SVA assertion module skeleton
- [bind_skeleton.sv](assets/skeletons/bind_skeleton.sv) -bind statement skeleton
- [sva_apb_handshake.sv](assets/examples/sva_apb_handshake.sv) -complete APB protocol assertion example
- [sva_fsm_checks.sv](assets/examples/sva_fsm_checks.sv) -parameterized FSM check example
