// =============================================================================
// SVA Bind File Skeleton
// Replace placeholders before use:
//   <DUT_MODULE>  - DUT module name to bind into (e.g., apb_uart)
//   <SVA_MODULE>  - SVA assertion module name (e.g., apb_uart_sva)
//   <PORT_MAP>    - Port connection list (e.g., .PCLK(PCLK), .PRESETn(PRESETn))
// =============================================================================

bind <DUT_MODULE> <SVA_MODULE> u_sva (
  <PORT_MAP>
);
