---
name: chip-design-formal
description: Use when checking logical equivalence between RTL and gate-level netlist (LEC), or between pre-ECO and post-ECO netlists, or running formal property verification (FPV). Trigger when the user mentions LEC, equivalence checking, Formality, Conformal, SymbiYosys, netlist verification, or post-ECO checking.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-formal: Formal Verification (LEC + FPV)

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. **SymbiYosys (sby)** is the recommended default for formal property verification (FPV/BMC) — supports multiple open-source solvers (Z3, Boolector, Yices2), no license required
2. **Yosys `equiv_*` commands** provide basic equivalence checking (LEC) for open-source flows — sufficient for Yosys-synthesized netlists
3. **Limitations**: Yosys equiv is less mature than Formality/Conformal for complex LEC (clock-gating, scan chain reordering, large designs) — this is documented honestly
4. Commercial tools (Formality, Conformal LEC) are supported but listed as optional — only use when the user explicitly selects them or when open-source LEC cannot resolve all compare points
5. Detection order: `sby` and `yosys` are checked before commercial tool commands

---

## Use Mode

This skill supports two modes:

**Full formal verification flow:**
- Follow the orchestrated flow: FPV (property verification) + LEC (equivalence checking) → signoff
- Run LEC after every synthesis compile and every ECO batch
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules for targeted LEC failure analysis or FPV property debugging

**Critical constraints:**
- LEC must be run after every netlist change (synthesis, ECO, scan insertion) — not just at final signoff
- Unmatched points must be root-caused, never waived without RTL team approval
- Post-ECO: run LEC after every ECO batch, do not accumulate ECOs without equivalence check

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| formal_fpv | `sby`, `jg`, `vcf`, `qformal` | Optional (SymbiYosys recommended for FPV) |
| formal_equiv | `yosys`, `formality`, `fm_shell`, `lec` | Required for LEC (at least one; Yosys recommended) |

### Tool Execution

Open-source (recommended):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| SymbiYosys (FPV) | `sby -f <task>.sby` | BMC, induction, cover; supports Z3, Boolector, Yices2 solvers | Open-source (recommended for FPV) |
| Yosys equiv (LEC) | `yosys -p "equiv_make gold gate; equiv_induct; equiv_status"` | Basic LEC for Yosys-synthesized netlists | Open-source (recommended for LEC) |

Commercial (optional):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| Formality | `fm_shell -f <script.tcl>` | `read_sverilog -r` for reference, `read_verilog -i` for implementation | Commercial — Synopsys |
| Conformal LEC | `lec -f <script.do>` | `read_design -golden` / `read_design -revised` | Commercial — Cadence |
| JasperGold | `jg` | FPV + coverage; property-based verification | Commercial — Cadence |
| VC Formal | `vcf` | FPV; Synopsys formal suite | Commercial — Synopsys |
| Questa Formal | `qformal` | FPV; Siemens formal suite | Commercial — Siemens |

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `formal_equiv` and `formal_fpv` capabilities are configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which sby`, `which yosys` first (open-source), then `which fm_shell`, `which formality`, `which lec`, `which jg` (commercial)
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. Required capability with no tool detected → inform user and stop; suggest installing SymbiYosys (`pip install symbiyosys` or from source) and Yosys as open-source option

---

## Stage Workflow

### Stage 1: fpv_property_verification (optional)

Run formal property verification to prove or disprove key design properties.

**Domain Rules:**
1. Write properties in concurrent SVA
2. Group properties by feature in separate `.sva` files
3. Constrain environment with assumptions that match valid stimulus
4. Run vacuity check: assumption disabled → property should NOT hold
5. Bound liveness properties (`##[1:BOUND]`)

**SymbiYosys Task File Template (`.sby`):**
```
[options]
mode bmc
depth <pipeline_depth + 2>

[engines]
smtbmc z3

[script]
read -formal <rtl_files>
prep -top <top_module>

[files]
<rtl_files>
```

**Solver Selection Guidance:**
- Z3: faster for arithmetic-heavy designs
- Boolector: faster for pure Boolean / bit-vector problems
- Yices2: good general-purpose alternative

**Common Issues & Fixes:**

| Issue | Fix |
|-------|-----|
| Vacuous proofs | Over-constrained assumptions — run `sby --vacuity`; relax constraints one at a time |
| Insufficient bound depth | Set `depth >= pipeline_depth + 2` in `.sby` file |
| Multi-clock designs | Use `sby --multiclock` flag |

**QoR Metrics:**
- All P0 properties: PROVEN or clearly UNREACHABLE
- No vacuous proofs
- CEX traced and classified for any failures

**Output Required:**
- SVA property files
- SymbiYosys run report (proven/failed/vacuous per property)
- CEX waveform descriptions for any failures

---

### Stage 2: lec_setup

Prepare reference and implementation designs for equivalence checking.

**Domain Rules:**
1. Reference (golden): RTL source files or pre-ECO netlist
2. Implementation (revised): post-synthesis netlist or post-ECO netlist
3. Both designs must use the same library for linking
4. Yosys LEC: both golden and gate netlist must be readable by Yosys (`read_verilog`)
5. Formality only: provide the synthesis `.svf` (setup verification file) from DC if available
6. Refer to `references/knowledge.md` for tool-specific library loading quirks before writing LEC script

**Setup Checklist:**
- [ ] Reference design files identified (RTL or pre-ECO netlist)
- [ ] Implementation netlist identified (post-synthesis output)
- [ ] Library files available and format compatible with LEC tool (`.lib` for Yosys; `.db` for Formality)
- [ ] SVF file from synthesis available (Formality only — optional but recommended)

**Output Required:**
- LEC run script with correct file paths and library setup

---

### Stage 3: lec_run

Run logical equivalence checking and analyze results.

See [references/formal-rules.md](references/formal-rules.md) for the complete Yosys equiv LEC script template.

**Yosys LEC limitations (be aware):**
- Less robust than Formality/Conformal for clock-gating equivalence
- Scan chain reordering not automatically handled
- For complex designs, if Yosys equiv reports unresolved points, escalate to commercial LEC tool

See [references/formal-rules.md](references/formal-rules.md) for Formality and Conformal LEC flow details.

See [references/formal-rules.md](references/formal-rules.md) for common LEC failure patterns and fixes.

**QoR Metrics:**
- All compare points: SUCCEEDED / EQUIVALENT
- 0 UNMATCHED points
- 0 ABORTED points

**Output Required:**
- LEC passing/failing/unmatched point reports
- EQUIVALENT or NON-EQUIVALENT verdict

---

### Stage 4: lec_signoff

Final review confirming equivalence is verified.

**Sign-off Checklist:**
- [ ] LEC: 100% SUCCEEDED (all compare points equivalent)
- [ ] 0 unmatched points
- [ ] 0 failing points
- [ ] LEC run after most recent netlist change (synthesis or ECO)

**Output Required:**
- LEC sign-off report
- LEC clean record

---

## Sign-off Hard Gates

Formal signoff requires ALL of these conditions:

- `lec_failing_points == 0` (all points equivalent)
- `lec_unmatched_points == 0` (all points mapped)
- `lec_run_after_latest_netlist_change == true` (no stale result)
- FPV (if run): all P0 properties PROVEN, no vacuous proofs

---

## Loop-Back Rules

- `lec_run` failing points → check synthesis script / SDC → re-synthesize → retry `lec_run` (max 3x)
- `lec_run` unmatched points → check library linkage → retry `lec_run` (max 3x)
- `lec_run` Yosys equiv cannot resolve → escalate to commercial LEC tool if available
- `fpv` CEX on P0 property → suspend flow, report to RTL team, wait for fix

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and known tool quirks. Use this to inform stage decisions — for example, known vacuity patterns, solver preferences for the design type, or LEC failure modes for the synthesis tool used.

During a formal verification campaign, it is useful to record key outcomes such as property results, bound depths used, CEX root causes, and LEC status. If the project uses a persistent knowledge system, these can be written out for reuse across campaigns. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/formal-rules.md](references/formal-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/formal-flow.md](references/formal-flow.md) — broader flow narrative
