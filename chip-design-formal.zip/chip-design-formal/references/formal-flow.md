# Formal Flow Reference

The original plugin combines FPV and LEC into one coordinated signoff path.

## Flow Overview

Input:
- spec intent
- RTL or gate-level representation
- assertions / assumptions

Output:
- property plan
- proof / CEX analysis
- LEC result
- formal signoff status
