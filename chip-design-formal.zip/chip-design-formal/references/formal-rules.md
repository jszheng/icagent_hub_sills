# Formal Rules Reference

## Stage Sequence

`property_planning -> environment_setup -> fpv_run -> cex_analysis -> lec_run -> formal_signoff`

## Loop-back Rules

- real RTL bug from CEX -> wait for RTL fix, then rerun FPV
- vacuous proof -> return to `environment_setup` (max 3x)
- inconclusive proofs -> rerun with stronger setup or higher bounds (max 3x)
- LEC unmatched points -> rerun/fix `lec_run` (max 3x)

## High-level Rules

- map spec features to properties and cover points
- validate assumption quality before trusting proofs
- classify each CEX before deciding the next step
- treat vacuity and unresolved P0 properties as blockers
- always rerun LEC after netlist-affecting changes

## Best fit for this reference

- property patterns and planning rules
- assumption / vacuity guidance
- counterexample analysis methods
- LEC mismatch causes
- solver or tool flag guidance
- formal signoff criteria

## Yosys Equiv LEC Script Template

```tcl
# Read golden (RTL)
read_verilog -sv <rtl_files>
prep -top <top> -flatten
splitnets -ports
design -stash gold

# Read revised (gate netlist)
read_verilog <netlist>
read_liberty -lib <lib.lib>
prep -top <top> -flatten
splitnets -ports
design -stash gate

# Compare
design -copy-from gold -as gold <top>
design -copy-from gate -as gate <top>
equiv_make gold gate
equiv_induct
equiv_status -assert
```

## Formality Flow (Commercial — Synopsys)

1. Read reference: `read_sverilog -r <rtl_files>`
2. Read implementation: `read_verilog -i <netlist>`
3. Set top for both: `set_top r:/WORK/<top>` and `set_top i:/WORK/<top>`
4. Match: `match` — maps sequential and combinational compare points
5. Verify: `verify` — checks equivalence of all mapped points
6. Report: SUCCEEDED (equivalent) / FAILED (non-equivalent) / UNMATCHED

## Conformal Flow (Commercial — Cadence)

1. `read_design -golden <rtl_files>`
2. `read_design -revised <netlist>`
3. Run comparison

## Common LEC Failure Patterns and Fixes

| Failure | Fix |
|---------|-----|
| Yosys equiv unresolved after `equiv_induct` | Try `equiv_simple` first, then `equiv_struct`, then `equiv_induct`; increase SAT solver effort |
| Unresolved references in netlist (Formality — commercial) | Verify `link_library` includes all libraries; add `*` wildcard |
| Optimizer removed logic (Formality — commercial) | Check `report_removed_points`; add `set_dont_touch` in synthesis if needed |
| Clock-gating cells unmatched (Formality — commercial) | Set `set_constant` on scan-enable or provide clock-gating guidance |
| Scan chain reordering (Formality — commercial) | Use `set_scan_chain_aware off` |
| SVF not loaded (Formality — commercial) | Load with `read_svf <file.svf>` before `match` |
