# Formal Verification Domain Knowledge

## Known Failure Patterns

- **Vacuous proofs from over-constrained environment**: A vacuous proof means the `assume`
  constraints make the input space unreachable. Run vacuity check (`sby --vacuity`) after every
  environment iteration. If vacuity is detected, relax constraints one at a time.
- **Insufficient bound depth**: SymbiYosys `--depth` must be set to at least `pipeline_depth + 2`
  to exercise all pipeline stages. Shallow bounds produce false "PASS" results for properties that
  only fire at the end of a pipeline.
- **LEC failures after synthesis**: LEC unmatched points after synthesis almost always indicate
  clock-gating cells that need equivalence mapping. Provide the synthesis tool's clock-gating cell
  list to the LEC tool before running.

## Successful Tool Flags

### Open-source (recommended)

- `sby -f <task>.sby --depth <N>` — always set `--depth` explicitly; never rely on default bound.
- `sby --multiclock` — required when the design has multiple clock domains; single-clock mode
  silently ignores cross-domain paths.
- `sby --vacuity` — run after every iteration to catch over-constrained assumptions.
- **Z3 vs Boolector for bitvector arithmetic**: Z3 is generally faster for designs with heavy
  arithmetic; Boolector outperforms Z3 on pure Boolean problems. Try both when a proof runs
  for > 30 minutes without result.
- **Yosys `prep` before sby**: Running `yosys -p "prep -top <top>"` on the design before
  invoking SymbiYosys catches synthesis elaboration errors early and reduces proof setup time.
- **Yosys equiv for LEC**: `equiv_make gold gate; equiv_simple; equiv_struct; equiv_induct; equiv_status`
  provides basic equivalence checking for Yosys-synthesized netlists without commercial tools.

### Commercial (optional)

- `jg -allow_empty_cex` — prevents JasperGold from treating an empty CEX set as proof of vacuity;
  use with explicit vacuity check script.
- **Formality requires `read_db`**: Must explicitly call `read_db <path>.db` before
  reading the implementation netlist.
- **Formality `link_library` must include `*` wildcard**: Set as `[list * <libname>.db]`.
- **Formality SVF improves matching**: Load synthesis SVF file (`set_svf <path>/default.svf`)
  before reading designs — significantly improves compare point matching accuracy.

## Notes

- CEX found for a P0 property = hard blocker. Suspend the formal flow, report to the RTL
  team with the full counterexample trace, and do not retry until RTL fix is confirmed.
