# Stage 7 Output Schema

## coverage_triage.json

```json
{
  "stage": "coverage-closure",
  "timestamp": "ISO-8601",
  "overall_metrics": {
    "line": "float (percentage)",
    "branch": "float",
    "toggle": "float",
    "fsm_state": "float",
    "fsm_transition": "float",
    "condition": "float",
    "functional": "float"
  },
  "gaps": [
    {
      "metric": "line | branch | toggle | fsm_state | fsm_transition | condition | functional",
      "module": "string",
      "item": "string — specific uncovered item",
      "likely_cause": "missing_scenario | wrong_config | dead_code | sampling_issue | encoding_mismatch",
      "confidence": "high | medium | low",
      "recommended_action": "string",
      "targeted_by": "string | null — test name if already targeted"
    }
  ],
  "rounds": [
    {
      "round": "integer",
      "tests_generated": "integer",
      "coverage_delta": "float",
      "cumulative_coverage": {"line": "float", "branch": "float", "...": "float"}
    }
  ],
  "exclusion_recommendations": [
    {
      "module": "string",
      "item": "string",
      "reason": "dead_code | unreachable_ifdef | external_fault_only",
      "human_approved": "boolean — must be true before excluding"
    }
  ],
  "final_status": "targets_met | gaps_remaining | escalated"
}
```

## Industry Coverage Targets (Default)

| Metric | Target | Source |
|--------|--------|--------|
| Line | 95% | Industry standard |
| Branch | 90% | Industry standard |
| Toggle | 85% | Industry standard |
| FSM State | 100% | All states must be reachable |
| FSM Transition | 90% | Industry standard |
| Condition | 85% | Industry standard |
| Functional | 100% | All bins must be reachable (use illegal_bins for unreachable) |
