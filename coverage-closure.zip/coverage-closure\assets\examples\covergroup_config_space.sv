// =============================================================================
// Example: Configuration-Space Covergroup (generic serial controller)
// Demonstrates coverpoints, cross, ignore_bins, illegal_bins
// =============================================================================

class config_space_coverage extends uvm_subscriber #(config_transaction);
  `uvm_component_utils(config_space_coverage)

  // --------------------------------------------------------------------------
  // Covergroup
  // --------------------------------------------------------------------------
  covergroup cg_config_space with function sample(config_transaction txn);

    // --- Data width ---
    cp_data_width: coverpoint txn.data_width {
      bins width_5 = {5};
      bins width_6 = {6};
      bins width_7 = {7};
      bins width_8 = {8};
      illegal_bins bad_width = {[0:4], [9:$]};
    }

    // --- Parity mode ---
    cp_parity_mode: coverpoint txn.parity_mode {
      bins none = {0};
      bins odd  = {1};
      bins even = {2};
      illegal_bins reserved = {[3:$]};
    }

    // --- Stop bits ---
    cp_stop_bits: coverpoint txn.stop_bits {
      bins one      = {1};
      bins one_half = {2};
      bins two      = {3};
      illegal_bins bad_stop = {0, [4:$]};
    }

    // --- Baud rate divisor ---
    cp_baud_divisor: coverpoint txn.baud_divisor {
      bins low    = {[1:15]};
      bins mid    = {[16:255]};
      bins high   = {[256:65535]};
      illegal_bins zero = {0};
    }

    // --- FIFO depth setting ---
    cp_fifo_depth: coverpoint txn.fifo_depth {
      bins depth_1  = {1};
      bins depth_4  = {4};
      bins depth_8  = {8};
      bins depth_16 = {16};
    }

    // --- Flow control ---
    cp_flow_ctrl: coverpoint txn.flow_ctrl_en {
      bins disabled = {0};
      bins enabled  = {1};
    }

    // --- Cross: data_width x parity_mode ---
    cx_width_parity: cross cp_data_width, cp_parity_mode;

    // --- Cross: data_width x stop_bits (with ignore) ---
    cx_width_stop: cross cp_data_width, cp_stop_bits {
      // 5-bit data with 2 stop bits is uncommon; ignore to reduce bin count
      ignore_bins ig_5bit_2stop = binsof(cp_data_width.width_5)
                                && binsof(cp_stop_bits.two);
    }

    // --- Cross: parity x flow control ---
    cx_parity_flow: cross cp_parity_mode, cp_flow_ctrl;

  endgroup : cg_config_space

  // --------------------------------------------------------------------------
  // Constructor
  // --------------------------------------------------------------------------
  function new(string name = "config_space_coverage", uvm_component parent = null);
    super.new(name, parent);
    cg_config_space = new();
  endfunction : new

  // --------------------------------------------------------------------------
  // write
  // --------------------------------------------------------------------------
  virtual function void write(config_transaction t);
    cg_config_space.sample(t);
  endfunction : write

  // --------------------------------------------------------------------------
  // report_phase
  // --------------------------------------------------------------------------
  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info(get_type_name(), $sformatf(
      "\n========== Config Space Coverage ==========\n"  +
      "  cg_config_space: %.2f%%\n"                      +
      "============================================",
      cg_config_space.get_inst_coverage()), UVM_LOW)
  endfunction : report_phase

endclass : config_space_coverage
