// =============================================================================
// Functional Coverage Collector Skeleton
// Project: <PROJECT>
// Auto-generated template — replace placeholders before use
// =============================================================================

class <PROJECT>_coverage extends uvm_subscriber #(<TRANSACTION_TYPE>);
  `uvm_component_utils(<PROJECT>_coverage)

  // --------------------------------------------------------------------------
  // Covergroup definition
  // --------------------------------------------------------------------------
  covergroup cg_<PROJECT> with function sample(<TRANSACTION_TYPE> txn);

    // --- Coverpoints ---
    // Replace <COVERPOINTS> with actual coverpoint definitions
    // Example:
    // cp_addr: coverpoint txn.addr {
    //   bins low    = {[0:7]};
    //   bins mid    = {[8:15]};
    //   bins high   = {[16:31]};
    // }
    //
    // cp_data: coverpoint txn.data {
    //   bins zero    = {0};
    //   bins nonzero = {[1:$]};
    // }
    <COVERPOINTS>

    // --- Cross coverage ---
    // Replace <CROSSES> with actual cross definitions
    // Example:
    // cx_addr_data: cross cp_addr, cp_data {
    //   ignore_bins ig = binsof(cp_addr.low) && binsof(cp_data.zero);
    // }
    <CROSSES>

  endgroup : cg_<PROJECT>

  // --------------------------------------------------------------------------
  // Constructor
  // --------------------------------------------------------------------------
  function new(string name = "<PROJECT>_coverage", uvm_component parent = null);
    super.new(name, parent);
    cg_<PROJECT> = new();
  endfunction : new

  // --------------------------------------------------------------------------
  // write — called automatically by analysis port
  // --------------------------------------------------------------------------
  virtual function void write(<TRANSACTION_TYPE> t);
    cg_<PROJECT>.sample(t);
  endfunction : write

  // --------------------------------------------------------------------------
  // report_phase — print coverage summary
  // --------------------------------------------------------------------------
  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info(get_type_name(), $sformatf(
      "\n========== Coverage Summary ==========\n"  +
      "  Covergroup: cg_<PROJECT>\n"                +
      "  Coverage:   %.2f%%\n"                       +
      "======================================",
      cg_<PROJECT>.get_inst_coverage()), UVM_LOW)
  endfunction : report_phase

endclass : <PROJECT>_coverage
