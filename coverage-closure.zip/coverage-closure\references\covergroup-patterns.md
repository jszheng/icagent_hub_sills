# Covergroup Patterns

Reference for IEEE 1800-2017 functional coverage design.

## Covergroup Design Methodology

Derive covergroup structure from `spec_analysis.json`:

| spec_analysis field | Covergroup type | Derivation method |
|---------------------|----------------|-------------------|
| `registers` (config fields) | Config space coverage | One coverpoint per config field, bins from valid values |
| `fsm` / `fsm_analysis` | FSM state + transition coverage | State bins from enumerated states, transition bins from valid edges |
| `registers` (all addresses) | Register access coverage | Address coverpoint crossed with read/write direction |
| `error_conditions` | Error injection coverage | Error type coverpoint crossed with operating modes |

## Code Patterns

### Pattern 1: Config Space Coverage

Transaction-level sampling using `with function sample(...)`. Fields derived from `spec_analysis.registers`.

```systemverilog
covergroup cg_config with function sample(
    bit [1:0] data_width,
    bit [1:0] parity_mode,
    bit       stop_bits,
    bit       flow_ctrl
);
    option.per_instance = 1;
    option.name = "config_space_cov";

    cp_data_width : coverpoint data_width {
        bins width_5 = {2'b00};
        bins width_6 = {2'b01};
        bins width_7 = {2'b10};
        bins width_8 = {2'b11};
    }

    cp_parity_mode : coverpoint parity_mode {
        bins none  = {2'b00};
        bins even  = {2'b01};
        bins odd   = {2'b10};
        bins stick = {2'b11};
    }

    cp_stop_bits : coverpoint stop_bits {
        bins one = {1'b0};
        bins two = {1'b1};
    }

    cp_flow_ctrl : coverpoint flow_ctrl {
        bins disabled = {1'b0};
        bins enabled  = {1'b1};
    }

    // Cross only dimensions with verification meaning
    cx_width_parity : cross cp_data_width, cp_parity_mode {
        // Total bins: 4 x 4 = 16 (acceptable)
    }

    cx_width_stop : cross cp_data_width, cp_stop_bits {
        // Total bins: 4 x 2 = 8 (acceptable)
    }
endgroup
```

### Pattern 2: FSM Coverage

Clock-level sampling for per-cycle state tracking. States and transitions from `fsm_analysis`.

```systemverilog
covergroup cg_fsm @(posedge clk);
    option.per_instance = 1;
    option.name = "fsm_cov";

    cp_state : coverpoint dut_state {
        bins idle    = {STATE_IDLE};
        bins active  = {STATE_ACTIVE};
        bins wait_st = {STATE_WAIT};
        bins done    = {STATE_DONE};
        bins error   = {STATE_ERROR};
        illegal_bins unknown = default;
    }

    cp_transitions : coverpoint dut_state {
        bins idle_to_active  = (STATE_IDLE   => STATE_ACTIVE);
        bins active_to_wait  = (STATE_ACTIVE => STATE_WAIT);
        bins active_to_done  = (STATE_ACTIVE => STATE_DONE);
        bins active_to_error = (STATE_ACTIVE => STATE_ERROR);
        bins wait_to_active  = (STATE_WAIT   => STATE_ACTIVE);
        bins wait_to_done    = (STATE_WAIT   => STATE_DONE);
        bins error_to_idle   = (STATE_ERROR  => STATE_IDLE);
        bins done_to_idle    = (STATE_DONE   => STATE_IDLE);
    }
endgroup
```

### Pattern 3: Register Access Coverage

Transaction-level sampling. Cross address with direction, using `ignore_bins` to exclude invalid access types.

```systemverilog
covergroup cg_reg_access with function sample(
    bit [7:0] addr,
    bit       is_write
);
    option.per_instance = 1;
    option.name = "reg_access_cov";

    cp_addr : coverpoint addr {
        bins ctrl_reg   = {8'h00};
        bins status_reg = {8'h04};
        bins data_reg   = {8'h08};
        bins config_reg = {8'h0C};
        bins intr_reg   = {8'h10};
        ignore_bins reserved = {[8'h14:8'hFF]};
    }

    cp_direction : coverpoint is_write {
        bins read  = {1'b0};
        bins write = {1'b1};
    }

    cx_addr_dir : cross cp_addr, cp_direction {
        // Ignore writes to read-only registers
        ignore_bins ro_write = binsof(cp_addr.status_reg) && binsof(cp_direction.write);
        // Ignore reads to write-only registers
        ignore_bins wo_read  = binsof(cp_addr.ctrl_reg) && binsof(cp_direction.read);
    }
endgroup
```

### Pattern 4: Error Injection Coverage

Transaction-level sampling. Cross error type with operating mode.

```systemverilog
covergroup cg_error_injection with function sample(
    bit [2:0] error_type,
    bit [1:0] operating_mode
);
    option.per_instance = 1;
    option.name = "error_injection_cov";

    cp_error_type : coverpoint error_type {
        bins no_error     = {3'b000};
        bins parity_err   = {3'b001};
        bins framing_err  = {3'b010};
        bins overflow_err = {3'b011};
        bins underflow_err= {3'b100};
        illegal_bins reserved = {[3'b101:3'b111]};
    }

    cp_mode : coverpoint operating_mode {
        bins normal     = {2'b00};
        bins loopback   = {2'b01};
        bins low_power  = {2'b10};
        illegal_bins reserved = {2'b11};
    }

    cx_error_mode : cross cp_error_type, cp_mode {
        // No errors injected in low_power mode (not supported)
        ignore_bins lp_errors = binsof(cp_mode.low_power) &&
                                !binsof(cp_error_type.no_error);
    }
endgroup
```

## Cross Coverage Control Rules

1. **Only cross meaningful dimensions**: do not cross fields that have no functional relationship
2. **Use `ignore_bins`** for unreachable or untestable combinations
3. **Use `illegal_bins`** for combinations that must never occur (assertion-like)
4. **Total bins per cross < 1000**: if exceeding, add `ignore_bins` or split into multiple covergroups
5. **Document the rationale** for every `ignore_bins` and `illegal_bins`

## Sampling Guide

| Sampling method | When to use | Rationale |
|----------------|-------------|-----------|
| `with function sample(...)` | Transaction-level coverage (config, register access, error injection) | Preferred -- samples exactly when a transaction completes, avoids redundant samples |
| `@(posedge clk)` | FSM state and transition coverage | Needed for per-cycle state tracking to capture all transitions |
| `@(event)` | Interrupt events, error detection events | Samples at the exact moment an asynchronous event fires |

**General preference**: `with function sample()` > `@(posedge clk)` > `@(event)`

Transaction-level sampling is preferred because it avoids sampling noise from idle cycles and directly ties coverage to meaningful verification events.
