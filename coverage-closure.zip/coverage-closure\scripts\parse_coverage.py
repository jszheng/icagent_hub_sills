#!/usr/bin/env python3
"""
Coverage Report Parser for Stage 7: Coverage Closure

Parses coverage text reports from VCS urg, Xcelium imc, or generic text format.
Extracts metrics, identifies gaps, and outputs structured JSON.

Usage:
    python3 parse_coverage.py <coverage_report_directory> [--targets LINE:95,BRANCH:90,...]
    python3 parse_coverage.py <coverage_report_directory> --output result.json
"""

import argparse
import json
import os
import re
import sys


# Default coverage targets
DEFAULT_TARGETS = {
    "line": 95.0,
    "branch": 90.0,
    "toggle": 85.0,
    "fsm_state": 100.0,
    "fsm_transition": 90.0,
    "condition": 85.0,
}


def detect_format(report_dir):
    """Auto-detect coverage report format based on directory contents."""
    if not os.path.isdir(report_dir):
        # Single file provided
        return "generic_text"

    files = os.listdir(report_dir)
    filenames = [f.lower() for f in files]

    # VCS urg text format: hierarchy.txt + dashboard.txt
    if "hierarchy.txt" in filenames and "dashboard.txt" in filenames:
        return "vcs_urg"

    # Also check for VCS with different casing
    if any("hierarchy" in f and f.endswith(".txt") for f in filenames) and \
       any("dashboard" in f and f.endswith(".txt") for f in filenames):
        return "vcs_urg"

    # Xcelium imc: look for imc-specific markers
    if any("imc" in f.lower() for f in filenames) or \
       any(f.endswith(".ucd") for f in files) or \
       any(f.endswith(".ucm") for f in files):
        return "xcelium_imc"

    # Check for subdirectories that suggest VCS urg structure
    for f in files:
        fpath = os.path.join(report_dir, f)
        if os.path.isdir(fpath):
            subfiles = os.listdir(fpath)
            subnames = [s.lower() for s in subfiles]
            if "hierarchy.txt" in subnames and "dashboard.txt" in subnames:
                return "vcs_urg"

    return "unknown"


def parse_vcs_dashboard(filepath):
    """Parse VCS urg dashboard.txt for summary metrics."""
    summary = {}
    if not os.path.isfile(filepath):
        return summary

    with open(filepath, "r") as f:
        content = f.read()

    # Pattern: metric_name   covered/total   percentage
    # Common VCS dashboard patterns
    patterns = [
        (r"(?i)line\s+coverage[:\s]+(\d+\.?\d*)\s*%", "line"),
        (r"(?i)branch\s+coverage[:\s]+(\d+\.?\d*)\s*%", "branch"),
        (r"(?i)cond(?:ition)?\s+coverage[:\s]+(\d+\.?\d*)\s*%", "condition"),
        (r"(?i)toggle\s+coverage[:\s]+(\d+\.?\d*)\s*%", "toggle"),
        (r"(?i)fsm\s+state\s+coverage[:\s]+(\d+\.?\d*)\s*%", "fsm_state"),
        (r"(?i)fsm\s+trans(?:ition)?\s+coverage[:\s]+(\d+\.?\d*)\s*%", "fsm_transition"),
        (r"(?i)(?:overall|total)\s+coverage[:\s]+(\d+\.?\d*)\s*%", "overall"),
    ]

    for pattern, key in patterns:
        match = re.search(pattern, content)
        if match:
            summary[key] = float(match.group(1))

    # Also try table-style format:
    # Line   |  1234 / 1300  |  94.92%
    table_patterns = [
        (r"(?i)line\s*\|[^|]*\|\s*(\d+\.?\d*)\s*%", "line"),
        (r"(?i)branch\s*\|[^|]*\|\s*(\d+\.?\d*)\s*%", "branch"),
        (r"(?i)cond(?:ition)?\s*\|[^|]*\|\s*(\d+\.?\d*)\s*%", "condition"),
        (r"(?i)toggle\s*\|[^|]*\|\s*(\d+\.?\d*)\s*%", "toggle"),
        (r"(?i)fsm\s*state\s*\|[^|]*\|\s*(\d+\.?\d*)\s*%", "fsm_state"),
        (r"(?i)fsm\s*trans\s*\|[^|]*\|\s*(\d+\.?\d*)\s*%", "fsm_transition"),
    ]

    for pattern, key in table_patterns:
        if key not in summary:
            match = re.search(pattern, content)
            if match:
                summary[key] = float(match.group(1))

    # Try generic percentage extraction from lines containing metric keywords
    for line in content.splitlines():
        line_stripped = line.strip()
        if not line_stripped:
            continue
        pct_match = re.search(r"(\d+\.?\d*)\s*%", line_stripped)
        if not pct_match:
            continue
        pct = float(pct_match.group(1))
        line_lower = line_stripped.lower()

        if "line" in line_lower and "line" not in summary:
            summary["line"] = pct
        elif "branch" in line_lower and "branch" not in summary:
            summary["branch"] = pct
        elif "cond" in line_lower and "condition" not in summary:
            summary["condition"] = pct
        elif "toggle" in line_lower and "toggle" not in summary:
            summary["toggle"] = pct
        elif "fsm" in line_lower and "state" in line_lower and "fsm_state" not in summary:
            summary["fsm_state"] = pct
        elif "fsm" in line_lower and "trans" in line_lower and "fsm_transition" not in summary:
            summary["fsm_transition"] = pct

    return summary


def parse_vcs_hierarchy(filepath):
    """Parse VCS urg hierarchy.txt for per-module metrics."""
    modules = []
    if not os.path.isfile(filepath):
        return modules

    with open(filepath, "r") as f:
        content = f.read()

    # VCS hierarchy.txt typically has lines like:
    # module_name  line%  branch%  toggle%  ...
    # Try to find header line to determine column positions
    lines = content.splitlines()
    header_idx = -1
    col_map = {}

    for i, line in enumerate(lines):
        lower = line.lower()
        if ("line" in lower or "branch" in lower or "toggle" in lower) and \
           ("%" in lower or "coverage" in lower or "module" in lower or "instance" in lower):
            header_idx = i
            # Parse column positions from header
            tokens = re.split(r"\s{2,}|\t|\|", line)
            tokens = [t.strip() for t in tokens if t.strip()]
            for j, tok in enumerate(tokens):
                tok_lower = tok.lower()
                if "module" in tok_lower or "instance" in tok_lower or "name" in tok_lower:
                    col_map["name"] = j
                elif "line" in tok_lower:
                    col_map["line"] = j
                elif "branch" in tok_lower:
                    col_map["branch"] = j
                elif "cond" in tok_lower:
                    col_map["condition"] = j
                elif "toggle" in tok_lower:
                    col_map["toggle"] = j
                elif "fsm" in tok_lower and "state" in tok_lower:
                    col_map["fsm_state"] = j
                elif "fsm" in tok_lower and "trans" in tok_lower:
                    col_map["fsm_transition"] = j
            break

    if header_idx < 0:
        # No header found, try generic parsing
        return parse_hierarchy_generic(lines)

    # Parse data lines after header
    for i in range(header_idx + 1, len(lines)):
        line = lines[i].strip()
        if not line or line.startswith("-") or line.startswith("="):
            continue

        tokens = re.split(r"\s{2,}|\t|\|", line)
        tokens = [t.strip() for t in tokens if t.strip()]

        if len(tokens) < 2:
            continue

        module = {}
        for key, idx in col_map.items():
            if idx < len(tokens):
                val = tokens[idx]
                if key == "name":
                    module["name"] = val
                else:
                    # Extract percentage
                    pct_match = re.search(r"(\d+\.?\d*)", val)
                    if pct_match:
                        module[key] = float(pct_match.group(1))

        if "name" in module:
            modules.append(module)

    return modules


def parse_hierarchy_generic(lines):
    """Fallback parser for hierarchy data when header detection fails."""
    modules = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("-") or line.startswith("=") or line.startswith("#"):
            continue

        # Look for lines with a name followed by percentages
        tokens = re.split(r"\s{2,}|\t|\|", line)
        tokens = [t.strip() for t in tokens if t.strip()]

        if len(tokens) < 2:
            continue

        # First non-numeric token is likely the module name
        name = None
        metrics = []
        for tok in tokens:
            pct_match = re.search(r"(\d+\.?\d*)\s*%?$", tok)
            if pct_match and float(pct_match.group(1)) <= 100.0:
                metrics.append(float(pct_match.group(1)))
            elif name is None and not re.match(r"^\d", tok):
                name = tok

        if name and metrics:
            module = {"name": name}
            # Assume order: line, branch, toggle (common convention)
            metric_keys = ["line", "branch", "toggle", "condition", "fsm_state", "fsm_transition"]
            for j, val in enumerate(metrics):
                if j < len(metric_keys):
                    module[metric_keys[j]] = val
            modules.append(module)

    return modules


def parse_vcs_urg(report_dir):
    """Parse VCS urg text report directory."""
    summary = {}
    modules = []

    # Look for dashboard.txt and hierarchy.txt
    dashboard_path = os.path.join(report_dir, "dashboard.txt")
    hierarchy_path = os.path.join(report_dir, "hierarchy.txt")

    # Case-insensitive search
    for f in os.listdir(report_dir):
        if f.lower() == "dashboard.txt":
            dashboard_path = os.path.join(report_dir, f)
        elif f.lower() == "hierarchy.txt":
            hierarchy_path = os.path.join(report_dir, f)

    summary = parse_vcs_dashboard(dashboard_path)
    modules = parse_vcs_hierarchy(hierarchy_path)

    # Also check modinfo.txt for additional data
    modinfo_path = os.path.join(report_dir, "modinfo.txt")
    if os.path.isfile(modinfo_path):
        extra_modules = parse_vcs_hierarchy(modinfo_path)
        if extra_modules and not modules:
            modules = extra_modules

    return summary, modules


def parse_xcelium_imc(report_dir):
    """Parse Xcelium imc report directory.

    Xcelium imc text reports may use different formats than VCS urg.
    Common patterns:
      - 'Code Coverage Results' sections
      - 'Block Coverage: 85.5%' style lines
      - Tabular module-level breakdown

    Falls back to generic percentage extraction for compatibility.
    """
    summary = {}
    modules = []

    # Xcelium-specific metric name mapping
    xcelium_metric_map = {
        "block": "line",       # Xcelium 'block' ≈ VCS 'line'
        "expression": "condition",  # Xcelium 'expression' ≈ VCS 'condition'
        "toggle": "toggle",
        "fsm": "fsm_state",
        "branch": "branch",
        "line": "line",
        "condition": "condition",
    }

    for f in sorted(os.listdir(report_dir)):
        fpath = os.path.join(report_dir, f)
        if not os.path.isfile(fpath):
            continue
        # Accept .txt, .rpt, .report files
        if not any(fpath.endswith(ext) for ext in (".txt", ".rpt", ".report", ".log")):
            continue

        with open(fpath, "r", encoding="utf-8", errors="replace") as fh:
            content = fh.read()

        # Try Xcelium-specific patterns first
        for line in content.splitlines():
            line_stripped = line.strip()
            if not line_stripped:
                continue
            pct_match = re.search(r"(\d+\.?\d*)\s*%", line_stripped)
            if not pct_match:
                continue
            pct = float(pct_match.group(1))
            line_lower = line_stripped.lower()

            for xcel_key, std_key in xcelium_metric_map.items():
                if xcel_key in line_lower and std_key not in summary:
                    summary[std_key] = pct
                    break

        # Try to extract per-module data using generic hierarchy parser
        file_modules = parse_vcs_hierarchy(fpath)
        if file_modules:
            modules.extend(file_modules)

    # If no specific patterns matched, fall back to VCS-style parsing
    if not summary:
        for f in sorted(os.listdir(report_dir)):
            fpath = os.path.join(report_dir, f)
            if os.path.isfile(fpath) and f.endswith(".txt"):
                temp_summary = parse_vcs_dashboard(fpath)
                if temp_summary:
                    summary.update(temp_summary)

    return summary, modules


def parse_generic_text(report_path):
    """Parse generic coverage text (single file or directory)."""
    summary = {}
    modules = []

    if os.path.isfile(report_path):
        summary = parse_vcs_dashboard(report_path)
    elif os.path.isdir(report_path):
        for f in sorted(os.listdir(report_path)):
            fpath = os.path.join(report_path, f)
            if os.path.isfile(fpath) and f.endswith(".txt"):
                temp = parse_vcs_dashboard(fpath)
                summary.update(temp)

    return summary, modules


def identify_gaps(summary, modules, targets):
    """Identify coverage gaps below target thresholds."""
    gaps = []

    # Check summary-level gaps
    for metric, target in targets.items():
        if metric in summary and summary[metric] < target:
            gaps.append({
                "metric": metric,
                "module": "OVERALL",
                "value": summary[metric],
                "target": target,
                "deficit": round(target - summary[metric], 2),
            })

    # Check per-module gaps
    for mod in modules:
        mod_name = mod.get("name", "unknown")
        for metric, target in targets.items():
            if metric in mod and mod[metric] < target:
                gaps.append({
                    "metric": metric,
                    "module": mod_name,
                    "value": mod[metric],
                    "target": target,
                    "deficit": round(target - mod[metric], 2),
                })

    # Sort gaps by deficit (largest first)
    gaps.sort(key=lambda g: g["deficit"], reverse=True)
    return gaps


def parse_targets_string(targets_str):
    """Parse targets from command-line string like 'line:95,branch:90'."""
    targets = dict(DEFAULT_TARGETS)
    if not targets_str:
        return targets

    for pair in targets_str.split(","):
        pair = pair.strip()
        if ":" not in pair:
            continue
        key, val = pair.split(":", 1)
        key = key.strip().lower().replace(" ", "_")
        try:
            targets[key] = float(val.strip())
        except ValueError:
            print(f"Warning: ignoring unparseable target value: {pair}", file=sys.stderr)

    return targets


def main():
    parser = argparse.ArgumentParser(
        description="Parse coverage reports and identify gaps"
    )
    parser.add_argument(
        "report_path",
        help="Path to coverage report directory or file",
    )
    parser.add_argument(
        "--targets",
        default=None,
        help="Coverage targets as key:value pairs (e.g., 'line:95,branch:90')",
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Output JSON file path (default: stdout)",
    )
    parser.add_argument(
        "--format",
        choices=["vcs_urg", "xcelium_imc", "generic", "auto"],
        default="auto",
        help="Report format (default: auto-detect)",
    )

    args = parser.parse_args()

    report_path = os.path.abspath(args.report_path)
    if not os.path.exists(report_path):
        print(f"Error: path does not exist: {report_path}", file=sys.stderr)
        sys.exit(1)

    targets = parse_targets_string(args.targets)

    # Detect or use specified format
    if args.format == "auto":
        fmt = detect_format(report_path)
    else:
        fmt = args.format
        if fmt == "generic":
            fmt = "unknown"

    # Parse based on format
    if fmt == "vcs_urg":
        summary, modules = parse_vcs_urg(report_path)
    elif fmt == "xcelium_imc":
        summary, modules = parse_xcelium_imc(report_path)
    else:
        summary, modules = parse_generic_text(report_path)

    # Identify gaps
    gaps = identify_gaps(summary, modules, targets)

    # Build output
    result = {
        "format": fmt,
        "report_path": report_path,
        "summary": summary,
        "modules": modules,
        "gaps": gaps,
        "targets": targets,
    }

    output_json = json.dumps(result, indent=2)

    if args.output:
        output_path = os.path.abspath(args.output)
        with open(output_path, "w") as f:
            f.write(output_json)
            f.write("\n")
        print(f"Results written to {output_path}", file=sys.stderr)
    else:
        print(output_json)


if __name__ == "__main__":
    main()
