---
name: coverage-closure
description: Analyze coverage results, generate functional coverage code, and drive coverage-driven test generation to close gaps.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Coverage Closure

## Automation Level

This skill has a wide scope (analyze coverage ->generate covergroups ->generate tests ->iterate). The package provides:
- `scripts/parse_coverage.py` -automated coverage report parsing (VCS/Xcelium/Questa)
- `references/` -covergroup patterns, gap-to-stimulus mapping, triage patterns
- `assets/` -covergroup skeleton, examples, report templates

Sub-stage A (covergroup generation) and Sub-stage B (gap analysis) are well-supported by references and templates. Sub-stage C (test generation + iterative closure) relies heavily on agent capability -the agent writes test code, registers it, compiles, runs, and checks delta. There is no script that automates Sub-stage C end-to-end.

## Boundaries

- **Never modifies RTL source code** -only generates/modifies testbench files in `uvm_tb/`
- Coverage exclusions require human confirmation -never auto-exclude
- Never automatically lower coverage goals -functional coverage target is fixed at **100%**
- **Anti-cheating**: AI must never generate stimulus only to "hit coverage bins" without verifying Spec-compliant DUT behavior

## Input

| Input | Source | Required |
|-------|--------|----------|
| Coverage text report directory | VCS `urg` / Xcelium `imc` / Questa `vcover` output | Yes |
| `testplan.json` | Stage 1 output (spec-to-testplan) | Optional |
| `regression_results.json` | Stage 6 output (regression) | Optional |
| `spec_analysis.json` | Stage 1 output (spec-to-testplan) | Optional (required for Sub-stage A) |
| `fsm_analysis.json` | Stage 1 output (spec-to-testplan) | Optional (required for FSM coverage) |

### Input Validation

Before starting, verify:
- Coverage report directory exists and contains readable text files (at minimum: `dashboard.txt` or equivalent summary file)
- If `spec_analysis.json` is provided, verify it has:
  - `registers[]` array with each register having `name`, `offset`, `fields[]` (needed for config space covergroups)
  - `interfaces[]` array with each interface having `name`, `signals[]` (needed for protocol coverage)
  - `error_conditions[]` array (needed for error injection covergroups)
- If `fsm_analysis.json` is provided, verify it has:
  - `fsm_list[]` array with each FSM having `states[]` and `transitions[]` (needed for FSM state/transition coverage)
- If `testplan.json` is provided, verify it has `scenarios[]` array (needed for coverage-to-testplan traceability)
- If no coverage report exists, instruct user to run Stage 6 first
- If required upstream JSON fields are missing, report specific missing fields and suggest re-running the upstream stage

### Standalone Mode

User provides coverage report text files directly. The script `scripts/parse_coverage.py` auto-detects the report format (VCS urg, Xcelium imc, or generic text) and extracts metrics. No EDA tool installation required for analysis-only mode.

## Workflow

### Step 0: Standalone Entry Check

If upstream artifacts are absent:
- Coverage report directory missing ->prompt the user for:
  - Path to coverage text report (VCS `urg` output, Xcelium `imc` output, or Questa `vcover` output)
  - Or coverage summary text/numbers for manual analysis
- `spec_analysis.json` missing (needed for Sub-stage A covergroup generation) ->prompt the user for:
  - Register map (names, fields, access types) for config space covergroups
  - Interface protocol names for protocol coverage
  - Error conditions for error injection covergroups
  - Or skip Sub-stage A and go directly to Sub-stage B (gap analysis on existing covergroups)
- `fsm_analysis.json` missing ->skip FSM coverage generation, or prompt the user for FSM states and transitions
- `testplan.json` missing ->proceed without coverage-to-testplan traceability
- `regression_results.json` missing ->proceed without failure correlation analysis

### Commands

```bash
# Parse coverage report
python3 scripts/parse_coverage.py <coverage_report_dir> --targets "line:95,branch:90"
```

### Sub-stage A: Functional Coverage Generation

Triggered when covergroups have not yet been created for the design.

**Derivation from spec_analysis:**

| spec_analysis field | Covergroup type | Derivation method |
|---------------------|----------------|-------------------|
| `registers` | Config space coverage | One coverpoint per config field, cross meaningful combinations |
| `fsm` / `fsm_analysis` | FSM state + transition coverage | State bins from FSM states, transition bins from valid edges |
| `registers` | Register access coverage | Address x read/write cross, ignore_bins for access violations |
| `error_conditions` | Error injection coverage | Error type coverpoints, cross with operating modes |

**Coverpoint and cross design rules:**

- Sampling: transaction-level (`with function sample(...)`) preferred over clock-level (`@(posedge clk)`)
- Clock-level sampling reserved for FSM state coverage where per-cycle tracking is needed
- Cross strategy:
  - Only cross dimensions that have verification meaning
  - Total bins per cross < 1000
  - Use `ignore_bins` for unreachable / illegal combinations
  - Use `illegal_bins` for forbidden states that should never occur
- Functional coverage goal: **100%** (unreachable bins must use `illegal_bins` or `ignore_bins`, never lower the target)

### Sub-stage B: Coverage Result Analysis

1. Parse coverage report using `scripts/parse_coverage.py`
2. Classify each gap by metric type:
   - Line coverage
   - Branch coverage
   - Toggle coverage
   - FSM state coverage
   - FSM transition coverage
   - Condition coverage
   - Functional coverage
3. Diagnose root cause per gap:
   - `missing_scenario` -- no test exercises this path
   - `wrong_config` -- configuration does not enable this feature
   - `dead_code` -- code is structurally unreachable
   - `sampling_issue` -- covergroup sampling not triggering correctly
   - `encoding_mismatch` -- register encoding in test does not match RTL
4. Mark confidence level: `high`, `medium`, `low`

### Sub-stage C: Coverage-Driven Test Generation

1. **Gap-to-stimulus mapping**: for each gap identified in Sub-stage B, map to a stimulus pattern (see `references/gap-to-stimulus-patterns.md`)
2. **Generate targeted test**: create new test class + virtual sequence addressing the gap
3. **Register new test into build system** (mandatory before compile):
   - Add test/vseq `include` lines to `uvm_tb/<project>_pkg.sv` (after existing test includes)
   - Add test class name to `sim/testname.f`
   - If a new covergroup file was created, add its `include` to the package and add file to `sim/flist`
4. **Compile and simulate**:
   - **Pipeline mode**: execute `cd sim && make compile_cov && make run_cov TEST=<new_test>` directly
   - **Standalone mode**: generate commands for user to execute
   - If compile fails: attempt safe auto-fix (missing include, factory macro) up to 2 rounds; if still failing, escalate -do NOT enter run-and-debug's full 3-round debug loop
   - If sim fails: log failure in `coverage_triage.json` rounds[], move to next gap
5. **Check coverage delta**:
   - `delta > 0` -- effective, gap is closing, continue to next gap
   - `delta = 0` -- stimulus not hitting the gap, revise approach (change constraints, adjust timing, verify sampling)
6. Repeat for all identified gaps

### Human Intervention Points

- **Dead code confirmation**: when Sub-stage B identifies `dead_code`, a human must confirm before exclusion
- **Exclusion decisions**: all coverage exclusions require human review and approval

## Output

| Output | Format | Description |
|--------|--------|-------------|
| `docs/coverage_triage.json` | JSON | Gap classification, root causes, confidence levels |
| `uvm_tb/<project>_coverage.sv` | SystemVerilog | Functional coverage collector (covergroups) |
| `uvm_tb/<project>_closure_tests.sv` | SystemVerilog | Targeted tests for coverage gaps (if generated) |
| `docs/coverage_report.md` | Markdown | Human-readable coverage summary |
| Exclusion recommendation list | In `docs/coverage_triage.json` `exclusion_recommendations[]` | Items recommended for exclusion (requires human approval) |

## Self-Correction

- **Coverage delta tracking**: track coverage improvement per round; log metrics after each iteration
- **Plateau detection**: if 2 consecutive rounds produce delta < 1%, escalate to human review for directed test strategy
- **Bin explosion warning**: if any cross coverage produces > 1000 bins, emit warning and recommend adding `ignore_bins`
- **Dead code identification**: flag code under `ifdef` guards that are never defined, error paths requiring external fault injection, and legacy code for removed features
- **Maximum rounds**: 5 rounds of test generation per coverage gap. This limit is non-negotiable.

**Escalation trigger**: Produce `escalation_report.json` when ANY of:
- 5 rounds of test generation for a gap produce zero coverage delta (gap is not closable by automated stimulus)
- Dead code identified (needs human confirmation before exclusion)
- Coverage plateau: 2 consecutive rounds with overall delta < 1% across all metrics
- Exclusion list exceeds 10 items (too many exclusions suggest structural issue)

Format follows the unified escalation schema (defined in spec-to-testplan/references/output-schema.md#escalation_reportjson). Human action: review dead code, approve/reject exclusions, design directed tests for remaining gaps, consider RTL review for unreachable paths.

## Safety

- **Never modifies RTL source code** -only generates/modifies testbench files in `uvm_tb/`
- New tests must compile and pass simulation before being added to regression suite
- Coverage exclusions require human confirmation -- never auto-exclude
- Never automatically lower coverage goals
- Functional coverage target is fixed at **100%**
- **Coverage genuineness verification**: High coverage numbers do not automatically mean verification is complete. Before declaring coverage targets met, human reviewers must:
  1. Verify scoreboard comparisons are actually checking data correctness (not just counting transactions)
  2. Confirm assertions are derived from Spec behavior, not from RTL implementation
  3. Review waveforms of representative tests to confirm DUT behavior matches Spec description
  4. Identify and exclude genuinely unreachable coverage points (with documented justification)
- **Anti-cheating**: AI must never generate stimulus specifically designed to "hit coverage bins" without verifying that the DUT behavior under that stimulus is Spec-compliant. Coverage without correctness checking is meaningless.

## Standards

- IEEE 1800-2017 functional coverage constructs: `covergroup`, `coverpoint`, `cross`, `bins`, `ignore_bins`, `illegal_bins`
- Coverage-Driven Verification (CDV) methodology (Synopsys / Cadence)

## References

- [references/covergroup-patterns.md](references/covergroup-patterns.md) -Read during Sub-stage A for covergroup design patterns, cross coverage control, and sampling timing guide
- [references/triage-patterns.md](references/triage-patterns.md) -Read during Sub-stage B for coverage gap diagnosis, root cause classification, and industry coverage targets
- [references/gap-to-stimulus-patterns.md](references/gap-to-stimulus-patterns.md) -Read during Sub-stage C for mapping coverage gaps to stimulus strategies and test generation patterns
- [references/output-schema.md](references/output-schema.md) -Read when producing output files to verify coverage_triage.json schema and exclusion report format
- [covergroup_skeleton.sv](assets/skeletons/covergroup_skeleton.sv) -covergroup skeleton with placeholder markers
- [covergroup_config_space.sv](assets/examples/covergroup_config_space.sv) -complete config space covergroup example with illegal_bins and cross
- [coverage_triage_template.json](assets/templates/coverage_triage_template.json) -coverage triage JSON template
