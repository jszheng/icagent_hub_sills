# Triage Patterns

Reference for diagnosing coverage gaps and determining root causes.

## Coverage Gap Diagnosis Table

| Gap type | Likely cause | Confidence | Action |
|----------|-------------|------------|--------|
| Uncovered line in active logic | Missing test scenario | High | Generate targeted test exercising that code path |
| Uncovered line in error handling path | Error condition not injected | High | Generate error injection test |
| Uncovered line in dead code | Unreachable code (structurally or functionally) | Medium | Confirm with designer, add exclusion if confirmed |
| Low toggle on config register bits | Not all configurations exercised | High | Add config traversal test covering all valid values |
| Missing FSM transition | State transition not triggered by any test | High | Generate directed sequence forcing the specific state path |
| Low condition coverage | Specific condition combination not hit | Medium | Add targeted stimulus focusing on the uncovered condition combo |
| Low functional coverage (coverpoint bins not sampled) | Varies | Varies | Check if sampling is correct first, then generate stimulus |
| Uncovered branch in conditional logic | Missing scenario for one branch arm | High | Generate test targeting the uncovered branch condition |
| Toggle stuck at 0 on output signal | Signal never driven high by any test | Medium | Verify if signal is connected; if yes, generate activating test |
| FSM state never reached | State requires rare condition sequence | High | Generate directed test with specific preconditions |

## Root Cause Classification

Each gap is assigned one of the following root causes:

| Root cause | Description | Typical action |
|-----------|-------------|----------------|
| `missing_scenario` | No existing test exercises this path | Generate new targeted test |
| `wrong_config` | DUT configuration does not enable the feature under test | Add test with correct config settings |
| `dead_code` | Code is structurally unreachable in current design | Flag for human review, recommend exclusion |
| `sampling_issue` | Covergroup sampling is incorrect or not triggering | Fix covergroup sampling logic before generating tests |
| `encoding_mismatch` | Register encoding in testbench does not match RTL | Fix address/field encoding in testbench |

## Dead Code Identification

Code should be flagged as potential dead code when:

- It is guarded by `` `ifdef `` / `` `ifndef `` where the macro is never defined in the build
- It is an error handling path that requires external fault injection not available in the testbench (e.g., physical-layer faults)
- It is legacy code for features that have been removed from the design but not from the source
- It is a default branch in a case statement where all valid cases are already enumerated
- It is parameterized code where the current parameter values make certain paths unreachable

**Important**: dead code determination requires human confirmation. The tool flags candidates but never auto-excludes.

## Coverage Metric Industry Targets

| Metric | Target | Notes |
|--------|--------|-------|
| Line coverage | > 95% | Remaining 5% typically dead code or rare error paths |
| Branch coverage | > 90% | Some branches may require complex multi-cycle conditions |
| Toggle coverage | > 85% | Upper bits of wide buses may not toggle in all configs |
| FSM state coverage | 100% | Every defined state must be reachable |
| FSM transition coverage | > 90% | Some transitions may be error-recovery only |
| Condition coverage | > 85% | Complex conditions may have hard-to-reach combinations |
| Functional coverage | 100% | All bins must be hit; unreachable bins use `illegal_bins` / `ignore_bins` |

## Confidence Levels

- **High**: clear mapping between gap and missing test scenario; fix is straightforward
- **Medium**: probable cause identified but may require investigation; fix may need iteration
- **Low**: uncertain cause; may be dead code, tool artifact, or complex interaction; needs human review
