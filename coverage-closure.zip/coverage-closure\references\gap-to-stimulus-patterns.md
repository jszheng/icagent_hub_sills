# Gap-to-Stimulus Patterns

Reference for mapping coverage gaps to stimulus generation strategies.

## Mapping Table

| Gap category | Stimulus approach | Example |
|-------------|-------------------|---------|
| Uncovered config combination | Constrained random over config space | Cross `data_width` x `parity_mode` -- enumerate all valid pairs |
| Uncovered FSM transition | Directed sequence forcing specific state path | Drive DUT through state A -> B -> C with precise input timing |
| Uncovered error path | Error injection sequence | Inject parity error, framing error, overflow, underflow |
| Low toggle on data bus | Walking-1, walking-0, all-ones, all-zeros patterns | Send `0x00`, `0xFF`, `0x55`, `0xAA`, `0x01`, `0x02`, ... `0x80` |
| Uncovered branch in idle logic | Exercise idle -> active -> idle transitions | Start operation then cancel or complete quickly |
| Missing interrupt scenario | Trigger interrupt condition | Fill FIFO to threshold, enable interrupt, verify assertion |
| Uncovered register field value | Write all valid encodings to the register | Loop through valid field values for config registers |
| Low condition coverage | Target specific boolean sub-expression | Isolate each term in the condition, ensure both true and false |
| Uncovered reset behavior | Apply reset in various states | Assert reset while DUT is in active, wait, error states |
| Missing back-to-back transactions | Send consecutive operations without idle gap | Issue write immediately followed by read, or vice versa |

## Stimulus Generation Procedure

For each gap identified in Sub-stage B:

1. **Look up gap category** in the table above
2. **Determine stimulus approach** based on the gap's root cause
3. **Generate test class**: extend `base_test`, instantiate appropriate virtual sequence
4. **Generate virtual sequence**: extend `vseq_base`, implement the stimulus pattern
5. **Add constraints** to focus random generation on the uncovered area
6. **Compile and simulate** through Stage 5
7. **Measure coverage delta** -- if delta > 0, the stimulus is effective

## Special Cases

### Root cause: `dead_code`

Do **NOT** generate a test. Flag the code for human exclusion review. Dead code cannot be covered by any stimulus because it is structurally unreachable.

### Root cause: `sampling_issue`

Do **NOT** generate a test. Fix the covergroup sampling logic first:

- Verify the `sample()` function is being called at the right time
- Verify signal connections to the covergroup
- Verify `coverpoint` expressions match the actual signal widths and encodings
- After fixing sampling, re-run existing regression before generating new tests

### Root cause: `encoding_mismatch`

Do **NOT** generate a test. Fix the address or field encoding in the testbench to match RTL:

- Compare register map in `spec_analysis.json` with actual RTL addresses
- Update testbench constants or `tb_define.v` macros
- Re-run existing regression after the fix

## Stimulus Pattern Details

### Config Traversal

```
for each config_field in spec_analysis.registers:
    for each valid_value in config_field.valid_range:
        configure DUT with this value
        run basic operation
        check coverage improvement
```

### FSM Transition Forcing

```
identify uncovered transition: STATE_X => STATE_Y
find precondition sequence to reach STATE_X
apply input that triggers transition to STATE_Y
verify DUT reaches STATE_Y
```

### Error Injection

```
configure DUT for normal operation
start a transaction
inject error at the protocol-defined injection point
verify DUT detects error (status register, interrupt, state change)
verify error recovery (DUT returns to operational state)
```

### Toggle Maximization

```
data_patterns = [0x00, 0xFF, 0x55, 0xAA, 0x01, 0x02, 0x04, ..., 0x80]
for each pattern in data_patterns:
    send transaction with data = pattern
    verify toggle coverage improvement
```

## Effectiveness Criteria

- **delta > 0**: stimulus is effective, proceed to next gap
- **delta = 0**: stimulus is not hitting the gap -- revise approach:
  - Verify the gap location matches the stimulus target
  - Check if additional preconditions are needed
  - Try a more directed (less random) approach
  - If 2 consecutive attempts yield delta = 0, escalate to ML optimization (Sub-stage D)
