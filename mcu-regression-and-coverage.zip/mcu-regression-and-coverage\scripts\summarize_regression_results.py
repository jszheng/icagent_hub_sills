#!/usr/bin/env python3
"""Cluster regression failures by root cause from regression_record.json.

Usage:
    python3 summarize_regression_results.py <regression_record.json>

Reads the regression record, extracts error messages from each failed test log,
and clusters failures by: same error message, same failing module, seed-sensitive,
and environment issues.

Output: JSON to stdout with cluster list and per-test assignment.
"""

import json
import os
import re
import sys
from collections import defaultdict


# ---------------------------------------------------------------------------
# Error message extraction patterns
# ---------------------------------------------------------------------------
FAIL_PATTERNS = [
    re.compile(r"TEST_FAILED:\s*(.+)", re.IGNORECASE),
    re.compile(r"UVM_FATAL\s+.*?:\s*(.+)", re.IGNORECASE),
    re.compile(r"Error-\[([A-Z_]+)\]\s*(.+)"),
    re.compile(r"\*E,\w+\s*\(([^)]+)\):\s*(.+)"),
    re.compile(r"Assertion\s+failed:\s*(.+)", re.IGNORECASE),
    re.compile(r"TIMEOUT", re.IGNORECASE),
]

MODULE_PATTERN = re.compile(
    r"(?:in module|Instance|hierarchy)\s+['\"]?(\w+)", re.IGNORECASE
)


def extract_failure_info(log_path):
    """Extract error messages and module names from a simulation log."""
    errors = []
    modules = set()
    if not os.path.isfile(log_path):
        return {"errors": ["<log file not found>"], "modules": []}

    try:
        with open(log_path, "r", errors="replace") as f:
            for line in f:
                for pat in FAIL_PATTERNS:
                    m = pat.search(line)
                    if m:
                        errors.append(m.group(0).strip())
                        break
                m_mod = MODULE_PATTERN.search(line)
                if m_mod:
                    modules.add(m_mod.group(1))
    except OSError:
        return {"errors": ["<log file unreadable>"], "modules": []}

    if not errors:
        errors = ["<no recognizable error pattern>"]
    return {"errors": errors[:20], "modules": sorted(modules)}


def normalize_error(msg):
    """Normalize an error message for clustering (strip addresses, timestamps)."""
    msg = re.sub(r"@\s*\d+(\.\d+)?\s*(ns|ps|us|ms)?", "", msg)
    msg = re.sub(r"0x[0-9a-fA-F]+", "0xXXXX", msg)
    msg = re.sub(r"\b\d{4,}\b", "NNNN", msg)
    msg = re.sub(r"\s+", " ", msg).strip()
    return msg


def cluster_failures(failed_tests, base_dir):
    """Cluster failed tests by root cause."""
    # Per-test analysis
    test_info = {}
    for t in failed_tests:
        name = t["name"]
        seed = t.get("seed", "?")
        log = t.get("log", "")
        if log and not os.path.isabs(log):
            log = os.path.join(base_dir, log)
        key = f"{name}_seed{seed}"
        test_info[key] = {
            "name": name,
            "seed": seed,
            "log": t.get("log", ""),
            "info": extract_failure_info(log),
        }

    # --- Cluster by normalized error message ---
    error_clusters = defaultdict(list)
    for key, ti in test_info.items():
        top_error = normalize_error(ti["info"]["errors"][0])
        error_clusters[top_error].append(key)

    # --- Detect seed-sensitive tests (same test, different seeds, mixed results) ---
    # We only have failed tests here; need pass info from full record
    test_names_failed = defaultdict(list)
    for key, ti in test_info.items():
        test_names_failed[ti["name"]].append(ti["seed"])

    # --- Detect environment issues (all fail early with same message) ---
    env_cluster = []
    for err_msg, keys in error_clusters.items():
        if "TIMEOUT" in err_msg.upper() or "log file not found" in err_msg:
            continue
        if len(keys) == len(failed_tests) and len(failed_tests) > 1:
            env_cluster = keys
            break

    # --- Build cluster list ---
    clusters = []
    assigned = set()

    if env_cluster:
        clusters.append({
            "type": "environment",
            "description": "All tests fail with the same error — likely environment or compile issue",
            "tests": env_cluster,
            "error": normalize_error(test_info[env_cluster[0]]["info"]["errors"][0]),
        })
        assigned.update(env_cluster)

    for err_msg, keys in sorted(error_clusters.items(), key=lambda x: -len(x[1])):
        remaining = [k for k in keys if k not in assigned]
        if not remaining:
            continue
        # Check if failures share a module
        shared_modules = None
        for k in remaining:
            mods = set(test_info[k]["info"]["modules"])
            if shared_modules is None:
                shared_modules = mods
            else:
                shared_modules &= mods
        if not shared_modules:
            shared_modules = set()

        cluster = {
            "type": "same_error" if len(remaining) > 1 else "unique",
            "description": err_msg,
            "tests": remaining,
            "count": len(remaining),
        }
        if shared_modules:
            cluster["type"] = "same_module"
            cluster["common_modules"] = sorted(shared_modules)
        clusters.append(cluster)
        assigned.update(remaining)

    return clusters, test_info


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: summarize_regression_results.py <regression_record.json>",
              file=sys.stderr)
        return 1

    record_path = sys.argv[1]
    try:
        with open(record_path, "r") as f:
            record = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        print(f"Error reading {record_path}: {e}", file=sys.stderr)
        return 1

    base_dir = os.path.dirname(os.path.abspath(record_path))
    # Walk up to project root (regression_record.json is in doc/)
    if os.path.basename(base_dir) == "doc":
        base_dir = os.path.dirname(base_dir)

    tests = record.get("tests", [])
    if not tests:
        print(json.dumps({"error": "no tests found in record"}, indent=2))
        return 1

    failed = [t for t in tests if t.get("status") == "fail"]
    passed = [t for t in tests if t.get("status") == "pass"]
    total = record.get("summary", {}).get("total", len(tests))

    # Seed-sensitive detection: same test name appears in both pass and fail
    pass_names = {t["name"] for t in passed}
    fail_names = {t["name"] for t in failed}
    seed_sensitive = sorted(pass_names & fail_names)

    if not failed:
        result = {
            "status": "all_pass",
            "total": total,
            "pass": len(passed),
            "fail": 0,
            "clusters": [],
            "seed_sensitive": [],
        }
    else:
        clusters, test_info = cluster_failures(failed, base_dir)
        result = {
            "status": "has_failures",
            "total": total,
            "pass": len(passed),
            "fail": len(failed),
            "pass_rate": f"{len(passed)/total*100:.1f}%" if total else "N/A",
            "clusters": clusters,
            "seed_sensitive": seed_sensitive,
            "recommended_action": _recommend(clusters, seed_sensitive),
        }

    json.dump(result, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


def _recommend(clusters, seed_sensitive):
    """Generate a one-line recommendation based on cluster analysis."""
    if not clusters:
        return "no failures to triage"
    if len(clusters) == 1 and clusters[0]["type"] == "environment":
        return "fix environment/compile issue before rerunning any tests"
    if seed_sensitive:
        return (f"seed-sensitive tests detected ({', '.join(seed_sensitive[:3])}); "
                "rerun with more seeds to confirm, then debug top failure cluster")
    if len(clusters) == 1:
        return f"single root cause — fix and rerun affected tests only"
    return (f"{len(clusters)} failure clusters — "
            f"prioritize largest cluster ({clusters[0]['count']} tests) first")


if __name__ == "__main__":
    raise SystemExit(main())
