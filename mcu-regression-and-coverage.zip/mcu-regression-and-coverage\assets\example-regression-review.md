## Regression goal

Check whether the MCU subsystem is stable enough for synthesis handoff after recent wrapper and interrupt changes.

## Run tiers used

- Tier 1 smoke and reset
- Tier 2 GPIO/UART/timer interrupt paths

## Failure clusters

- one timeout cluster tied to UART interrupt clear
- one checker mismatch cluster tied to timer configuration shadowing

## Rerun versus pause decision

Pause broad reruns. The clusters are already clear enough to route to focused debug.

## Recommended next step

Return UART interrupt-clear cases to `mcu-verification-triage`, then rerun Tier 1 and affected Tier 2 cases only.
