---
name: mcu-regression-and-coverage
description: Analyze regression results, cluster failures, merge coverage databases, diagnose coverage gaps, and decide rerun scope or closure actions for an MCU SoC design. Use when regression has run and results need interpretation — failure clustering, coverage gap analysis, exclusion review, or continue/stop decisions.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Regression And Coverage

Use this skill after regression has been run and results need interpretation. This skill handles both failure analysis and coverage closure in a single iteration loop.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** run simulation. (Companion skill: `mcu-compile-sim-run`)
- Do **not** plan or generate new tests. Test additions feed back to the user. (Companion skill: `mcu-tb-development`)
- Do **not** modify RTL or TB code.

## Good Outcome

Produce:

- failure clustering with root-cause grouping
- merged coverage database and per-metric summary
- coverage gap classification with ranked closure actions
- rerun scope decision (which tests, which seeds, what to add)
- continue versus stop guidance

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `doc/regression_record.json` | From compile/sim regression run | Yes |
| Coverage databases | From sim/coverage/ directory | Yes (for coverage analysis) |
| `eda_env.json` | From EDA env setup if available | Yes (for coverage merge tool) |
| `doc/test_list.json` | From TB development stage if available | For context |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Merged coverage DB | `sim/coverage/merged.vdb` or equivalent | Combined coverage |
| Coverage report | `sim/coverage/report/` | Text coverage summary |
| Regression summary | `doc/regression_summary.json` | Failure clusters + coverage metrics |
| Gap analysis | `doc/coverage_gaps.json` | Classified gaps with actions |

## Input Validation

### From regression_record.json

| Required field | What to check | Used for |
|---|---|---|
| `tests[]` | Array with entries, each has name/status/log | Failure clustering |
| `summary.total` | > 0 | Sanity check |
| `summary.pass` / `summary.fail` | Numbers | Pass rate calculation |
| `coverage_dir` | Path exists, contains coverage data | Coverage merge input |

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.simulator` | vcs or xcelium | Coverage merge tool (urg vs imc) |

## Workflow

### Part 1 — Failure Analysis

#### Step 1: Read regression results

Parse `doc/regression_record.json`. For each failed test, read its log file to extract failure message.

#### Step 2: Cluster failures

Group failures by root cause, not by test name:

| Cluster type | Pattern | Example |
|---|---|---|
| Same error message | Multiple tests fail with identical assertion text | GPIO and Timer both fail on "bus timeout" |
| Same failing module | Failures trace to the same RTL module | All UART tests fail |
| Same seed-sensitive | Test passes with seed 1, fails with seed 42 | Race condition or uninitialized value |
| Environment issue | All tests fail at compile or early sim | Missing file, tool error |

Use `scripts/summarize_regression_results.py` for automated clustering. The script reads `regression_record.json`, extracts error messages from each failed test log, normalizes and clusters by root cause (same error, same module, seed-sensitive, environment), and outputs JSON with cluster list and recommendations.

#### Step 3: Decide rerun scope

| Situation | Decision |
|---|---|
| All failures in one cluster → single root cause | Fix once, rerun only affected tests |
| Failures across many clusters → multiple issues | Prioritize by impact, fix top cluster first |
| Seed-sensitive failures | Rerun with more seeds to confirm |
| All pass | Proceed to coverage analysis |

### Part 2 — Coverage Analysis

#### Step 4: Merge coverage databases

**VCS:**
```
urg -dir sim/coverage/*.vdb -dbname sim/coverage/merged.vdb -report sim/coverage/report
```

**Xcelium:**
```
imc -load sim/coverage/* -merge -out sim/coverage/merged
imc -load sim/coverage/merged -report -metrics all -out sim/coverage/report
```

#### Step 5: Parse coverage report

Extract per-metric totals:

| Metric | Typical target |
|--------|---------------|
| Line coverage | > 95% |
| Branch coverage | > 90% |
| Condition coverage | > 85% |
| Toggle coverage | > 80% |
| FSM coverage | > 90% |

#### Step 6: Classify gaps

For each uncovered item:

| Classification | Action |
|---|---|
| Unreachable code (dead logic, unused config) | Exclude with justification |
| Missing stimulus (untested path) | Add test to `mcu-tb-development` backlog |
| Missing checker/constraint (blocked stimulus) | Fix environment |
| Black-box boundary (inside uncontrolled IP) | Exclude |
| Plateau (no progress after iterations) | Investigate root cause, may need architectural change |

Use `scripts/summarize_coverage_gaps.py` for automated gap analysis. The script parses URG/IMC coverage reports, checks metrics against targets, classifies uncovered items (missing_stimulus/unreachable/black_box), and outputs JSON with gap summary and recommendations. Supports `--black-box mod1,mod2` to mark IP modules for exclusion.

#### Step 7: Write gap analysis

Write `doc/coverage_gaps.json` with per-gap: metric, file, item, classification, action.

### Part 3 — Decision

#### Step 8: Continue or stop

| Condition | Decision |
|---|---|
| All tests pass + all metrics at target | Coverage closure complete → proceed to synthesis |
| Tests pass + gaps remain with clear actions | Continue: add tests, re-run regression |
| Tests fail + coverage gaps | Fix failures first, coverage comes later |
| Plateau after 2+ iterations | Stop: review with user |
| Only exclusion candidates remain | Review exclusions with user, then close |

## Bundled Assets

- [regression-summary-template.md](assets/regression-summary-template.md) — regression review output format
- [example-regression-review.md](assets/example-regression-review.md) — sample regression review output
- [sample-regression-summary.json](assets/sample-regression-summary.json) — structured regression summary
- [coverage-closure-template.md](assets/coverage-closure-template.md) — coverage closure output format
- [example-coverage-closure.md](assets/example-coverage-closure.md) — sample coverage closure output
- [sample-coverage-gaps.json](assets/sample-coverage-gaps.json) — structured gap analysis

## Completion Gate

- Failures clustered with root-cause grouping
- Coverage databases merged, per-metric percentages extracted
- Gaps classified with actions
- Exclusions documented with rationale (not silently skipped)
- Continue/stop/rerun decision explicit

## Decision Rules

- Do not rerun failed tests without new evidence or a fix.
- Do not add stimulus blindly when the gap is a checker or sampling issue.
- Exclusions require user approval — never auto-approve.
- Prioritize failure fixes over coverage closure (no point closing coverage on broken tests).
- Coverage merge uses the tool from eda_env.json (urg for VCS, imc for Xcelium).
