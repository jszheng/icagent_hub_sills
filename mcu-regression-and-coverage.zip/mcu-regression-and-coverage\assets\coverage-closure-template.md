# Coverage Closure: [Design Name]

## Coverage status

| Metric | Current % | Target % | Status |
|--------|----------|----------|--------|
| Line | from report | > 95% | MET/GAP |
| Branch | from report | > 90% | MET/GAP |
| Condition | from report | > 85% | MET/GAP |
| Toggle | from report | > 80% | MET/GAP |
| FSM | from report | > 90% | MET/GAP |

## Important gaps

For each uncovered item above the threshold gap:

| Module | Metric | Uncovered item | Classification | Action |
|--------|--------|---------------|----------------|--------|
| gpio_ctrl | branch | line 42 else branch | missing stimulus | add GPIO error-inject test |
| ... | ... | ... | ... | ... |

Gap classifications: **missing stimulus**, **missing checker/observation**, **unreachable/dead code**, **black-box boundary**, **plateau** (no progress after iterations).

## Likely causes

For each gap category, explain why coverage is not advancing:
- Missing stimulus: which scenarios are not exercised?
- Unreachable code: is the logic truly dead, or just unconfigured?
- Plateau: has the checker model drifted from the current RTL?

## Ranked closure actions

1. Highest-impact action (closes the most gaps)
2. Next action
3. Items that can be deferred or excluded with justification

## Continue or stop

- **Continue**: gaps remain with clear closure actions
- **Stop and exclude**: only unreachable/dead code remains, document exclusions for user review
- **Stop and investigate**: plateau after 2+ iterations, root cause unclear
