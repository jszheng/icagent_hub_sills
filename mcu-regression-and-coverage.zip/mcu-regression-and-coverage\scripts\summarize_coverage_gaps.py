#!/usr/bin/env python3
"""Parse VCS/Xcelium coverage reports and classify uncovered items.

Usage:
    python3 summarize_coverage_gaps.py <coverage_report_dir> [--black-box mod1,mod2]

Scans text coverage reports (URG or IMC format) for uncovered lines, branches,
conditions, toggles, and FSM states. Classifies each gap and outputs JSON.

Output: JSON to stdout with per-metric summary and classified gap list.
"""

import json
import os
import re
import sys
from collections import defaultdict


# ---------------------------------------------------------------------------
# Coverage report parsing patterns
# ---------------------------------------------------------------------------

# URG (VCS) summary patterns
URG_METRIC = re.compile(
    r"^\s*(Line|Branch|Cond|Toggle|FSM)\s+(\d+(?:\.\d+)?)\s*%", re.IGNORECASE
)
# URG detail: uncovered item
URG_UNCOVERED = re.compile(
    r"^\s*(?:UNCOVERED|Excluded|NOT_COVERED)\s+(.+)", re.IGNORECASE
)
# Module/file header in URG report
URG_MODULE = re.compile(r"^(?:Module|Instance)\s*:\s*(\S+)", re.IGNORECASE)
URG_FILE = re.compile(r"^(?:File|Source)\s*:\s*(\S+)", re.IGNORECASE)

# IMC (Xcelium) summary patterns
IMC_METRIC = re.compile(
    r"(block|line|branch|condition|toggle|expression|fsm)\s+coverage\s*:\s*(\d+(?:\.\d+)?)\s*%",
    re.IGNORECASE,
)

# Common uncovered line pattern
UNCOV_LINE = re.compile(
    r"(\S+\.(?:v|sv))\s*:\s*(\d+)\s+.*(?:UNCOVERED|0/\d+|not hit)", re.IGNORECASE
)


def parse_coverage_dir(report_dir):
    """Parse all text files in a coverage report directory."""
    metrics = {}
    gaps = []
    current_module = None
    current_file = None

    if not os.path.isdir(report_dir):
        return metrics, gaps

    for root, _dirs, files in os.walk(report_dir):
        for fname in sorted(files):
            if not fname.endswith((".txt", ".rpt", ".log", ".report")):
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", errors="replace") as f:
                    for line in f:
                        # Metric summaries
                        m = URG_METRIC.search(line)
                        if m:
                            metric = _normalize_metric(m.group(1))
                            pct = float(m.group(2))
                            metrics[metric] = pct
                            continue

                        m = IMC_METRIC.search(line)
                        if m:
                            metric = _normalize_metric(m.group(1))
                            pct = float(m.group(2))
                            metrics[metric] = pct
                            continue

                        # Module/file context
                        m = URG_MODULE.search(line)
                        if m:
                            current_module = m.group(1)
                            continue
                        m = URG_FILE.search(line)
                        if m:
                            current_file = m.group(1)
                            continue

                        # Uncovered items
                        m = UNCOV_LINE.search(line)
                        if m:
                            gaps.append({
                                "file": m.group(1),
                                "line": int(m.group(2)),
                                "module": current_module,
                                "raw": line.strip()[:200],
                            })
            except OSError:
                continue

    return metrics, gaps


def _normalize_metric(name):
    """Normalize metric name to standard form."""
    name = name.lower().strip()
    mapping = {
        "line": "line", "block": "line",
        "branch": "branch",
        "cond": "condition", "condition": "condition", "expression": "condition",
        "toggle": "toggle",
        "fsm": "fsm",
    }
    return mapping.get(name, name)


def classify_gaps(gaps, black_box_modules=None):
    """Classify each gap into actionable categories."""
    if black_box_modules is None:
        black_box_modules = set()

    classified = defaultdict(list)
    for gap in gaps:
        module = gap.get("module", "")

        # Black-box boundary
        if module and module in black_box_modules:
            gap["classification"] = "black_box"
            gap["action"] = "exclude — inside uncontrolled IP"
            classified["black_box"].append(gap)
            continue

        # Unreachable code heuristics
        raw = gap.get("raw", "").lower()
        if any(kw in raw for kw in ["default:", "else", "unused", "reserved",
                                      "synthesis", "pragma"]):
            gap["classification"] = "unreachable"
            gap["action"] = "exclude with justification — likely dead/defensive code"
            classified["unreachable"].append(gap)
            continue

        # Default: missing stimulus
        gap["classification"] = "missing_stimulus"
        gap["action"] = "add test to cover this path"
        classified["missing_stimulus"].append(gap)

    return classified


def check_targets(metrics):
    """Check metrics against typical targets."""
    targets = {
        "line": 95.0,
        "branch": 90.0,
        "condition": 85.0,
        "toggle": 80.0,
        "fsm": 90.0,
    }
    results = {}
    for metric, target in targets.items():
        actual = metrics.get(metric)
        if actual is not None:
            results[metric] = {
                "actual": actual,
                "target": target,
                "met": actual >= target,
                "gap": round(target - actual, 2) if actual < target else 0,
            }
    return results


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: summarize_coverage_gaps.py <coverage_report_dir> "
              "[--black-box mod1,mod2]", file=sys.stderr)
        return 1

    report_dir = sys.argv[1]
    black_box_modules = set()
    for i, arg in enumerate(sys.argv):
        if arg == "--black-box" and i + 1 < len(sys.argv):
            black_box_modules = set(sys.argv[i + 1].split(","))

    metrics, gaps = parse_coverage_dir(report_dir)

    if not metrics and not gaps:
        result = {
            "status": "no_data",
            "error": f"No coverage reports found in {report_dir}",
            "metrics": {},
            "gaps": [],
        }
        json.dump(result, sys.stdout, indent=2)
        sys.stdout.write("\n")
        return 1

    target_check = check_targets(metrics)
    all_met = all(v["met"] for v in target_check.values()) if target_check else False

    classified = classify_gaps(gaps, black_box_modules)

    summary = {}
    for cls, items in classified.items():
        summary[cls] = {
            "count": len(items),
            "action": items[0]["action"] if items else "",
        }

    result = {
        "status": "coverage_complete" if all_met else "gaps_remain",
        "metrics": metrics,
        "target_check": target_check,
        "all_targets_met": all_met,
        "gap_summary": summary,
        "total_uncovered_items": len(gaps),
        "gaps_by_classification": {
            cls: [{"file": g["file"], "line": g["line"],
                   "module": g.get("module"), "classification": g["classification"]}
                  for g in items[:50]]  # limit output size
            for cls, items in classified.items()
        },
        "recommended_action": _recommend(all_met, summary, classified),
    }

    json.dump(result, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


def _recommend(all_met, summary, classified):
    """Generate recommendation based on gap analysis."""
    if all_met:
        return "all coverage targets met — proceed to synthesis"

    parts = []
    missing = summary.get("missing_stimulus", {}).get("count", 0)
    unreachable = summary.get("unreachable", {}).get("count", 0)
    black_box = summary.get("black_box", {}).get("count", 0)

    if missing > 0:
        parts.append(f"add tests for {missing} uncovered paths")
    if unreachable > 0:
        parts.append(f"review {unreachable} items for exclusion")
    if black_box > 0:
        parts.append(f"exclude {black_box} black-box items with justification")
    if not parts:
        parts.append("investigate remaining coverage gaps")

    return "; ".join(parts)


if __name__ == "__main__":
    raise SystemExit(main())
