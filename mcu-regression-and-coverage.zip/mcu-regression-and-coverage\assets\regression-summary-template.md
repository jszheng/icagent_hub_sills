# Regression Summary: [Design Name]

## Regression goal

State the purpose of this regression run: smoke validation, nightly coverage, full weekly, or targeted rerun after a fix. Include test count and seed strategy.

## Run tiers used

| Tier | Tests included | Seeds | Purpose |
|------|---------------|-------|---------|
| Tier 1 (smoke) | reset, basic access | 1 | Fast sanity |
| Tier 2 (nightly) | peripheral function, interrupt | 1-3 | Core behavior |
| Tier 3 (weekly) | stress, cross-peripheral | multiple | Coverage closure |

## Failure clusters

Group failures by root cause, not by test name:

| Cluster | Tests affected | Pattern | Likely root cause |
|---------|---------------|---------|-------------------|
| Bus timeout | test_uart_tx, test_timer_irq | Same "bus timeout" assertion | Interconnect HREADY mux |
| ... | ... | ... | ... |

Single-cause clusters should be fixed once. Multi-cause clusters need individual investigation.

## Rerun versus pause decision

- **Rerun justified**: if the environment was unstable, input set changed, or a fix was applied
- **Pause and investigate**: if failures cluster to a known blocker — rerunning won't help
- **Escalate**: if the cluster spans multiple subsystems with no obvious shared cause

## Recommended next step

One concrete action: fix the top failure cluster, add a missing test, or proceed to coverage analysis.
