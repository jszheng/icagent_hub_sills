---
name: chip-design-pd
description: Use when planning or reviewing physical design from floorplan through signoff, including placement, CTS, routing, timing optimization, power optimization, area optimization, and final signoff delivery. Trigger even if the user only mentions congestion, CTS, routing DRC, timing closure, IR/EM, LVS, or GDS signoff.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-pd: Physical Design Flow

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. **OpenROAD** (via ORFS or OpenLane) is the recommended default PD tool — full RTL-to-GDS flow, no license required
2. **KLayout** is the recommended default for DRC/LVS signoff — open-source, scriptable Python/Ruby DRC decks
3. **Open PDKs** (sky130, GF180, ASAP7) are fully supported with the open-source flow
4. **Limitations**: OpenROAD CTS skew targets may be less tight than commercial tools; sky130 antenna repair rates are higher — these are documented honestly
5. Commercial tools (Innovus, ICC2, Calibre) are supported but listed as optional — only use when the user explicitly selects them
6. Detection order: `openroad` and `klayout` are checked before commercial tool commands

---

## Use Mode

This skill supports two modes:

**Full PD flow:**
- Follow the 8-stage orchestrated flow from floorplan through tape-out signoff
- Track QoR continuously across stages; loop back on failures
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules when answering targeted questions
- Reference stage QoR thresholds, ECO rules, or signoff criteria without running the full flow

**Critical constraints:**
- Core utilisation > 85% at signoff: hard stop (routing congestion and ECO become intractable)
- ECO cell count > 2% of total cells: escalate to floorplan revision — incremental ECO will not close timing if root cause is placement congestion
- Do not run GDS signoff with any open DRC, LVS, or timing violations

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| pd | `openroad`, `innovus`, `icc2_shell`, `fc_shell` | Required (at least one; OpenROAD recommended) |
| drc_lvs | `klayout`, `calibre`, `icv`, `pegasus` | Required for signoff (KLayout recommended) |

### Tool Execution

Open-source (recommended):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| OpenROAD (ORFS) | `make DESIGN_CONFIG=./designs/<platform>/<design>/config.mk` | Resume: `make do-<stage>`; full RTL-to-GDS | Open-source (recommended) |
| OpenROAD (OpenLane) | `openlane <config.json>` | Resume: `openlane --from <step>` | Open-source |
| KLayout DRC | `klayout -b -r <drc_script.py>` | Python/Ruby scriptable DRC | Open-source (recommended for DRC/LVS) |
| KLayout LVS | `klayout -b -r <lvs_script.py>` | Netlist extraction + comparison | Open-source |

Commercial (optional):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| Innovus | `innovus -batch -f <script.tcl>` | Interactive: `innovus` then source tcl | Commercial — Cadence |
| IC Compiler 2 | `icc2_shell -f <script.tcl>` | Hierarchical PD with Fusion technology | Commercial — Synopsys |
| Fusion Compiler | `fc_shell -f <script.tcl>` | Combined synthesis + PD | Commercial — Synopsys |
| Calibre | `calibre -drc <rule_file> -batch` | DRC/LVS signoff | Commercial — Siemens |
| ICV | `icv -f <rule_file>` | DRC/LVS signoff | Commercial — Synopsys |

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `pd` and `drc_lvs` capabilities are configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which openroad`, `which klayout` first (open-source), then `which innovus`, `which icc2_shell`, `which fc_shell`, `which calibre`, `which icv` (commercial)
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. Required capability with no tool detected → inform user and stop; suggest installing OpenROAD (`apt install openroad` or build from source) and KLayout (`apt install klayout`) as open-source options

---

## Stage Workflow

### Stage 1: pdk_analysis

Analyze the PDK to identify LEF, tech files, and library views before physical design.

**Domain Rules:**
1. Identify tech LEF: layer definitions, via definitions, design rules — required for all PD tools
2. Identify standard cell LEF: cell abstracts with pin shapes and obstruction layers
3. Identify technology file: `.tf` for Innovus/ICC2 (commercial only); OpenROAD uses LEF/liberty directly
4. Check for memory/macro LEF if design uses SRAM or hard IPs
5. Confirm layer stack matches the PDK variant being used (e.g., 10LM vs 8LM)
6. Identify DRC/LVS rule decks: KLayout Python/Ruby DRC scripts (open-source — recommended; available for sky130, GF180); Calibre or ICV rule files (commercial — optional)
7. Record findings before proceeding to floorplan

**Output Required:**
- PDK summary: tech LEF, cell LEF, .tf path, layer stack, DRC/LVS rule deck paths
- Confirmed PDK readiness for PD

---

### Stage 2: floorplan

Establish core area, macro placement, IO ring, and power grid.

**Domain Rules:**
1. Core utilisation target: 70–80% — leave margin for routing congestion (ORFS: keep 60–65% for sky130)
2. Macros: place at die edges or corners with halos (typically 5–10 μm)
3. IO pads: distribute evenly; match package pin assignment
4. Power grid: VDD/VSS straps every N rows (technology-node specific)
5. Blockages: hard blockages around analog/RF macros
6. Aspect ratio: keep close to 1:1 unless package constrains otherwise
7. Voltage island boundaries must align to row boundaries
8. Insert n-well tie-off and substrate tie-off cells at required pitch (sky130 LVS failure prevention)

**QoR Metrics:**
- Estimated congestion (H and V): flag if > 80%
- Estimated WNS from floorplan-stage STA: flag if < −2 ns
- IR drop estimate: flag if > 10% of VDD

**Output Required:**
- Floorplan DEF (`floorplan.def`)
- Power grid DEF or script
- Macro placement report
- Estimated congestion map

---

### Stage 3: placement

Place standard cells to minimize timing and routing congestion.

**Domain Rules:**
1. Sequence: global → legalise → detailed → pre-CTS optimisation
2. Pre-CTS timing: ideal clocks; uncertainty = skew + jitter estimate
3. Max utilisation per partition: 80%
4. High-fanout nets: buffer before placement or apply constraints
5. Timing-critical paths: co-locate related cells with placement constraints
6. Scan chains: re-order after placement for minimum wirelength

See [references/pd-rules.md](references/pd-rules.md) for common placement issues and fixes.

**QoR Metrics:**
- Pre-CTS WNS: > −0.3 ns
- Cell density hotspots: flag if any region > 90%
- Estimated routing congestion overflow: flag if > 1%

**Output Required:**
- Placed DEF
- Pre-CTS timing report (setup and hold)
- Cell density and congestion report

---

### Stage 4: cts

Build clock trees across all clock domains.

**Domain Rules:**
1. Target skew: < 100 ps (or per SDC `set_clock_uncertainty`); sky130 at 500 MHz: use 50 ps target (tighter targets < 30 ps are unreachable with OpenROAD CTS)
2. Max transition on clock nets: per technology DRC rule (150–200 ps)
3. Max fanout per clock buffer: per library (16–32)
4. Useful skew: only with explicit sign-off approval
5. Clock gating: integrate into CTS; verify enable pin timing
6. Multi-clock: handle each domain independently; check CDC after CTS

**QoR Metrics:**
- Global skew per domain: flag if > 150 ps
- Max insertion delay: flag if > 500 ps
- Post-CTS WNS (setup): flag if < −0.2 ns
- Post-CTS hold slack: must be ≥ 0 before routing

**Output Required:**
- Post-CTS DEF
- Clock tree report (skew, insertion delay per domain)
- Post-CTS timing report (setup and hold)

---

### Stage 5: routing

Route all signal and power nets following foundry DRC rules.

**Domain Rules:**
1. Sequence: global → track assignment → detailed → search-and-repair
2. Follow foundry DRC deck (spacing, width, via enclosure)
3. Shield critical clock and analog nets
4. Upper metals for power, lower metals for signals
5. Antenna rules: insert diodes or use jump-via strategy; sky130: run `repair_antennas` — expect 5–15% of nets to need repair
6. Double/multi-patterning (7 nm and below): resolve same-colour violations
7. Always check `drc_count` from detailed routing metrics — not global routing overflow count (global DRC clean ≠ detailed DRC clean)

**QoR Metrics:**
- DRC violations: 0 at sign-off
- LVS errors: 0 at sign-off
- Post-route WNS: flag if < 0
- Routing overflow: 0

**Output Required:**
- Routed DEF
- DRC report
- LVS report
- Post-route timing report

---

### Stage 6: timing_optimization

Close all timing violations using ECO and cell swapping.

**Domain Rules:**
1. Multi-corner: SS (setup), FF (hold), TT (typical)
2. Setup: upsize drivers, insert repeaters, retime registers
3. Hold: insert HVT delay buffers
4. Vt swapping: SVT/LVT for speed-critical; HVT for power-insensitive paths
5. ECO: formal ECO → place in reserved sites → re-route ECO nets
6. Do not modify scan chain order without DFT approval
7. Apply OCV derating (OpenROAD: `set_timing_derate`; commercial: POCV/AOCV per foundry sign-off agreement)
8. If WNS has not converged after 3 ECO rounds: escalate to floorplan revision (incremental ECO will not fix placement-congestion root cause)

**QoR Metrics:**
- WNS: ≥ 0 all corners
- TNS: = 0 all corners
- Hold slack: ≥ 0 after fixing
- ECO cell count: flag if > 2% of total cells

**Output Required:**
- Timing closure report (all corners)
- ECO change list
- SPEF
- Updated routed DEF (post-ECO)

---

### Stage 7: power_optimization

Optimize dynamic and static power within IR drop and EM budgets.

**Domain Rules:**
1. Dynamic: clock gating insertion, operand isolation, multi-Vt swapping
2. Leakage: swap non-critical cells to HVT; verify timing after each batch
3. Power domains: validate UPF (isolation, level-shifters, retention regs)
4. Voltage islands: verify IR drop per domain
5. Always-on logic: verify correct library cells
6. Power gating: verify wakeup/shutdown sequences before routing changes

**QoR Metrics:**
- Total power: within spec budget
- Leakage: flag if > 15% of total at TT corner
- IR drop: < 5% VDD across all domains
- Post-power-opt WNS: must remain ≥ 0

**Output Required:**
- Power analysis report (dynamic + static, per domain)
- IR drop report
- Updated DEF (post-power-opt)
- UPF compliance report

---

### Stage 8: area_optimization

Remove redundant logic and minimize core footprint while preserving timing.

**Domain Rules:**
1. Remove redundant buffers and inverter pairs
2. Downsize non-timing-critical cells to minimum drive strength
3. Reclaim unused standard cell sites
4. Do not drop WNS margin below 50 ps buffer
5. Re-run DRC after any area ECO

**QoR Metrics:**
- Core utilisation: target 70–80%; hard limit 85%
- WNS: must remain ≥ 0
- DRC: must remain clean

**Output Required:**
- Area utilisation report (pre vs post)
- Updated DEF
- Cell count breakdown

---

### Stage 9: signoff

Final tape-out checks: timing, DRC, LVS, antenna, IR/EM.

**Sign-off Pass Criteria (all must pass):**

| Check | Criterion |
|-------|-----------|
| Setup WNS | ≥ 0 all corners |
| Setup TNS | = 0 all corners |
| Hold WNS | ≥ 0 all corners |
| DRC violations | = 0 |
| LVS errors | = 0 |
| Antenna violations | = 0 |
| IR drop | < 5% VDD |
| Metal density | Within foundry window |

See [references/pd-rules.md](references/pd-rules.md) for detailed signoff domain rules (STA, DRC, LVS, ERC, GDS).

**Failure Escalation:**
- Timing fail → `timing_optimization`
- DRC/LVS fail → `routing`
- Power/EM fail → `power_optimization`

**Output Required:**
- Sign-off STA report (all corners)
- DRC clean report
- LVS clean report
- Final GDS-II
- Completed tape-out checklist

---

## Sign-off Hard Gates

PD signoff requires ALL of these conditions:

- `setup_wns_ns >= 0` (all corners, setup clean)
- `drc_violations == 0` (foundry DRC deck clean)
- `lvs_errors == 0` (netlist vs layout match)
- `antenna_violations == 0` (antenna rules clean)
- `ir_drop_pct < 5` (per-domain IR drop within budget)
- `core_area_util_pct <= 85` (routing and ECO tractable)

---

## Loop-Back Rules

- `placement` congestion > 1% → return to `floorplan` (max 2×)
- `placement` FAIL (WNS < −0.5 ns) → return to `floorplan` (max 2×)
- `cts` skew > 150 ps → retry `cts` (max 3×)
- `routing` DRC > 0 → retry `routing` (max 3×)
- `routing` FAIL (post-route WNS < 0) → `timing_optimization` (max 3×)
- `timing_optimization` WNS not closed after 3 ECO rounds → escalate to `floorplan` revision
- `timing_optimization` FAIL (ECO cell count > 2% of total cells) → `routing` (max 1×)
- `signoff` timing fail → `timing_optimization`
- `signoff` DRC/LVS fail → `routing`
- `signoff` power/EM fail → `power_optimization`

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and known tool quirks. Use this to inform stage decisions — for example, ORFS density thresholds, sky130 CTS skew targets, antenna repair rates, or ECO convergence limits.

During a PD flow, it is useful to record key outcomes such as WNS/TNS, DRC counts, utilisation, IR drop, and ECO counts per stage. If the project uses a persistent knowledge system, these can be written out for reuse across designs. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/pd-rules.md](references/pd-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/pd-flow.md](references/pd-flow.md) — broader flow narrative
- [../chip-design-architecture/scripts/qor_trends.py](../chip-design-architecture/scripts/qor_trends.py) — cross-run QoR trend utility (shared)
