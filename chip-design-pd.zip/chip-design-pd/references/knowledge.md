# Physical Design Domain Knowledge

## Known Failure Patterns

- **ORFS density > 65% -> routing congestion**: OpenROAD/ORFS placement density above 65% almost
  always correlates with routing congestion (DRC violations in routing stage). Reduce target
  density in `floorplan` to 60-65% before retrying; do not push past 70% without manual congestion
  analysis.
- **CTS target skew for sky130 at 500 MHz**: Use 50 ps target skew for 500 MHz designs in sky130.
  Tighter targets (< 30 ps) are unreachable with OpenROAD CTS and will cause the CTS stage to
  loop indefinitely.
- **Post-route timing closure ECO rounds**: Post-route timing closure typically requires 2-3 ECO
  rounds. If WNS has not converged after 3 rounds, escalate to floorplan revision.
- **LVS failures from missing substrate tie-offs**: The most common LVS failure in sky130 is
  missing n-well tie-offs and substrate tie-offs. Ensure the floorplan inserts them at required pitch.

## Successful Tool Flags

### Open-source (recommended)

- `make DESIGN_CONFIG=... finish` (ORFS) — run the full pipeline to completion before reading
  `reports/.../metrics.json`; partial runs leave stale metrics files.
- `klayout -rd input=<gds> -r <drc_script.rb> -zz` — batch DRC mode; `-zz` suppresses GUI and
  is required for CI/CD integration.
- `klayout -b -r <lvs_script.py>` — batch LVS mode for open-source signoff.
- `openroad -no_init` with `read_lef`/`read_def`/`report_checks` TCL sequence — useful for
  one-shot timing queries on a routed design without reloading the full ORFS database.

### Commercial (optional)

- Innovus, ICC2, Calibre flags — use only when the user explicitly selects a commercial PD tool.

## PDK / Tool Quirks

### Open-source

- **sky130 antenna rules**: sky130 antenna rules are stricter than most commercial PDKs. Enable
  antenna repair (`repair_antennas`) in OpenROAD after routing; expect 5-15% of nets to need
  repair on a typical design.
- **OpenROAD global routing vs detailed routing DRC**: Global routing DRC (overflow) does not
  guarantee detailed routing DRC clean. Always check `drc_count` from the metrics file after
  detailed routing — not the global routing overflow count.

### Commercial (optional)

- **Innovus PODv2 CTS command change**: Innovus 23.x uses PODv2 database format. Use
  `clock_opt_design` instead of the old `ccopt_design` flow.
- **Innovus `optDesign -postRoute` requires OCV mode**: Requires
  `setAnalysisMode -analysisType onChipVariation` before `optDesign -postRoute`.
- **Innovus MMMC MMMC-1 vs MMMC-2**: Do not mix `library_set` (MMMC-1) and `timing_condition`
  (MMMC-2) in `create_delay_corner`. Use one style consistently.

## Notes

- `core_area_util_pct` above 85% at sign-off is a hard stop — route congestion and ECO closure
  become intractable above this threshold in sky130 with OpenROAD.
