# PD Flow Reference

This skill covers floorplan, placement, CTS, routing, timing/power/area optimization, and final signoff.

Core outputs are QoR-aware rollback decisions and a complete physical-design delivery package.
