# PD Rules Reference

## Stage Sequence
`floorplan -> placement -> cts -> routing -> timing_optimization -> power_optimization -> area_optimization -> signoff`

## Loop-back Rules
- severe placement timing miss -> floorplan
- routing DRC -> routing
- signoff timing fail -> timing optimization
- signoff DRC/LVS fail -> routing
- signoff power/EM fail -> power optimization

## High-level Rules
- floorplan/congestion/power foundations come first
- maintain full-flow QoR awareness, not one-metric tuning
- timing, DRC/LVS, and power/EM are all rollback gates
- large ECO volume indicates upstream issues

## Common Placement Issues and Fixes

| Issue | Fix |
|-------|-----|
| ORFS density > 65% → routing congestion | Reduce target density in floorplan to 60–65%; do not push past 70% without manual congestion analysis |
| Cell density hotspot > 90% | Add placement blockage or expand floorplan in that region |

## Signoff Domain Rules (STA, DRC, LVS, ERC, GDS)

1. STA sign-off: run all required PVT corners (OpenSTA with OCV derate for open-source flow; PrimeTime with POCV/AOCV for commercial flow)
2. DRC: KLayout batch (recommended): `klayout -rd input=<gds> -r <drc_script.rb> -zz`; Calibre/ICV (commercial — optional) — zero violations required
3. LVS: KLayout LVS (recommended) or Calibre/ICV (commercial) — netlist vs layout — zero errors
4. ERC: electromigration and IR drop sign-off (OpenROAD PDNSim for basic IR drop; RedHawk for full EM — commercial)
5. Final GDS: merge all layers, add seal ring, chip-level DRC
