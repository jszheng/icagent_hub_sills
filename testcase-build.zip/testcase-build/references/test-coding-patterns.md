# Test Coding Patterns

## 1. Common Scenario Categories (Design-Independent)

| Category | Purpose | Applicable when | Source |
|----------|---------|----------------|--------|
| Basic function | Core data path verification | Always | testplan P0 scenarios |
| Config traversal | Cover all legal configuration combinations | Design has configurable registers | spec_analysis.registers (writable fields) |
| Error injection | Verify error detection and reporting | Design has error handling logic | spec_analysis.error_conditions |
| Reset | Verify reset behavior and register defaults | Always | spec_analysis.clock_reset |
| Reset during operation | Verify reset robustness mid-transaction | Design has FSM | fsm_analysis (non-idle states) |
| Back-to-back | Verify continuous operation | Design has FIFO or pipeline | spec_analysis.interfaces |
| Register read/write | Verify register access correctness | Design has registers | spec_analysis.registers |
| Boundary values | Verify extreme input values | Always | spec_analysis.registers (field widths) |
| Interrupt | Verify interrupt generation and clear | Design has interrupt output | spec_analysis (interrupt registers) |

## 2. Virtual Sequence 4-Step Pattern

Every virtual sequence body follows this pattern:

```systemverilog
task body();
  // === Step 1: Configure ===
  // Write configuration registers through bus agent
  // Example: set data width, enable features, set parameters
  `uvm_do_on_with(config_seq, p_sequencer.bus_sqr, {
    addr == CFG_REG_ADDR;
    data == cfg_value;
    write == 1;
  })

  // === Step 2: Stimulate ===
  // Send main stimulus through appropriate agent
  `uvm_do_on_with(data_seq, p_sequencer.data_sqr, {
    // Constrain stimulus per scenario requirements
  })

  // === Step 3: Wait ===
  // Wait for operation to complete
  // Options: poll status register, wait for interrupt, fixed delay
  // Prefer polling over fixed delay for robustness

  // === Step 4: Check (optional) ===
  // Additional register reads to verify status
  // Main data comparison is in scoreboard
endtask
```

## 3. Test Registration Checklist

Every new test must complete all items:

```
1. Test class has `uvm_component_utils(<test_name>)
2. Test file is `included in project package
3. Test name is added to sim/testname.f
4. Corresponding vseq class has `uvm_object_utils(<vseq_name>)
5. Vseq file is `included in project package
6. run_phase has raise_objection before vseq.start
7. run_phase has drop_objection after vseq.start returns
8. build_phase calls super.build_phase(phase)
```

## 4. Naming Convention

```
Test class:  <feature>_<scenario>_test     e.g. tx_basic_test, rx_parity_error_test
Vseq class:  <feature>_<scenario>_vseq     e.g. tx_basic_vseq, rx_parity_error_vseq
Test file:   <project>_tests.sv            or individual <feature>_<scenario>_test.sv
Vseq file:   <project>_virtual_sequences.sv or individual files
```

## 5. Example: Industry UVM Test Log (Expected Output)

A properly working test produces UVM log output like:

```
UVM_INFO @ 0: reporter [RNTST] Running test tx_basic_test...
UVM_INFO @ 100: uvm_test_top.env.apb_agent.monitor [APB_MON] Write: addr=0x00 data=0x41
UVM_INFO @ 5200: uvm_test_top.env.uart_agent.monitor [UART_MON] Frame received: data=0x41
UVM_INFO @ 5200: uvm_test_top.env.scoreboard [SCB] Match: expected=0x41 actual=0x41
UVM_INFO @ 6000: reporter [TEST_DONE] ** UVM TEST PASSED **

--- UVM Report Summary ---
** Report counts by severity
UVM_INFO :   12
UVM_WARNING :    0
UVM_ERROR :    0
UVM_FATAL :    0
```

Key indicators of PASS:
- `UVM_ERROR : 0`
- `UVM_FATAL : 0`
- `UVM TEST PASSED` or `TEST PASSED` in log
