// =============================================================================
// UVM Virtual Sequence Skeleton
// Replace placeholders before use:
//   <VSEQ_NAME>  - Virtual sequence class name (e.g., apbuart_smoke_vseq)
//   <VSEQ_BASE>  - Base virtual sequence to extend (e.g., apbuart_vseq_base)
//   <VSQR_TYPE>  - Virtual sequencer type (e.g., apbuart_virtual_sequencer)
// =============================================================================

class <VSEQ_NAME> extends <VSEQ_BASE>;

  `uvm_object_utils(<VSEQ_NAME>)
  `uvm_declare_p_sequencer(<VSQR_TYPE>)

  // --------------------------------------------------------------------------
  // Constraints (add randomizable fields above, constraints here)
  // --------------------------------------------------------------------------

  // --------------------------------------------------------------------------
  // Constructor
  // --------------------------------------------------------------------------
  function new(string name = "<VSEQ_NAME>");
    super.new(name);
  endfunction : new

  // --------------------------------------------------------------------------
  // Body - 4-step pattern
  // --------------------------------------------------------------------------
  virtual task body();

    // Step 1: Configure
    //   Write configuration registers, set up DUT operating mode.

    // Step 2: Stimulate
    //   Drive primary stimulus through agent sequencers.

    // Step 3: Wait
    //   Wait for DUT to process stimulus (clock cycles, events, flags).

    // Step 4: Check
    //   Read back status/data registers, let scoreboard verify results.

  endtask : body

endclass : <VSEQ_NAME>
