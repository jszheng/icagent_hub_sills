// =============================================================================
// UVM Test Class Skeleton
// Replace placeholders before use:
//   <TEST_NAME>   - Test class name (e.g., apbuart_smoke_test)
//   <BASE_TEST>   - Base test class to extend (e.g., apbuart_base_test)
//   <VSEQ_NAME>   - Virtual sequence class name (e.g., apbuart_smoke_vseq)
//   <VSQR_PATH>   - Virtual sequencer path (e.g., env.vsqr)
// =============================================================================

class <TEST_NAME> extends <BASE_TEST>;

  `uvm_component_utils(<TEST_NAME>)

  // --------------------------------------------------------------------------
  // Constructor
  // --------------------------------------------------------------------------
  function new(string name = "<TEST_NAME>", uvm_component parent = null);
    super.new(name, parent);
  endfunction : new

  // --------------------------------------------------------------------------
  // Build Phase
  // --------------------------------------------------------------------------
  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // Override factory types or set config_db entries here
  endfunction : build_phase

  // --------------------------------------------------------------------------
  // Run Phase
  // --------------------------------------------------------------------------
  virtual task run_phase(uvm_phase phase);
    <VSEQ_NAME> vseq;

    phase.raise_objection(this, {get_name(), " raising objection"});

    vseq = <VSEQ_NAME>::type_id::create("vseq");
    assert(vseq.randomize()) else
      `uvm_fatal(get_name(), "Virtual sequence randomization failed")
    vseq.start(<VSQR_PATH>);

    phase.drop_objection(this, {get_name(), " dropping objection"});
  endtask : run_phase

endclass : <TEST_NAME>
