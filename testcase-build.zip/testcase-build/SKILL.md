---
name: testcase-build
description: Use when the user needs to generate UVM test cases and virtual sequences from a testplan. Produces test classes, virtual sequences, and updates testname.f. Each test follows the standard factory-registered pattern with raise/drop objection. Code generation only -compilation and simulation verification is Stage 5.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Test Case Build

Generate UVM test classes and virtual sequences from testplan, register into regression.

## Boundaries

- **Spec-driven test generation**: all test scenarios derived from Spec behavior, NOT from observing RTL
- Only creates/modifies test and sequence files -**never modifies env components** (agent, scoreboard, driver, monitor)
- Batch generation: P0 first, wait for user/Stage 5 confirmation before P1
- Does not invoke EDA tools -compilation is Stage 5's job
- testplan.json updates are additive (status field), never removes scenarios

## Input

| Item | Required | Source |
|------|----------|--------|
| testplan.json | Yes | Stage 1 output or user-provided equivalent |
| UVM environment code | Yes | Stage 2 output (need base_test, vseq_base, pkg) |
| spec_analysis.json | No | Stage 1 output (for register addresses in sequences) |

**Standalone mode**: user provides testplan (JSON or verbal description of scenarios) + existing UVM base_test class.

### Input Validation

Before starting, verify:
- `testplan.json` exists and has `scenarios[]` array with at least one entry
- Each scenario has required fields: `id`, `group`, `name`, `priority`, `steps`, `expected_result`
- At least one scenario has `priority: "P0"` (core data path must be tested)
- UVM base_test class exists in `uvm_tb/` (contains class extending `uvm_test`)
- UVM vseq_base class exists in `uvm_tb/` (contains class extending `uvm_sequence`)
- If `spec_analysis.json` is used for register addresses: verify `registers[]` array is non-empty and each register has `offset` field
- If any missing, report to user with specific missing item and which upstream stage should be re-run

## Workflow

### Step 0: Standalone Entry Check

If upstream artifacts are absent:
- `testplan.json` missing ->prompt the user for:
  - Test scenarios (feature name, priority, stimulus description, expected behavior)
  - Or provide a spec/testplan document for inline extraction
- UVM base_test / vseq_base missing ->prompt the user for:
  - Path to existing UVM environment code
  - Or base test class name and virtual sequencer name to extend from
- `spec_analysis.json` missing ->proceed without register address lookup (user must provide register offsets in scenario descriptions if needed)

### Commands

```bash
# Input: docs/testplan.json + existing UVM env in uvm_tb/
# Output: test files in uvm_tb/, updated sim/testname.f
```

### Step 1: Extract Scenario List from Testplan

Read `testplan.json.scenarios[]`, sort by priority: P0 first, then P1, then P2.

### Step 2: Generate Test Class per Scenario

Each scenario maps to:
- 1 test class extending `<project>_base_test`
- 1 virtual sequence extending `<project>_vseq_base`

Test class structure:

```systemverilog
class <scenario>_test extends <project>_base_test;
  `uvm_component_utils(<scenario>_test)

  function new(string name = "<scenario>_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);  // MUST call super
    // Override config if this test needs non-default settings
  endfunction

  task run_phase(uvm_phase phase);
    <scenario>_vseq vseq = <scenario>_vseq::type_id::create("vseq");
    phase.raise_objection(this);
    vseq.start(env.virtual_sequencer);  // or env.v_sqr
    phase.drop_objection(this);
  endtask
endclass
```

### Step 3: Generate Virtual Sequence per Scenario

vseq body follows the universal 4-step pattern:

```systemverilog
class <scenario>_vseq extends <project>_vseq_base;
  `uvm_object_utils(<scenario>_vseq)

  function new(string name = "<scenario>_vseq");
    super.new(name);
  endfunction

  task body();
    // Step 1: Configure DUT (write config registers via bus agent)
    // Step 2: Send stimulus (drive data through agent)
    // Step 3: Wait for completion (poll status or wait event)
    // Step 4: Optional additional checks
  endtask
endclass
```

### Step 4: Update Testplan with AI Coverage Annotation

For each generated test, update `testplan.json` scenario entry:

| Field | Update to |
|-------|----------|
| `status` | `"covered"` |
| `covered_by` | `"<test_class_name>"` -exact class name |
| `vseq` | `"<vseq_class_name>"` -exact vseq name |
| `source_files` | `["uvm_tb/<test_file>.sv", "uvm_tb/<vseq_file>.sv"]` -full file paths |
| `review_note` | Brief AI description: what this test verifies, key stimulus, expected behavior |

These annotations enable human reviewers to:
- See which testplan scenarios AI has covered vs not covered
- Locate the exact source code for waveform review
- Understand AI's verification intent per scenario

### Step 5: Register to Package and Regression

1. Add `include` lines to package file:
   - **Standard structure** (generated by uvm-env-build): insert after `vseq_base` include, before `endpackage`
   - **Non-standard structure**: read the package file, find the last `include` line, insert after it but before `endpackage`. If no `include` lines exist, insert before `endpackage`. If `endpackage` not found, report error -package file may be malformed.
   - **Dependency rule**: test vseq files must be included BEFORE test class files (vseqs are used inside test classes)
   - **Never duplicate**: check if the include already exists before adding
2. Add test names to `sim/testname.f` (one per line, no duplicates, no comments)

### Step 6: Batch by Priority

1. Generate all P0 tests first
2. Output P0 test list -user takes this to Stage 5 for compile+sim verification
3. After P0 passes, generate P1 tests
4. After P1 passes, generate P2 tests

This prevents generating 30 broken tests at once.

## Output

| Item | Path |
|------|------|
| Test classes | `uvm_tb/<project>_tests.sv` (or individual files) |
| Virtual sequences | `uvm_tb/<project>_test_vseqs.sv` (independent file -do NOT append to Stage 2's `*_virtual_sequences.sv`) |
| Test name list | `sim/testname.f` (updated) |
| Testplan update | `docs/testplan.json` -`status` and `covered_by` fields updated |
| Batch status | Printed to console | "P0 batch complete: N tests generated, ready for Stage 5" |

## Self-Correction

| Check | Condition | Auto-fix |
|-------|-----------|----------|
| Factory registration | Every test has `uvm_component_utils` | Add macro |
| Factory registration | Every vseq has `uvm_object_utils` | Add macro |
| Objection pairing | Every `raise_objection` has matching `drop_objection` | Add missing drop |
| Super call | Every overridden phase method calls `super.<phase>(phase)` | Add call |
| Testname.f sync | Every test class name appears in testname.f | Add missing entries |
| Package include | Every new file is included in package | Add include line |
| No duplicate tests | Test name not already in testname.f | Skip generation |

**Maximum rounds**: 3 rounds of self-correction per priority batch. This limit is non-negotiable.

**Escalation trigger**: Produce `escalation_report.json` when ANY of:
- Factory registration cannot be added automatically (class structure incompatible with UVM macros)
- Objection raise/drop cannot be paired (complex control flow with multiple return paths)
- Base test class or vseq_base class is missing required methods

Format follows the unified escalation schema (defined in spec-to-testplan/references/output-schema.md#escalation_reportjson). Human action: review test class structure, fix inheritance issues, re-run.

## Standards Reference

- IEEE 1800.2-2020: uvm_test, uvm_sequence, factory registration, objection mechanism
- UVM Cookbook: test class patterns, virtual sequence coordination

## References

- [test-coding-patterns.md](references/test-coding-patterns.md) -Read during Steps 2-3 for test class skeleton, vseq 4-step pattern, registration checklist, and naming convention
- [output-schema.md](references/output-schema.md) -Read after generation to verify testname.f format and testplan.json field updates
- [test_class_skeleton.sv](assets/skeletons/test_class_skeleton.sv) -UVM test class skeleton with placeholder markers
- [vseq_skeleton.sv](assets/skeletons/vseq_skeleton.sv) -Virtual sequence skeleton with 4-step pattern
- [testname_template.f](assets/templates/testname_template.f) -testname.f format template
