# Output Schema — Stage 6 Regression

## regression_results.json

```json
{
  "timestamp": "ISO-8601",
  "total_tests": "integer",
  "total_runs": "integer (tests x seeds)",
  "passed": "integer",
  "failed": "integer",
  "pass_rate": "float (percentage)",
  "results": [
    {
      "test": "string",
      "seed": "integer",
      "result": "PASS | FAIL",
      "failure_type": "null | uvm_fatal | uvm_error | timeout | mismatch",
      "failure_category": "null | deterministic | random",
      "log_file": "string"
    }
  ],
  "deterministic_failures": ["string -- test names that fail on all seeds"],
  "random_failures": ["string -- test names with mixed results"]
}
```

### Field Descriptions

| Field | Type | Description |
|-------|------|-------------|
| `timestamp` | string | ISO-8601 timestamp of when the regression was analyzed |
| `total_tests` | integer | Number of unique test names in the regression |
| `total_runs` | integer | Total number of test+seed executions |
| `passed` | integer | Number of runs that passed |
| `failed` | integer | Number of runs that failed |
| `pass_rate` | float | Percentage of passing runs (0.0 to 100.0) |
| `results` | array | Per-run detailed results |
| `results[].test` | string | UVM test class name |
| `results[].seed` | integer | Random seed used for this run |
| `results[].result` | string | `PASS` or `FAIL` |
| `results[].failure_type` | string or null | Category of failure: `uvm_fatal`, `uvm_error`, `timeout`, `mismatch`, or `null` if passed |
| `results[].failure_category` | string or null | `deterministic` (all seeds fail), `random` (mixed), or `null` if passed |
| `results[].log_file` | string | Path to the simulation log file |
| `deterministic_failures` | array of strings | Test names where every seed produced FAIL |
| `random_failures` | array of strings | Test names where some seeds PASS and some FAIL |

## seed_analysis.json

```json
{
  "per_seed_coverage": [
    {
      "seed": "integer",
      "coverage_delta": "float",
      "cumulative": "float"
    }
  ],
  "saturation_detected": "boolean",
  "recommendation": "expand_seeds | stop_expansion | add_directed_tests"
}
```

### Field Descriptions

| Field | Type | Description |
|-------|------|-------------|
| `per_seed_coverage` | array | Ordered list of seeds with their coverage contribution |
| `per_seed_coverage[].seed` | integer | Seed value |
| `per_seed_coverage[].coverage_delta` | float | Marginal coverage added by this seed (percentage points) |
| `per_seed_coverage[].cumulative` | float | Cumulative merged coverage after including this seed |
| `saturation_detected` | boolean | `true` if 3 consecutive seeds produced delta near zero |
| `recommendation` | string | One of: `expand_seeds`, `stop_expansion`, `add_directed_tests` |
