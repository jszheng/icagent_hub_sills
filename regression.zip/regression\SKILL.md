---
name: regression
description: Use when the user needs to run multi-test multi-seed regression, analyze results per test and per seed, classify failures (deterministic vs random), evaluate seed coverage contribution, and recommend next actions.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# Regression

## Boundaries

- **Pipeline mode** (invoked by pipeline-orchestrator): auto-executes simulations via `make` commands
- **Standalone mode** (invoked directly by user): generates commands for user to review and run
- Does **NOT** delete log files or coverage databases
- Does **NOT** modify test source code or UVM environment files
- All analysis is read-only on simulation outputs

## Purpose

Execute a structured regression campaign across all tests with multiple random seeds,
analyze pass/fail results, classify failure modes, evaluate per-seed coverage contribution,
and produce actionable recommendations for coverage closure.

## Input

| Source | Description | Required |
|--------|-------------|----------|
| `sim/testname.f` | Test list (one test name per line) | Yes |
| Working simulation infrastructure | Stage 5 must have verified compile + basic sim | Yes |
| Previous `regression_results.json` | Results from prior regression run | No (optional, for delta comparison) |

### Input Validation

Before starting, verify:
- `sim/testname.f` exists and contains at least one test name
- At least one test has been verified PASS in Stage 5
- If no tests pass, return to Stage 5 first

### Standalone Mode

If invoked outside the pipeline, the user must provide:
- A test list file with one UVM test name per line
- A simulation environment that compiles and runs at least one test successfully

## Workflow

### Step 0: Standalone Entry Check

If upstream artifacts are absent:
- `sim/testname.f` missing ->prompt the user for:
  - Test class names to include in regression (one per line)
  - Or path to an existing test list file
- Working simulation infrastructure not verified ->prompt the user for:
  - Confirmation that at least one test compiles and passes
  - Simulation working directory path
  - Or provide a compile/sim log to verify readiness

### Step 1: Classify Tests

Read `sim/testname.f` and classify each test:

- **Directed tests** (error injection, reset, specific corner cases): run with **1 seed** only.
  Heuristic: test name contains `error`, `reset`, `corner`, `boundary`, `specific`, or test
  has no `std::randomize` / constrained-random stimulus.
- **Random-sensitive tests** (constrained random stimulus): run with **5 seeds** initially.
  Heuristic: test name contains `random`, `stress`, `config`, `burst`, or uses virtual
  sequences with randomized transactions.

Output the classification to the user for confirmation before proceeding.

### Step 2: Generate Regression Commands

Generate `make` commands for execution.

- **Pipeline mode**: execute commands automatically, parse results, proceed to Step 3
- **Standalone mode**: print commands for user to review and run manually; wait for user to confirm execution is done before proceeding to Step 3

Example output:

```bash
# Single-seed bulk regression (all tests, 1 random seed each):
make regression_cov

# Directed tests (1 fixed seed for reproducibility):
make run_cov TEST=<error_test_name> SEED=12345
make run_cov TEST=<reset_test_name> SEED=12345

# Random-sensitive tests (multiple seeds -agent loops over SEED values):
make run_cov TEST=<config_test_name> SEED=12345
make run_cov TEST=<config_test_name> SEED=67890
make run_cov TEST=<config_test_name> SEED=11111
make run_cov TEST=<config_test_name> SEED=22222
make run_cov TEST=<config_test_name> SEED=33333
```

**Note**: There is no `regression_multiseed` Makefile target. Multi-seed regression is implemented by the agent looping over `make run_cov TEST=<test> SEED=<N>` with different seed values. The Makefile's `regression_cov` target runs each test once with `SEED=random`.

### Step 3: Parse Regression Results

After the user executes the regression, parse each test log using:

```bash
python3 scripts/parse_sim_log.py <log_file>
```

**Sync note**: `run-and-debug` skill has an identical copy of `parse_sim_log.py`. When modifying this script, update both copies to keep behavior consistent.

**Aggregation method**: The `parse_sim_log.py` script parses a single log file and outputs structured JSON for that test run. Multi-test and multi-seed aggregation is performed by the agent:
1. Loop over all log files in `sim/` matching `<test_name>.log` or `<test_name>_seed<N>.log`
2. Call `parse_sim_log.py` on each (or parse manually if script unavailable)
3. Aggregate per-test results into `regression_results.json`
4. Aggregate per-seed coverage deltas into `seed_analysis.json`

There is no separate aggregation script -the agent assembles the final JSON from individual parse results.

### Step 4: Classify Failures

For each test that has at least one FAIL:

- **Deterministic failure**: All seeds for the same test produce FAIL.
  Action: this is a logic bug or environment issue; fix before expanding seeds.
- **Random failure**: Same test PASSes with some seeds, FAILs with others.
  Action: investigate constraint gaps, race conditions, or timing-dependent logic.

### Step 5: Seed Value Analysis

For each seed in the regression:

1. Compute `coverage_delta(seed_N) = merged_coverage(1..N) - merged_coverage(1..N-1)`
2. If `delta > 0`: seed is valuable (explored new state space)
3. **Saturation detection**: if 3 consecutive seeds produce `delta = 0`, stop expanding

Record results in `seed_analysis.json`.

### Step 6: Recommendation

Based on Steps 4 and 5, produce one of:

| Condition | Recommendation |
|-----------|----------------|
| Deterministic failures exist | `fix_deterministic_failures` -fix bugs before expanding |
| Random failures exist | `investigate_random_failures` -check constraints and race conditions |
| Seed delta > 2% | `expand_seeds` -increase to 10 seeds per test |
| Seed delta > 1% | `expand_seeds` -increase to 20 seeds per test |
| Seed delta < 0.5% for 3 consecutive | `stop_expansion` -seeds saturated |
| Coverage target met | `regression_complete` |
| Coverage plateau, no failures | `add_directed_tests` -need targeted stimulus for uncovered bins |

## Output

| Artifact | Path | Description |
|----------|------|-------------|
| `regression_results.json` | `docs/regression_results.json` | Per-test PASS/FAIL with failure category |
| `seed_analysis.json` | `docs/seed_analysis.json` | Per-seed coverage delta and saturation info |

See `references/output-schema.md` for the exact JSON schema of both files.

## Self-Correction

- **Random failure detection**: If a test shows mixed PASS/FAIL across seeds, flag it as a random failure and do not count it as a deterministic bug.
- **Deterministic failure detection**: If a test fails on all seeds, flag it as deterministic and prioritize fix over seed expansion.
- **Seed saturation detection**: If 3 consecutive seeds add zero coverage delta, stop recommending more seeds and switch to directed test recommendation.
- **Maximum rounds**: Seed expansion stops after 3 consecutive delta=0 results. This limit is non-negotiable.

**Escalation trigger**: Produce `escalation_report.json` when ANY of:
- Deterministic failures exist (any test fails on ALL seeds -this is a bug, not a seed issue)
- Random failure rate exceeds 20% of total runs (systemic constraint or race condition problem)
- Seed saturation reached AND coverage targets not met (random exploration exhausted)

Format follows the unified escalation schema (defined in spec-to-testplan/references/output-schema.md#escalation_reportjson). Human action: debug deterministic failures with waveform, review constraints for random failures, plan directed tests for remaining coverage gaps.

## Standards

- **IEEE 1800-2017**: Constrained random verification methodology. Same seed + same constraints produces the same stimulus sequence (random stability).
- Seed management follows random stability principles: constraint changes are isolated, fixed-seed reproduction is always available.

## References

- [references/seed-management-patterns.md](references/seed-management-patterns.md) -Read during Steps 1 and 4-5 for seed evaluation methodology, scaling criteria, reproduction commands, and failure classification patterns
- [references/output-schema.md](references/output-schema.md) -Read when producing output files to verify JSON schema for regression_results.json and seed_analysis.json
- [regression_results_template.json](assets/templates/regression_results_template.json) -regression results JSON template
- [seed_analysis_template.json](assets/templates/seed_analysis_template.json) -seed analysis JSON template
