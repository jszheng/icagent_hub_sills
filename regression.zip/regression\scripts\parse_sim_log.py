#!/usr/bin/env python3
"""Parse a simulation log file and produce a structured JSON summary.

Supports VCS, Xcelium, and Questa log formats.
Auto-detects simulator from signature strings in the log.
Classifies findings: uvm_fatal, uvm_error, timeout, mismatch, x_propagation, pass.
Extracts UVM Report Summary if present.

Usage:
    python3 parse_sim_log.py <log_file>

Output (stdout):
    JSON object with simulator, log path, result, UVM summary, and findings.
"""

import json
import re
import sys


def detect_simulator(text):
    """Detect which simulator produced the log."""
    if "Chronologic VCS" in text or "VCS Version" in text or "vcs" in text[:500].lower():
        return "vcs"
    if "xcelium" in text.lower() or "xmsim" in text.lower() or "TOOL:\txrun" in text:
        return "xcelium"
    if "questa" in text.lower() or "vsim" in text.lower() or "Model Technology" in text:
        return "questa"
    return "unknown"


def extract_uvm_summary(text):
    """Extract UVM Report Summary counts."""
    summary = {"info": 0, "warning": 0, "error": 0, "fatal": 0}

    # Pattern: "UVM_INFO :   123" or "UVM_INFO:  123" etc.
    for level in ["info", "warning", "error", "fatal"]:
        pattern = re.compile(
            r"UVM_" + level.upper() + r"\s*[:]\s*(\d+)", re.IGNORECASE
        )
        match = pattern.search(text)
        if match:
            summary[level] = int(match.group(1))

    return summary


def classify_findings(text):
    """Scan log for notable findings and classify each."""
    findings = []
    lines = text.splitlines()

    for i, line in enumerate(lines, start=1):
        line_stripped = line.strip()

        # UVM_FATAL
        if re.search(r"\bUVM_FATAL\b", line, re.IGNORECASE):
            # Skip the summary line
            if re.search(r"UVM_FATAL\s*[:]\s*\d+", line):
                continue
            findings.append({
                "line": i,
                "category": "uvm_fatal",
                "text": line_stripped[:300],
            })

        # UVM_ERROR
        elif re.search(r"\bUVM_ERROR\b", line, re.IGNORECASE):
            if re.search(r"UVM_ERROR\s*[:]\s*\d+", line):
                continue
            # Check for mismatch keywords
            if re.search(r"mismatch|miscompare|expected.*actual|actual.*expected", line, re.IGNORECASE):
                findings.append({
                    "line": i,
                    "category": "mismatch",
                    "text": line_stripped[:300],
                })
            else:
                findings.append({
                    "line": i,
                    "category": "uvm_error",
                    "text": line_stripped[:300],
                })

        # Timeout
        elif re.search(r"\btimeout\b", line, re.IGNORECASE):
            findings.append({
                "line": i,
                "category": "timeout",
                "text": line_stripped[:300],
            })

        # X-propagation — only match explicit X-propagation warnings
        elif re.search(r"\b[Xx][-_]?propagation\b|\bx_prop\b|\$isunknown|\bx[-_]state\b", line, re.IGNORECASE):
            findings.append({
                "line": i,
                "category": "x_propagation",
                "text": line_stripped[:300],
            })

    return findings


def determine_result(uvm_summary, findings):
    """Determine overall PASS/FAIL based on UVM summary and findings."""
    # If we have explicit UVM summary counts, use those
    if uvm_summary["fatal"] > 0 or uvm_summary["error"] > 0:
        return "FAIL"

    # If no UVM summary was found, check findings
    fail_categories = {"uvm_fatal", "uvm_error", "timeout", "mismatch"}
    for f in findings:
        if f["category"] in fail_categories:
            return "FAIL"

    return "PASS"


def determine_failure_type(findings):
    """Determine the primary failure type from findings."""
    # Priority order: uvm_fatal > timeout > mismatch > uvm_error
    categories = {f["category"] for f in findings}
    if "uvm_fatal" in categories:
        return "uvm_fatal"
    if "timeout" in categories:
        return "timeout"
    if "mismatch" in categories:
        return "mismatch"
    if "uvm_error" in categories:
        return "uvm_error"
    return None


def parse_log(log_path):
    """Parse a simulation log file and return structured results."""
    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()

    simulator = detect_simulator(text)
    uvm_summary = extract_uvm_summary(text)
    findings = classify_findings(text)
    result = determine_result(uvm_summary, findings)
    failure_type = determine_failure_type(findings) if result == "FAIL" else None

    return {
        "simulator": simulator,
        "log": log_path,
        "result": result,
        "failure_type": failure_type,
        "uvm_summary": uvm_summary,
        "findings": findings,
    }


def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <log_file>", file=sys.stderr)
        sys.exit(1)

    log_path = sys.argv[1]

    try:
        result = parse_log(log_path)
    except FileNotFoundError:
        print(f"Error: file not found: {log_path}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error parsing log: {e}", file=sys.stderr)
        sys.exit(1)

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
