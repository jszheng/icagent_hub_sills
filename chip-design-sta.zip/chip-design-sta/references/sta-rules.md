# STA Rules Reference

## Stage Sequence
`constraint_validation -> multi_corner_analysis -> path_analysis -> exception_review -> eco_guidance -> sta_signoff`

## Loop-back Rules
- invalid exception -> return to path analysis (max 3x)
- ECO applied -> rerun multi-corner analysis
- ECO scale above threshold -> escalate upstream instead of local patching

## High-level Rules
- all ECO choices must be based on multi-corner evidence
- exception review is mandatory
- setup and hold should be diagnosed separately
- every ECO batch should be followed by STA and often LEC

## Recommended OpenSTA Flags and Batch Mode Configuration

```bash
# OpenSTA timing report
report_timing -path_type full_clock_expanded -delay_type max -nworst 10
# full_clock_expanded shows full clock network; essential for diagnosing skew in WNS

# OpenSTA slack overview
report_slack_histogram -num_bins 20
# quick overview before detailed path analysis; shows whether violations are widespread or concentrated

# OpenSTA batch mode (recommended for CI/CD)
sta -no_splash -exit <script.tcl>
# -exit ensures clean exit with return code; required for CI/CD integration
```

## Common Exception Errors and Consequences

| Error | Consequence |
|-------|------------|
| `set_false_path` on functional CDC | Real metastability risk hidden |
| MCP without hold correction | Hold violations introduced silently |
| Exception too broad (glob match) | Unintended paths unconstrained |
| Expired exception (removed logic) | Stale SDC — may mask other issues |

## ECO Decision Tree

```
Setup violation:
  Logic depth > target?       → Retime / add pipeline stage
  Long wire (> 500 μm)?       → Buffer insertion / reroute on upper metal
  Weak driver?                → Upsize driver cell
  High-Vt on critical path?   → Swap to SVT or LVT
  Reconvergent fanout?        → Clone cell / split net

Hold violation:
  Skew-induced (post-CTS)?    → Useful skew / targeted delay buffer
  Short path (< 1 cycle)?     → Insert HVT delay buffer
  New path from ECO?          → Targeted hold buffer at sink register
```
