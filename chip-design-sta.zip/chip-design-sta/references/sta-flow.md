# STA Flow Reference

This skill covers constraint validation, multi-corner analysis, path review, exception audit, ECO guidance, and timing signoff.

Core outputs are trustworthy timing conclusions and ECO decisions grounded in constraint quality.
