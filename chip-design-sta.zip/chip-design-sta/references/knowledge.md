# STA Domain Knowledge

## Known Failure Patterns

- **OpenSTA hold analysis without set_propagated_clock**: OpenSTA `set_propagated_clock` is
  required before hold analysis. Without it, OpenSTA uses ideal clock (zero skew) for hold
  checks, which produces false "clean hold" results. Always call
  `set_propagated_clock [all_clocks]` before `report_checks -path_delay min`.
- **Multi-corner hold closure needs hold_margin**: Multi-corner hold closure in sky130 usually
  requires setting a `hold_margin` in the target liberty file. The default of 0 ps is insufficient
  for signoff at slow-slow corner with RCMAX parasitics — add 50-100 ps margin.
- **ECO cells > 2% -> upstream issue**: If ECO cell count exceeds 2% of total cells, this almost
  always indicates a floorplan or CTS issue upstream. Escalate to PD team rather than continuing
  ECO iteration.
- **Parasitic extraction accuracy for hold at 28nm and below**: OpenRCX (via OpenROAD) with
  calibrated rules is the minimum for hold signoff. OpenROAD's built-in `estimate_parasitics` is
  not accurate enough. For commercial flows, use SPEF from Calibre xRC or StarRC.

## Successful Tool Flags

### Open-source (recommended)

- `sta -no_splash -exit <script.tcl>` — `-exit` ensures OpenSTA exits cleanly with a return code;
  required for CI/CD integration.
- `report_timing -path_type full_clock_expanded -delay_type max -nworst 10` — `full_clock_expanded`
  shows full clock network paths; essential for diagnosing clock skew contributions to WNS.
- `report_slack_histogram -num_bins 20` — quick overview of slack distribution before detailed
  path analysis.
- `set_timing_derate -early 0.95 -late 1.05` — OCV derating in OpenSTA (no POCV support; use
  conservative flat derate as approximation).

### Commercial (optional)

- **PrimeTime POCV vs AOCV**: POCV is more accurate than AOCV for advanced nodes but requires
  POCV coefficient files from the PDK vendor. OpenSTA does not support POCV — use PrimeTime when
  POCV signoff is required.
- **Tempus MMMC**: Requires `constraint_mode` and `delay_corner` for every combination — missing
  combinations produce incorrect "all clear" reports.

## PDK / Tool Quirks

### Commercial (optional)

- **PrimeTime V-2023.12-SP1 segfault on RHEL 8**: Crashes with Signal 11 during startup on
  RHEL 8. Fix: use PT X-2025.06-SP3 or later.

## Notes

- STA signoff requires `setup_wns_ns >= 0` AND `setup_tns_ps == 0` AND `hold_wns_ps >= 0`
  AND `hold_tns_ps == 0` at ALL corners. A single failing corner blocks tape-out.
