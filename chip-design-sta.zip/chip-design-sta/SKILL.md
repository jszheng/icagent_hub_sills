---
name: chip-design-sta
description: Use when validating timing constraints, running multi-corner STA, reviewing critical paths and timing exceptions, planning ECO guidance, or deciding timing signoff. Trigger even if the user only mentions WNS/TNS, false paths, multicycle paths, constraint audits, path analysis, or timing ECOs.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-sta: Static Timing Analysis and ECO Guidance

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. **OpenSTA** is the recommended default STA engine — reads `.lib` and SDC directly, no license required
2. **OpenROAD STA** provides integrated STA within the OpenROAD physical design flow
3. **Limitations**: OpenSTA does not support POCV natively (AOCV/OCV derating only via manual margin); for advanced-node signoff requiring POCV coefficients, commercial tools (PrimeTime, Tempus) are needed — this is documented honestly
4. Commercial tools (PrimeTime, Tempus) are supported but listed as optional — only use when the user explicitly selects them
5. Detection order: `sta` (OpenSTA) and `openroad` are checked before commercial tool commands

---

## Use Mode

This skill supports two modes:

**Full STA and ECO closure flow:**
- Follow the 6-stage orchestrated flow from constraint validation through timing signoff
- Run multi-corner analysis, audit exceptions, apply ECO, and close all corners
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules when answering targeted questions
- Reference corner matrix, ECO decision tree, or exception rules without running the full flow

**Critical constraints:**
- Always run multi-corner analysis before ECO decisions — never use single-corner results
- LEC required after every ECO batch — do not accumulate ECOs without equivalence check
- ECO cell count > 2% of total cells: hard stop, escalate to physical design team
- Do not enter eco_guidance if any exception from exception_review is pending sign-off

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| sta | `sta` (OpenSTA), `openroad`, `pt_shell`, `tempus` | Required (at least one; open-source recommended) |

### Tool Execution

Open-source (recommended):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| OpenSTA | `sta -no_splash -exit <script.tcl>` | Key output: `report_timing`, `report_tns`, `check_timing`; reads `.lib` directly | Open-source (recommended) |
| OpenROAD STA | `openroad -no_init -exit <sta.tcl>` | STA subsystem within OpenROAD; integrated with PD flow | Open-source |

Commercial (optional):

| Tool | Command | Key notes | Type |
|------|---------|-----------|------|
| PrimeTime | `pt_shell -f <script.tcl>` | Multi-corner: `-multi_scenario`; power: PTPX mode; POCV support | Commercial — Synopsys |
| Tempus | `tempus -f <script.tcl>` | Concurrent MMMC with ECO guidance | Commercial — Cadence |

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `sta` capability is configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which sta`, `which openroad` first (open-source), then `which pt_shell`, `which tempus` (commercial)
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. Required capability with no tool detected → inform user and stop; suggest installing OpenSTA (build from source at github.com/The-OpenROAD-Project/OpenSTA) as open-source option

---

## Stage Workflow

### Stage 1: pdk_analysis

Analyze the PDK to identify available liberty corners before running STA.

**Domain Rules:**
1. List all available PVT corners from liberty/db files: parse filenames for corner patterns (SS, FF, TT)
2. Identify multi-corner set: setup analysis requires SS corner, hold analysis requires FF corner
3. Check for POCV/AOCV coefficient files if available (advanced OCV analysis)
4. Confirm library format compatibility with STA tool (`.lib` for OpenSTA — open-source standard, recommended; `.db` for PrimeTime — commercial only)
5. Record available corners and selected corner matrix before proceeding

**Output Required:**
- Corner matrix: which corners available, which selected for setup/hold analysis
- Liberty file paths per corner

---

### Stage 2: constraint_validation

Audit all timing constraints before trusting timing numbers.

**Validation Checks:**
1. All clocks defined with correct period and waveform
2. All generated clocks: correct source and division/multiplication
3. No unconstrained paths: verify with `report_timing -unconstrained`
4. CDCs: correct `false_path` or `max_delay` applied
5. Multicycle paths: both `-setup N` and `-hold 1` specified together
6. Input/output delays: match system-level timing budget
7. Timing exceptions: not overly broad (masking real violations)
8. Propagated vs ideal clocks: correct mode (ideal pre-CTS, propagated post-CTS)
9. Call `set_propagated_clock [all_clocks]` before hold analysis — without it, OpenSTA uses ideal clock (zero skew), producing false "clean hold" results

**Common Constraint Errors:**

| Error | Consequence |
|-------|------------|
| MCP without hold correction | Hold violations introduced |
| False path too broad | Real timing issues masked |
| Generated clock missing | Path unconstrained |
| Wrong clock period | Over/under-constraining |
| Missing `set_propagated_clock` | False "clean hold" in OpenSTA |

**QoR Metrics:**
- 0 unconstrained paths
- 0 clock definition errors
- All exceptions reviewed and documented

**Output Required:**
- Constraint QA report
- Clock summary (all clocks, sources, periods)
- Exception list with justifications

---

### Stage 3: multi_corner_analysis

Run timing analysis across all required corners and modes.

**Required Corner Matrix:**

| Mode | Setup Corner | Hold Corner |
|------|-------------|-------------|
| Functional | SS/0.9V/125°C | FF/1.1V/−40°C |
| Test (at-speed) | SS/0.9V/125°C | FF/1.1V/25°C |
| Low Power | SS/0.9V/125°C | FF/1.1V/25°C |

**OCV / POCV / AOCV Application:**

OpenSTA (open-source):
1. OCV derating: supported via `set_timing_derate` — use flat derate factors as approximation
2. POCV: **not natively supported by OpenSTA** — apply conservative manual margin instead (add 5-10% derate on data paths)
3. Clock uncertainty: pre-CTS ideal values → post-CTS propagated (must call `set_propagated_clock [all_clocks]`)
4. Hold margin (sky130): add 50–100 ps margin in liberty file — default 0 ps is insufficient at SS corner with RCMAX parasitics
5. Parasitic extraction: use OpenRCX (via OpenROAD) for SPEF generation; for hold signoff at 28nm and below, OpenRCX with calibrated rules is minimum — `estimate_parasitics` is not accurate enough

Commercial (PrimeTime / Tempus — optional):
1. AOCV: apply depth and location-based derating (pre-POCV designs)
2. POCV: apply parametric variation (sigma-based, per foundry agreement); more accurate but requires POCV coefficient files from PDK vendor
3. For hold signoff at 28nm and below: use SPEF from Calibre xRC or StarRC for best accuracy

**Path Analysis Priority:**
1. WNS path per corner (most critical single path)
2. TNS contribution (how many paths fail and by how much)
3. CDC paths with max_delay constraints
4. At-speed paths: launch/capture pair STA

**Sign-off Targets:**

| Metric | Target |
|--------|--------|
| Setup WNS | ≥ 0 all corners |
| Setup TNS | = 0 all corners |
| Hold WNS | ≥ 0 all corners |
| Hold TNS | = 0 all corners |

See [references/sta-rules.md](references/sta-rules.md) for recommended OpenSTA flags and batch mode configuration.

**Output Required:**
- Timing report per corner (setup and hold)
- WNS/TNS summary table across all corners
- Top 100 violating paths

---

### Stage 4: path_analysis

Classify and root-cause all timing violations.

**Domain Rules:**
1. Group failing paths by root cause: long wire, weak driver, logic depth, high-Vt
2. Separate setup violations from hold violations — different fix strategies
3. At-speed violations: check launch/capture pair timing explicitly
4. False paths: verify every exception is still valid after PD changes
5. Reconvergent fanout: flag paths with reconvergence for careful ECO planning

**Output Required:**
- Failing path analysis (root cause per path group)
- Paths requiring ECO vs paths requiring SDC correction

---

### Stage 5: exception_review

Audit every timing exception for correctness and scope.

**Domain Rules:**
1. `set_false_path`: verify the path is truly non-functional (not just inconvenient)
2. `set_multicycle_path`: verify both `-setup N` and `-hold 1` are set correctly
3. `set_max_delay`: verify value matches system-level timing budget
4. Overly broad exceptions: any exception matching > 1% of all paths requires architect approval
5. Exceptions masking real violations: revoke immediately and re-run path analysis
6. Every exception must have documented justification (design intent, async crossing, test mode)
7. Post-ECO exceptions: verify any new exceptions added after ECO are still valid

See [references/sta-rules.md](references/sta-rules.md) for common exception errors and consequences.

**QoR Metrics:**
- 0 exceptions without documented justification
- 0 overly broad exceptions (flagged for architect review)
- Exception list signed off before ECO guidance begins

**Output Required:**
- Exception audit report (valid / revoked / needs-approval per exception)
- Revised SDC with invalid exceptions removed
- Exception sign-off record

---

### Stage 6: eco_guidance

Apply targeted ECOs to close remaining timing violations.

See [references/sta-rules.md](references/sta-rules.md) for the ECO decision tree.

**ECO Rules:**
1. Minimum ECO footprint: fewest cell changes to fix the most violations
2. Prefer resize over add new cell (less routing impact)
3. ECO cells: place in pre-reserved ECO sites or free standard cell rows
4. Re-run STA after every ECO batch — never accumulate blind
5. LEC after every ECO: verify equivalence preserved
6. Never introduce new hold violations while fixing setup (and vice versa)
7. ECO cell count > 2%: hard stop, escalate to PD team — indicates floorplan or CTS issue upstream

**QoR Metrics:**
- ECO efficiency: violations fixed per change
- ECO cell count: < 2% of total cells (flag if exceeded)
- Post-ECO LEC: EQUIVALENT

**Output Required:**
- ECO change list (cell, action, justification)
- Pre/post ECO timing comparison
- ECO LEC result

---

### Stage 7: sta_signoff

Final timing review confirming all corners and modes are clean.

**Sign-off Checklist:**
- [ ] Setup WNS ≥ 0 at all corners
- [ ] Setup TNS = 0 at all corners
- [ ] Hold WNS ≥ 0 at all corners
- [ ] Hold TNS = 0 at all corners
- [ ] All exceptions valid and documented
- [ ] POCV/AOCV applied per foundry spec
- [ ] LEC clean post all ECOs

**Output Required:**
- Sign-off timing report (all corners, all modes)
- ECO change summary
- Timing sign-off record

---

## Sign-off Hard Gates

STA signoff requires ALL of these conditions at ALL corners:

- `setup_wns_ns >= 0` (no setup violations)
- `setup_tns_ps == 0` (zero total negative setup slack)
- `hold_wns_ps >= 0` (no hold violations)
- `hold_tns_ps == 0` (zero total negative hold slack)

**Critical note:**
A single failing corner blocks tape-out. For OpenSTA, run separate scripts per corner and merge results. For Tempus MMMC (commercial only), `constraint_mode` and `delay_corner` must be set for every combination — missing combinations produce incorrect "all clear" reports.

---

## Loop-Back Rules

- `path_analysis` violations found → `exception_review` (unlimited)
- `exception_review` invalid exceptions → retry `path_analysis` (max 3×)
- `eco_guidance` ECO applied → retry `multi_corner_analysis` (max 10× total)
- `eco_guidance` ECO cell count > 2% → escalate to PD team (hard stop)

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and known tool quirks. Use this to inform stage decisions — for example, known OpenSTA propagated clock requirement, hold margin conventions for sky130, or ECO escalation thresholds.

During a STA/ECO flow, it is useful to record key outcomes such as WNS/TNS per corner, ECO cell counts, loop-back counts, and exceptions added or revoked. If the project uses a persistent knowledge system, these can be written out for reuse across designs. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/sta-rules.md](references/sta-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/sta-flow.md](references/sta-flow.md) — broader flow narrative
- [../chip-design-architecture/scripts/qor_trends.py](../chip-design-architecture/scripts/qor_trends.py) — cross-run QoR trend utility (shared)
