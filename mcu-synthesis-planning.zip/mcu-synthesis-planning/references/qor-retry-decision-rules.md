# QoR Retry Decision Rules

Use this guide when deciding whether synthesis should simply be rerun or whether upstream work must change.

## Small retry is reasonable when

- the miss is marginal
- the run used obviously weak effort settings
- a specific constraint typo or missing generated clock was fixed

## Upstream rollback is more likely when

- the frequency target is unrealistic for the architecture
- bus, memory, or wrapper structure dominates the critical path
- power is high because clock intent or activity assumptions are wrong
- the same QoR miss survives multiple clean runs
