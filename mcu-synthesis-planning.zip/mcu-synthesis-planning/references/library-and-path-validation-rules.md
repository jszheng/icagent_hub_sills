# Library And Path Validation Rules

Before treating synthesis output as meaningful, validate the input set:

- filelist paths exist and point to the intended RTL revision
- SDC paths exist and reference real top-level ports and clocks
- standard-cell `.db` inputs and macro `.lib` inputs are distinguished correctly
- required corners actually exist for the selected analysis set
- embedded paths are absolute or otherwise safe for batch-job execution

If these checks fail, classify the issue as setup integrity failure instead of QoR failure.
