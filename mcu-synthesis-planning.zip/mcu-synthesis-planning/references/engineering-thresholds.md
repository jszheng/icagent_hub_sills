# Engineering Thresholds

Use these as practical review bands, not as universal foundry truth.

## Timing

- `WNS >= 0 ns`: handoff-ready from a setup perspective
- `-0.10 ns < WNS < 0 ns`: marginal miss; a focused retry may be reasonable
- `WNS <= -0.10 ns`: treat as meaningful miss; investigate structural cause before cosmetic reruns

## Power

- `<= target`: acceptable for this stage
- `within 5% above target`: investigate gating and activity assumptions before deeper rollback
- `> 5% above target`: treat as material power miss, not a rounding issue

## Decision Rules

- A marginal miss is still a miss, but it can justify a smaller retry.
- Repeated misses in the same band point to architecture, constraint, or activity-model problems.
