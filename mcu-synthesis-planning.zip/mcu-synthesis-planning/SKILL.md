---
name: mcu-synthesis-planning
description: Generate SDC constraints, run logic synthesis (DC/Genus), analyze QoR, and review synthesis readiness for an MCU SoC design. Use when moving from verified RTL to gate-level netlist, or when synthesis reports need interpretation and optimization.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Synthesis Planning

Use this skill to generate timing constraints, run synthesis, and review results. Covers both execution (SDC generation, tool invocation) and analysis (QoR review, constraint quality, optimization priorities).

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify RTL. Optimization suggestions feed back to the user. (Companion skill: `mcu-rtl-development`)
- Do **not** run PnR. (Companion skill: `mcu-pnr-implementation`)
- Do **not** run equivalence checking. (Companion skill: `mcu-equivalence-review`)

## Good Outcome

Produce:

- SDC timing constraints generated from spec clock definitions
- synthesized gate-level netlist
- synthesis reports (timing, area, power, QoR)
- QoR assessment with pass/fail and optimization priorities
- SVF guidance file for downstream equivalence verification

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| `eda_env.json` | From EDA env setup if available | Yes |
| `doc/spec.md` | User-provided or from spec planning stage | Yes (for SDC generation) |
| `rtl/filelist.f` | User-provided or from RTL development stage | Yes |
| Verification pass evidence | From compile/sim stage if available | Recommended |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| SDC constraints | `sdc/<design>.sdc` | Generated timing constraints |
| Synthesis script | `scripts/syn_run.tcl` | Filled TCL from template |
| Netlist | `output/syn/<design>_syn.v` | Gate-level Verilog |
| Post-syn SDC | `output/syn/<design>_syn.sdc` | Propagated constraints |
| SVF | `output/syn/<design>.svf` | Guidance for Formality (DC only) |
| Reports | `rpt/syn_timing.rpt`, `syn_area.rpt`, `syn_power.rpt`, `syn_qor.rpt` | Synthesis reports |

## Input Validation

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.synthesizer` | Not null, one of: dc_shell, genus | Template and command selection |
| `available_tools[]` for synthesizer | `path` not null | Binary location |
| `pdk` | Library paths populated | TCL library setup |
| `libraries.std_cell` | At least one corner with .db or .lib files | target_library / read_libs |

### From spec.md

| Required section | What to check | Used for |
|---|---|---|
| Clock domains | Name, frequency, port for each clock | SDC generation via gen_sdc.py |
| Design name | Top module name | TCL current_design |

## Workflow

### Step 1: Generate SDC constraints

**Check if SDC already exists** before generating:

1. If `sdc/<design>.sdc` does **not** exist → run gen_sdc.py:
   ```
   python3 scripts/gen_sdc.py --spec doc/spec.md --output sdc/<design>.sdc
   ```
   Review the generated SDC. If spec has multiple clock domains, verify `set_clock_groups` is correct. If spec has generated clocks (dividers), add `create_generated_clock` manually.

2. If `sdc/<design>.sdc` **already exists** → check the file header to determine its origin:
   - Header contains `gen_sdc.py` → auto-generated, safe to overwrite.
   - Header does **not** contain `gen_sdc.py` (or contains hand-edited comments like per-port delays, false paths, operating conditions) → likely hand-tuned.

   **Ask the user** which action to take:
   - **Keep**: use existing SDC as-is, skip generation.
   - **Overwrite**: regenerate from spec (warning: hand-tuned constraints will be lost).
   - **Compare**: run gen_sdc.py to a temp file, diff against existing SDC, let user decide which parts to merge.

   Do **not** silently skip or overwrite — the decision must come from the user.

### Step 2: Select synthesis tool and fill template

Read `eda_env.json → selected_tools.synthesizer`:

**If DC Shell**: Read `scripts/dc_syn_template.tcl`, fill placeholders:

| Placeholder | Value source |
|---|---|
| `{{DESIGN}}` | spec.md → design name |
| `{{TOP_MODULE}}` | spec.md → top module |
| `{{SEARCH_PATH}}` | eda_env.json → library directory paths |
| `{{TARGET_LIBRARY}}` | eda_env.json → libraries.std_cell.ss.db (setup corner) |
| `{{LINK_LIBRARY}}` | target_library + SRAM .db files |
| `{{READ_RTL_FILES}}` | Expand filelist.f into `read_file -format verilog <file>` lines |
| `{{SDC_PATH}}` | `sdc/<design>.sdc` |
| `{{RPT_DIR}}` | `rpt` |
| `{{OUTPUT_DIR}}` | `output/syn` |
| `{{SRAM_READ_LIB_CMDS}}` | `read_lib` commands for SRAM macro .lib files (if no .db available); empty if all macros are in link_library |
| `{{DONT_TOUCH_CMDS}}` | Per black-box module: `set_dont_touch [get_designs <module>]`; empty if no black boxes |
| `{{COMPILE_CMD}}` | Synthesis compile command, default: `compile_ultra -no_autoungroup` |

Write filled script to `scripts/syn_run.tcl`.

**If Genus**: Read `scripts/genus_syn_template.tcl`, fill similarly:

| Placeholder | Value source |
|---|---|
| `{{LIB_FILES}}` | eda_env.json → libraries.std_cell.ss.lib (.lib not .db) |
| `{{FILELIST}}` | `rtl/filelist.f` |
| Other fields | Same mapping as DC |

Write filled script to `scripts/syn_run.tcl`.

### Step 2.5: Pre-clean (built into TCL templates)

The templates contain a pre-clean block that backs up previous outputs to `output/syn/iterN/` and deletes conflict-prone files (SVF, DDC, alib cache, etc.) before synthesis starts. It prompts the user for confirmation before any deletion. See [pre-clean-and-backup-rules.md](references/pre-clean-and-backup-rules.md) for detailed rationale.

### Step 3: Execute synthesis

**DC Shell:**
```
dc_shell -f scripts/syn_run.tcl | tee rpt/dc_syn.log
```

**Genus:**
```
genus -f scripts/syn_run.tcl -log rpt/genus_syn.log
```

If LSF is available (from eda_env.json), submit via `bsub` as async job.

### Step 4: Parse results

Check log for completion marker (`DC_SYNTHESIS_COMPLETE` or `GENUS_SYNTHESIS_COMPLETE`).

Parse reports using `scripts/parse_syn_qor.py` or extract manually:

| Metric | Source | Pass criteria |
|---|---|---|
| WNS (setup) | `rpt/syn_timing.rpt` | >= 0 ns |
| Total area | `rpt/syn_area.rpt` | Reported |
| Total power | `rpt/syn_power.rpt` | < power budget from spec |
| Cell count | `rpt/syn_area.rpt` | Reported |

### Step 5: QoR assessment and routing

| Result | Route to | Action |
|---|---|---|
| WNS >= 0, power < budget | `mcu-equivalence-review` | Proceed to formal verification |
| WNS < 0 (small, < -0.1ns) | Retry with higher effort or constraint tuning | Iterate |
| WNS < 0 (large) | Review RTL architecture or clock constraints | May need rollback to `mcu-rtl-development` |
| Power > budget | Review clock gating, check for unnecessary toggling | May need RTL optimization |
| Compile error | `mcu-verification-triage` | Diagnose synthesis error |

## Synthesis Quality Rules

### Constraint review checklist

Before treating synthesis results as meaningful, verify SDC quality:
- Primary clocks are defined and named consistently with spec
- Generated clocks are declared (not left as implicit dividers)
- I/O delay values are realistic for the target application
- False-path and multicycle exceptions are justified and documented
- Reset behavior is not hidden by careless timing exceptions
- `set_clock_groups -asynchronous` is correct for multi-domain designs

### QoR risk patterns

Common sources of poor QoR that require upstream fixes, not synthesis retries:
- Unstable hierarchy or wrapper contracts creating artificial critical paths
- Unrealistic frequency target relative to architecture complexity
- Clock gating intent not reflected in RTL or constraints — synthesis infers unnecessary logic
- Memory and bus structure creating avoidable critical paths (structural, not random)

### Clock gating synthesis patterns

- Preserve the distinction between intended gating points and inferred gating accidents
- Review whether clock enables are stable enough for ICG cell inference
- Expect power analysis to be misleading if clock intent is only partially expressed in constraints
- Use `set_clock_gating_check` to control inference behavior

## Bundled References

- [library-and-path-validation-rules.md](references/library-and-path-validation-rules.md) — library setup validation
- [qor-retry-decision-rules.md](references/qor-retry-decision-rules.md) — when to retry vs rollback
- [engineering-thresholds.md](references/engineering-thresholds.md) — WNS/power judgment bands
- [pre-clean-and-backup-rules.md](references/pre-clean-and-backup-rules.md) — backup strategy and conflict file deletion rationale

## Bundled Assets

- [synthesis-review-template.md](assets/synthesis-review-template.md) — synthesis review output format
- [example-synthesis-review.md](assets/example-synthesis-review.md) — sample synthesis review output
- [sample-qor-summary.json](assets/sample-qor-summary.json) — structured QoR summary example

## Bundled Scripts

- [dc_syn_template.tcl](scripts/dc_syn_template.tcl) — DC synthesis TCL template
- [genus_syn_template.tcl](scripts/genus_syn_template.tcl) — Genus synthesis TCL template
- [gen_sdc.py](scripts/gen_sdc.py) — SDC constraint generator from spec
- [parse_syn_qor.py](scripts/parse_syn_qor.py) — QoR report parser

## Completion Gate

- SDC constraints generated and reviewed
- Synthesis script generated from template with project-specific values
- Synthesis executed, netlist exists
- Reports parsed, WNS/power/area extracted
- QoR pass/fail assessed with next-step routing

## Decision Rules

- Bad constraints should be treated as stage blockers, not minor warnings.
- Distinguish architecture-driven QoR pressure from accidental coding issues.
- If WNS is negative but small (< 0.1ns), try higher effort before escalating.
- If WNS is negative and large (> 0.5ns), do not iterate — rollback to RTL or constraints.
- **Power decision rules** (consolidated from engineering-thresholds.md):
  - Total power <= budget from spec: acceptable.
  - Total power within 5% above budget: investigate clock gating and activity assumptions before escalating.
  - Total power > 5% above budget: treat as material power miss — rollback to RTL (clock gating, module optimization) or re-examine activity assumptions. Do not iterate synthesis alone.
- SVF is only produced by DC, not Genus. If using Genus, equivalence must use Conformal.
- Back up previous synthesis outputs before re-running. Templates handle this automatically via iterN backup + targeted deletion. See [pre-clean-and-backup-rules.md](references/pre-clean-and-backup-rules.md).
- Do **not** set `SKIP_CONFIRM 1` in interactive sessions — confirmation before deletion is mandatory for attended runs.

