# Synthesis Review: [Design Name]

## Reviewed inputs

List all input files verified before reviewing QoR:
- RTL filelist path and file count
- SDC constraint file path
- Library corner used (ss/ff/tt)
- Report files read (timing, area, power, qor)

Note any inputs that were missing or stale.

## Constraint quality

Assess SDC quality against the constraint review checklist:
- Are all clocks defined and named consistently with spec?
- Are generated clocks declared?
- Are I/O delays realistic?
- Are false-path/multicycle exceptions justified?
- Is reset behavior properly constrained?

Rate: **Clean** / **Has issues** / **Blocker**

## QoR risk summary

| Metric | Value | Target | Status |
|--------|-------|--------|--------|
| WNS (setup) | from rpt | >= 0 ns | PASS/MARGINAL/FAIL |
| Total area | from rpt | reported | — |
| Total power | from rpt | < budget | PASS/FAIL |
| Cell count | from rpt | reported | — |

For each MARGINAL or FAIL metric, state whether the cause is structural (architecture/RTL) or cosmetic (constraint/effort tuning).

## Ranked action list

Numbered list of actions in priority order. For each:
1. What to do
2. Why (what evidence supports this action)
3. Expected impact

## Next skill

- **Primary**: which skill to proceed to if QoR is acceptable
- **Fallback**: which skill to roll back to if QoR issues are structural
