## Reviewed inputs

- `rtl/filelist.f`
- `sdc/mcu_top.sdc`
- `rpt/syn_timing.rpt`
- `rpt/syn_area.rpt`
- `rpt/syn_power.rpt`

## Constraint quality

- Primary clock is declared and named consistently
- Generated peripheral clock is implied in architecture notes but not fully constrained
- Reset false-path intent exists but should be reviewed for overreach

## QoR risk summary

- Setup WNS is slightly negative on a bus-to-memory path
- Power is close to target because clock gating intent is only partially visible
- Critical path appears structural rather than random optimization noise

## Ranked action list

1. Confirm generated clock declaration and asynchronous grouping
2. Review bus-to-memory path for architectural depth
3. Check whether gating enables are inferable in current RTL
4. Re-run only after the above is explicit

## Next skill

- Primary: `mcu-pnr-implementation` if constraints stabilize and QoR is acceptable
- Fallback: `mcu-rtl-development` if the critical path is architecture-driven
