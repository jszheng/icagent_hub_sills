# {{GENERATED_BY}}
# Cadence Genus Synthesis Script
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-synthesis-planning skill
# NOTE: Genus does not produce SVF guidance files. Use Conformal (not Formality) for equivalence checking.

#--------------------------------------------------------------
# Pre-clean: backup previous outputs to iterN directory
# Set SKIP_CONFIRM to 1 for batch/LSF mode (no interactive prompt)
#--------------------------------------------------------------
if {![info exists SKIP_CONFIRM]} { set SKIP_CONFIRM 0 }

if {[file exists {{OUTPUT_DIR}}/{{DESIGN}}_syn.v]} {
    set _iter 1
    while {[file exists {{OUTPUT_DIR}}/iter${_iter}]} { incr _iter }
    set _bak_dir {{OUTPUT_DIR}}/iter${_iter}

    # Iteration cap warning
    if {$_iter > 10} {
        puts "============================================================"
        puts "WARNING: iteration count = ${_iter}, backup dirs are piling up."
        puts "  Consider cleaning old iterations to reclaim disk space."
        puts "  Run: ls -lhd {{OUTPUT_DIR}}/iter*"
        puts "============================================================"
    }

    puts "=========================================================="
    puts "WARNING: Previous synthesis outputs detected."
    puts "  Will backup to: ${_bak_dir}"
    if {[file exists fv]} {
        puts "  Will delete:    fv/ (stale hints break Conformal)"
    }
    if {[glob -nocomplain genus.cmd* genus.log*] ne ""} {
        puts "  Will delete:    genus.cmd*/genus.log* (accumulated residuals)"
    }
    puts "=========================================================="

    if {!$SKIP_CONFIRM} {
        puts -nonewline "Proceed with backup and clean? \[y/N\]: "
        flush stdout
        gets stdin _ans
        if {$_ans ne "y" && $_ans ne "Y"} {
            puts "INFO: Aborted by user. Exiting."
            exit 1
        }
    }

    file mkdir ${_bak_dir}
    foreach _f [glob -nocomplain {{OUTPUT_DIR}}/{{DESIGN}}_syn.v \
                                 {{OUTPUT_DIR}}/{{DESIGN}}_syn.sdc] {
        file copy -force ${_f} ${_bak_dir}/
    }
    foreach _f [glob -nocomplain {{RPT_DIR}}/syn_*.rpt] {
        file copy -force ${_f} ${_bak_dir}/
    }
    # Genus fv/ hints directory — stale hints cause Conformal conflicts
    if {[file exists fv]} {
        file copy -force fv ${_bak_dir}/
        file delete -force fv
    }
    # genus.cmd*/genus.log* — accumulated session residuals, may mislead debugging
    foreach _f [glob -nocomplain genus.cmd* genus.log*] {
        file delete -force ${_f}
    }
    puts "INFO: previous outputs backed up to ${_bak_dir}"
}

#--------------------------------------------------------------
# Library Setup
#--------------------------------------------------------------
set_db init_lib_search_path "{{SEARCH_PATH}}"
read_libs {{{LIB_FILES}}}

#--------------------------------------------------------------
# Read Design
#--------------------------------------------------------------
read_hdl -sv -f {{FILELIST}}
elaborate {{TOP_MODULE}}

#--------------------------------------------------------------
# Constraints
#--------------------------------------------------------------
read_sdc {{SDC_PATH}}

#--------------------------------------------------------------
# Synthesis
#--------------------------------------------------------------
syn_generic
syn_map
syn_opt

#--------------------------------------------------------------
# Reports
#--------------------------------------------------------------
report_timing > {{RPT_DIR}}/syn_timing.rpt
report_area   > {{RPT_DIR}}/syn_area.rpt
report_power  > {{RPT_DIR}}/syn_power.rpt
report_qor    > {{RPT_DIR}}/syn_qor.rpt

#--------------------------------------------------------------
# Output
#--------------------------------------------------------------
write_hdl > {{OUTPUT_DIR}}/{{DESIGN}}_syn.v
write_sdc > {{OUTPUT_DIR}}/{{DESIGN}}_syn.sdc

puts "GENUS_SYNTHESIS_COMPLETE"
exit
