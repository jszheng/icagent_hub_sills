import json
import re
import sys


def extract_float(pattern: str, text: str):
    match = re.search(pattern, text, re.I)
    return float(match.group(1)) if match else None


def main() -> int:
    text = sys.stdin.read()
    payload = {
        "wns_ns": extract_float(r"WNS[^-0-9]*(-?\d+(?:\.\d+)?)", text),
        "tns_ns": extract_float(r"TNS[^-0-9]*(-?\d+(?:\.\d+)?)", text),
        "power_mw": extract_float(r"(?:total|internal\s*\+\s*switching\s*\+\s*leakage)\s*[=:]\s*([0-9]+(?:\.\d+)?)\s*m?[wW]", text)
                  or extract_float(r"total\s+power[^0-9]*([0-9]+(?:\.\d+)?)\s*m?[wW]", text)
                  or extract_float(r"power[^0-9]*([0-9]+(?:\.\d+)?)\s*m?[wW]", text),
        "area_um2": extract_float(r"total\s+(?:cell\s+)?area[^0-9]*([0-9]+(?:\.\d+)?)", text)
                  or extract_float(r"area[^0-9]*([0-9]+(?:\.\d+)?)", text),
        "cell_count": extract_float(r"(?:number\s+of\s+cells|cell\s+count|instances)[^0-9]*([0-9]+)", text),
    }
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
