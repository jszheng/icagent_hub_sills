# {{GENERATED_BY}}
# Design Compiler Synthesis Script — generated from dc_syn_template.tcl
# Design: {{DESIGN}}
# Do not edit manually — regenerate via mcu-synthesis-planning skill

set PROJ_HOME "{{PROJ_HOME}}"

#-------------------------------------------------------------------------------
# Pre-clean: backup previous outputs to iterN directory, delete conflict files
# Set SKIP_CONFIRM to 1 for batch/LSF mode (no interactive prompt)
#-------------------------------------------------------------------------------
if {![info exists SKIP_CONFIRM]} { set SKIP_CONFIRM 0 }

if {[file exists {{OUTPUT_DIR}}/{{DESIGN}}.svf]} {
    # Find next iteration number
    set _iter 1
    while {[file exists {{OUTPUT_DIR}}/iter${_iter}]} { incr _iter }
    set _bak_dir {{OUTPUT_DIR}}/iter${_iter}

    # Iteration cap warning
    if {$_iter > 10} {
        puts "============================================================"
        puts "WARNING: iteration count = ${_iter}, backup dirs are piling up."
        puts "  Consider cleaning old iterations to reclaim disk space."
        puts "  Run: ls -lhd {{OUTPUT_DIR}}/iter*"
        puts "============================================================"
    }

    puts "=========================================================="
    puts "WARNING: Previous synthesis outputs detected."
    puts "  Will backup to: ${_bak_dir}"
    puts "  Will delete:    {{OUTPUT_DIR}}/{{DESIGN}}.svf (DC appends, breaks Formality)"
    puts "                  {{OUTPUT_DIR}}/{{DESIGN}}.ddc (may be corrupted)"
    if {[glob -nocomplain alib-52 alib_*] ne ""} {
        puts "                  alib cache (stale if libraries changed)"
    }
    if {[file exists default.svf]} {
        puts "                  ./default.svf (DC residual in working dir)"
    }
    puts "=========================================================="

    if {!$SKIP_CONFIRM} {
        puts -nonewline "Proceed with backup and clean? \[y/N\]: "
        flush stdout
        gets stdin _ans
        if {$_ans ne "y" && $_ans ne "Y"} {
            puts "INFO: Aborted by user. Exiting."
            exit 1
        }
    }

    file mkdir ${_bak_dir}
    foreach _f [glob -nocomplain {{OUTPUT_DIR}}/{{DESIGN}}_syn.v \
                                 {{OUTPUT_DIR}}/{{DESIGN}}_syn.sdc \
                                 {{OUTPUT_DIR}}/{{DESIGN}}.svf \
                                 {{OUTPUT_DIR}}/{{DESIGN}}.ddc] {
        file copy -force ${_f} ${_bak_dir}/
    }
    foreach _f [glob -nocomplain {{RPT_DIR}}/syn_*.rpt] {
        file copy -force ${_f} ${_bak_dir}/
    }
    puts "INFO: previous outputs backed up to ${_bak_dir}"
    # SVF must be deleted — DC appends, causing Formality guidance conflicts
    file delete -force {{OUTPUT_DIR}}/{{DESIGN}}.svf
    # DDC may be corrupted from prior crash
    file delete -force {{OUTPUT_DIR}}/{{DESIGN}}.ddc
    # default.svf — DC sometimes writes a copy in the working directory
    file delete -force default.svf
    # alib cache — stale cache silently uses old library; only safe to rebuild
    foreach _d [glob -nocomplain alib-52 alib_*] {
        file delete -force ${_d}
    }
}

# SVF guidance file for Formality
set_svf {{OUTPUT_DIR}}/{{DESIGN}}.svf

#-------------------------------------------------------------------------------
# Library Setup
#-------------------------------------------------------------------------------
set target_library [list \
{{TARGET_LIBRARY_LIST}}
]

set link_library [list "*" \
{{LINK_LIBRARY_LIST}}
]

set search_path [list \
{{SEARCH_PATH_LIST}}
]

# Read SRAM macro .lib files (if no .db available)
{{SRAM_READ_LIB_CMDS}}

#-------------------------------------------------------------------------------
# Read Design from filelist
#-------------------------------------------------------------------------------
set fp [open "$PROJ_HOME/{{FILELIST}}" r]
set file_data [read $fp]
close $fp
set file_list [list]
foreach line [split $file_data "\n"] {
    set line [string trim $line]
    if {$line ne "" && [string index $line 0] ne "#" && [string range $line 0 1] ne "//"} {
        if {[string index $line 0] ne "/"} {
            lappend file_list $PROJ_HOME/$line
        } else {
            lappend file_list $line
        }
    }
}

analyze -format verilog $file_list
elaborate {{TOP_MODULE}}
current_design {{TOP_MODULE}}
link

#-------------------------------------------------------------------------------
# Dont Touch (black-box IP cores)
#-------------------------------------------------------------------------------
{{DONT_TOUCH_CMDS}}

#-------------------------------------------------------------------------------
# Apply Timing Constraints
#-------------------------------------------------------------------------------
source {{SDC_PATH}}

#-------------------------------------------------------------------------------
# Synthesis
#-------------------------------------------------------------------------------
# Default: compile_ultra -no_autoungroup
# For higher effort: compile_ultra -no_autoungroup -timing_high_effort_script
{{COMPILE_CMD}}

#-------------------------------------------------------------------------------
# Reports
#-------------------------------------------------------------------------------
report_timing -max_paths 10 > {{RPT_DIR}}/syn_timing.rpt
report_area -hierarchy       > {{RPT_DIR}}/syn_area.rpt
report_power                 > {{RPT_DIR}}/syn_power.rpt
report_qor                   > {{RPT_DIR}}/syn_qor.rpt

#-------------------------------------------------------------------------------
# Save Outputs
#-------------------------------------------------------------------------------
write -format verilog -hierarchy -output {{OUTPUT_DIR}}/{{DESIGN}}_syn.v
write_sdc -nosplit {{OUTPUT_DIR}}/{{DESIGN}}_syn.sdc
write_file -format ddc -hierarchy -output {{OUTPUT_DIR}}/{{DESIGN}}.ddc

puts "DC_SYNTHESIS_COMPLETE"
exit
