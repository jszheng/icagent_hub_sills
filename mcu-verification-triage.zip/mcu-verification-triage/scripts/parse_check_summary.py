import json
import re
import sys


PATTERNS = {
    "compile_error": re.compile(r"Error-|cannot find module|undefined module|\*E,|\*F,", re.I),
    "compile_warning": re.compile(r"Warning-|\*W,", re.I),
    "lint_fatal": re.compile(r"Fatals?\s*:\s*[1-9]|FATAL\s*:", re.I),
    "lint_error": re.compile(r"Errors?\s*:\s*[1-9]", re.I),
    "lint_warning": re.compile(r"Warnings?\s*:\s*[1-9]", re.I),
    "assertion_fail": re.compile(r"Assertion.*failed|assert.*error", re.I),
    "test_failed": re.compile(r"TEST_FAILED|SIM_FAIL", re.I),
    "test_passed": re.compile(r"TEST_PASSED|SIM_PASS", re.I),
    "uvm_fatal": re.compile(r"UVM_FATAL", re.I),
    "uvm_error": re.compile(r"UVM_ERROR", re.I),
    "timeout": re.compile(r"timeout|timed out", re.I),
}


def main() -> int:
    text = sys.stdin.read()
    payload = {name: bool(pattern.search(text)) for name, pattern in PATTERNS.items()}
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
