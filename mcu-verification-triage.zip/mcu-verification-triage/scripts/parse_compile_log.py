import json
import re
import sys


PATTERNS = [
    ("missing_module", re.compile(r"cannot find module|undefined module", re.I)),
    ("port_mismatch", re.compile(r"port.*mismatch", re.I)),
    ("syntax_error", re.compile(r"syntax error", re.I)),
    ("undeclared", re.compile(r"undeclared|implicit.*wire|not declared", re.I)),
    ("width_mismatch", re.compile(r"width mismatch|size mismatch", re.I)),
    ("multiple_drivers", re.compile(r"multiple drivers|net.*contention|multiply driven", re.I)),
    ("duplicate_def", re.compile(r"redeclar|duplicate.*module|already defined", re.I)),
]


def main() -> int:
    text = sys.stdin.read()
    matches = [name for name, pattern in PATTERNS if pattern.search(text)]
    payload = {"classifications": matches or ["unknown_compile_issue"]}
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
