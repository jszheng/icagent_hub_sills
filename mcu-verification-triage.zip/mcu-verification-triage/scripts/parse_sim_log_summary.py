import json
import re
import sys


PATTERNS = {
    "timeout": re.compile(r"timeout|timed out", re.I),
    "uvm_fatal": re.compile(r"UVM_FATAL", re.I),
    "uvm_error": re.compile(r"UVM_ERROR", re.I),
    "test_failed": re.compile(r"TEST_FAILED|SIM_FAIL", re.I),
    "assertion_fail": re.compile(r"assert.*fail|assertion.*error|SVA.*error", re.I),
    "test_passed": re.compile(r"TEST_PASSED|SIM_PASS|UVM_INFO.*Test passed", re.I),
}


def main() -> int:
    text = sys.stdin.read()
    payload = {name: bool(pattern.search(text)) for name, pattern in PATTERNS.items()}
    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
