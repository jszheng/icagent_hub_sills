---
name: mcu-verification-triage
description: Triage Cortex-M3 MCU verification failures across compile, simulation, lint, and CDC evidence. Use when the user has a failing log, checker message, or report and needs the safest next debugging action instead of blind reruns.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU Verification Triage

Use this skill when the user already has a concrete failure artifact and needs to understand the problem before changing code or rerunning tools.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** modify RTL or TB source code. Produce a structured diagnostic and let the user or a companion skill apply the fix. (Companion skills: `mcu-rtl-development`, `mcu-tb-development`)
- Do **not** run compilation or simulation. (Companion skill: `mcu-compile-sim-run`)
- Do **not** replace deep formal, synthesis, or PnR analysis with shallow triage.
- Do **not** hide uncertainty when the log is incomplete — state what is unknown.

## Good Outcome

Produce a stage result that includes:

- failure classification
- strongest available evidence
- likely root-cause category
- smallest safe next action
- rerun, rollback, or escalation guidance

## Stage Entry Criteria

Use this stage when at least one of the following is available:

- compile log (`sim/compile.log`)
- simulation log (`sim/sim.log`)
- lint or CDC report
- failing testcase name with checker output
- run record (`doc/run_record.json`) from `mcu-compile-sim-run`

## Input Validation

### From run_record.json (produced by `mcu-compile-sim-run`, optional)

| Field | What to check | Used for |
|---|---|---|
| `compile.status` | "pass" or "fail" | Determines if triage targets compile or sim |
| `compile.log` | Path to compile log file | Reading error messages |
| `simulate.status` | "pass", "fail", or "timeout" | Determines sim failure type |
| `simulate.log` | Path to sim log file | Reading failure output |
| `simulate.test` | Test name that was run | Contextualizing the failure |
| `mode` | "full", "incremental", "single_test", "lint" | Understanding what was executed |

If `run_record.json` is not available, fall back to reading log files directly.

### From compile.log / sim.log (produced by `mcu-compile-sim-run`)

| What to check | Used for |
|---|---|
| File exists and is non-empty | Triage has evidence to work with |
| Timestamp is newer than RTL/TB source files | Confirms log is from latest code |

## Workflow

### Step 1: Log-based triage

Start from the artifact that failed, not from a generic full-flow checklist.

1. Read compile.log or sim.log (from run_record.json or directly).
2. Classify whether the issue is structural, behavioral, environment-related, or evidence-poor.
3. If the log contains a clear error message with file:line, produce a structured diagnostic directly.
4. If the log shows TEST_FAILED but the message is vague, proceed to Step 2 (waveform).

### Step 2: Waveform-based debug (when log analysis is insufficient)

When to use waveform analysis:

| Symptom | Why log isn't enough |
|---|---|
| TEST_FAILED with generic message | Need to see signal values at failure time |
| TEST_TIMEOUT (simulation hung) | Need to find which signal is stuck |
| Intermittent failure (seed-dependent) | Need to compare passing vs failing signal traces |
| Protocol timing violation | Need to verify setup/hold/handshake timing |
| Interrupt not responding | Need to trace IRQ signal path |
| Data corruption (wrong read value) | Need to trace write → storage → read path |

#### Step 2a: Verify waveform file exists

Check `sim/wave.fsdb` (VCS) or `sim/waves.shm` (Xcelium). If missing, recommend re-running simulation with dump enabled:

**VCS:** Add `-fsdb +fsdb+autoflush` to simulation command and `$fsdbDumpfile`/`$fsdbDumpvars` to TB.

**Xcelium:** Add `-access +rwc` to compile and probe TCL to simulation.

#### Step 2b: Signal tracing strategy

Do NOT look at all signals. Trace backwards from the failure point:

1. **Start at the failure**: Identify the checker/assertion that fired — what signal had the wrong value?
2. **Trace the source**: Where does that signal come from? (register output → combinational logic → input port)
3. **Check the driver**: Is the driving logic getting correct inputs? Check one level back.
4. **Check timing**: Is the signal changing at the right clock edge? Is there a clock domain crossing?
5. **Check reset**: Was the signal properly reset? Check the first few cycles after reset release.

#### Step 2c: Common waveform patterns

| Pattern in waveform | Likely cause |
|---|---|
| Signal is X (unknown) | Uninitialized register, missing reset, or floating input |
| Signal is Z (high-impedance) | Unconnected port or tri-state driver not enabled |
| Signal changes one cycle late | Pipeline stage mismatch or wrong clock edge |
| Signal glitches between clock edges | Combinational loop or race condition |
| Bus data correct but address wrong | Address decode error in interconnect |
| Interrupt asserts but never clears | Missing W1C logic or wrong clear address |

#### Step 2d: Waveform tool invocation

Read `eda_env.json → selected_tools.waveform` to determine viewer:

**Verdi:** `verdi -ssf sim/wave.fsdb -top tb_top &`
**SimVision:** `simvision sim/waves.shm &`

### Step 3: Produce triage result

Classify the failure and identify the narrowest next action. Call out when a rerun is justified and when it is waste. End with a compact triage summary.

## Bundled References

- Use [layered-verification-strategy.md](references/layered-verification-strategy.md) when deciding whether the next action should stay in basic TB, lint/CDC, or full UVM.
- Use [spec-rtl-consistency-checks.md](references/spec-rtl-consistency-checks.md) when the failure may really be a contract mismatch.

Use the bundled scripts and assets when structured summaries help:

- [parse_compile_log.py](scripts/parse_compile_log.py)
- [parse_check_summary.py](scripts/parse_check_summary.py)
- [parse_sim_log_summary.py](scripts/parse_sim_log_summary.py)
- [debug-triage-template.md](assets/debug-triage-template.md)
- [example-debug-triage.md](assets/example-debug-triage.md)
- [sample-debug-triage.json](assets/sample-debug-triage.json)

## Completion Gate

This stage is complete when:

- the failure class is explicit
- the proposed next action is smaller than a blind full rerun
- escalation or rollback conditions are visible

## Reusable Outputs

- failure class
- evidence summary
- probable root-cause category
- next-action recommendation
- escalation notes

### Structured diagnostic (for downstream `mcu-rtl-development` / `mcu-tb-development`)

When the triage result routes to a code fix, produce a structured diagnostic with these fields:

| Field | Type | Description |
|---|---|---|
| `source` | "rtl" or "tb" | Whether the fix should target RTL or testbench |
| `file` | string | Path to the failing source file |
| `line` | number or null | Line number of the error (if known) |
| `error_type` | string | One of: syntax, port_mismatch, missing_module, logic_bug, lint_violation, wrong_expected, missing_checker, wrong_timing, false_pass |
| `message` | string | Compiler/simulator error text |
| `suggested_fix` | string or null | Brief fix direction (if evident from evidence) |
| `cascade_hint` | string | "compile_only", "compile_and_lint", or "full_reverify" |

## Triage Pattern Reference

### Compile failure patterns

| Pattern | Likely cause | Next action |
|---------|-------------|-------------|
| Missing module or undefined reference | File absent from filelist, or filelist order wrong | Check filelist, add missing file or fix order |
| Port size mismatch | Width inconsistency between instance and declaration | Report exact module/port/expected vs actual |
| Macro or parameter dependency not included | Missing `+define+` or include path | Check compile flags and `+incdir+` |
| Unsupported language construct | Tool mode mismatch (Verilog-2001 vs SystemVerilog) | Check `-sverilog` flag |

### Simulation failure patterns

| Pattern | Likely cause | Next action |
|---------|-------------|-------------|
| Reset never releases cleanly | Reset synchronizer wiring or TB reset sequence issue | Check waveform at reset release |
| Address decode or peripheral selection wrong | Interconnect decode constant mismatch | Compare RTL decode constants with spec memory map |
| Interrupt behavior differs from plan | IRQ routing, trigger type, or clear mechanism wrong | Trace IRQ signal path in waveform |
| Memory initialization assumptions missing | Boot ROM or SRAM has X values | Check preload or initialization in TB |
| Checker expectation stale | TB expected values don't match current spec | Re-derive expected values from spec |

### Escalation triggers

Escalate to user or upstream skill when:
- The same failure crosses multiple stages or tools
- Evidence suggests environment or license instability (not a design bug)
- The real issue is interface ambiguity or missing architecture intent — roll back to spec/architecture
- Repeated reruns change symptoms without a stable hypothesis

### Rerun waste patterns

Do NOT recommend a rerun when:
- The user is repeating the same failing command without a new hypothesis
- The issue is clearly missing inputs or broken constraints (rerun won't help)
- Flaky environment symptoms are being treated as proof of RTL instability

### Manual review triggers

Flag for manual human review when:
- The same symptom crosses compile, sim, and checker layers
- Log evidence is incomplete or contradictory
- Issue may involve black-box IP boundary behavior
- Suspected checker-model drift could invalidate debug conclusions

## Decision Rules

- Prefer evidence over instinct.
- Separate tool-environment trouble from design trouble.
- Do not recommend rerun unless it can answer a new question.
