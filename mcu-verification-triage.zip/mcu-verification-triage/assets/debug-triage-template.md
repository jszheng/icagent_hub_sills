# Debug Triage Report

## Failing artifact

State which file(s) contain the failure evidence:
- Log file path (e.g., `sim/compile.log`, `sim/sim.log`)
- Failing test name (if simulation)
- Tool and version that produced the log

## Failure classification

Classify as one of:
- **Structural**: compile error, missing module, port mismatch
- **Behavioral**: simulation assertion failure, wrong output value, timeout
- **Environment**: tool crash, license issue, cache corruption
- **Evidence-poor**: log is incomplete or ambiguous

## Strongest evidence

Quote the most relevant line(s) from the log. Include file:line if available. If waveform was used, describe the key signal observation (e.g., "HREADY stuck low from cycle 150").

## Likely root-cause category

State the probable cause category:
- Integration contract (spec-RTL mismatch)
- Logic bug (RTL functional error)
- TB issue (wrong expected value, missing checker)
- Environment (tool/OS/license)
- Unknown (insufficient evidence)

## Smallest safe next action

One concrete, actionable step. Not "debug more" but a specific action like "check address decode constants in ahb_interconnect.v line 42 against spec memory map."

## Escalate or roll back

State whether this issue should be:
- **Fixed locally**: diagnostic routes to RTL or TB fix
- **Escalated**: needs user decision, involves black-box IP, or crosses multiple stages
- **Rolled back**: real issue is upstream (spec ambiguity, architecture mismatch)
