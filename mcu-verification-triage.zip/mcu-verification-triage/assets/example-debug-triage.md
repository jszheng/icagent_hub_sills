## Failing artifact

- `sim/compile.log`
- failing module instantiation under `rtl/top/mcu_top.v`

## Failure classification

- structural integration failure
- likely missing module or filelist-order issue

## Strongest evidence

- compile log reports undefined module for an APB peripheral wrapper
- the same hierarchy appears in top-level assembly but is absent from the current filelist inventory

## Likely root-cause category

- integration contract or compile-input issue

## Smallest safe next action

Rebuild the filelist inventory and verify whether the missing wrapper is truly absent or only ordered incorrectly.

## Escalate or roll back

If the wrapper exists but its ports no longer match the architecture contract, roll back to `mcu-rtl-development` rather than iterating inside testbench debug.
