# Layered Verification Strategy

Use a three-layer model instead of jumping straight to the heaviest environment.

## Layer 1

Basic TB compile and simulation for fast iteration:

- run after local RTL changes
- validate reset release, simple bus access, and smoke behavior
- use when the question is "did I break the block"

## Layer 2

Lint and CDC for structural quality:

- run before synthesis handoff
- treat true structural errors as stage blockers
- do not let UVM hide unresolved latch, multi-driver, or CDC issues

## Layer 3

UVM or broader system verification:

- run when block-level behavior is stable enough to justify longer cycles
- use for cross-block behavior, interrupt ordering, stress, and scenario coverage

## Decision Rules

- If Layer 1 or Layer 2 is unstable, do not pretend Layer 3 is the right next step.
- Prefer the cheapest layer that can answer the current question.
- Treat basic TB and lint as required evidence, not optional warm-up work.
