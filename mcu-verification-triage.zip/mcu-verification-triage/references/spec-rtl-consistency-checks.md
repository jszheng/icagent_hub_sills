# Spec RTL Consistency Checks

Before deep debug, check whether the design contract is internally aligned:

- top-level ports and directions match the intended interface
- register offsets and field semantics match the planning output
- interrupt numbering and ownership match the interrupt map
- reset polarity and release assumptions match the architecture notes

If these do not align, classify the issue as a contract mismatch and roll back to `mcu-spec-architecture-planning` or `mcu-rtl-development` instead of treating it as ordinary testcase failure.
