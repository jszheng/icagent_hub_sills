# ==============================================================================
# Makefile Skeleton for UVM Verification
# Auto-generated — replace <PLACEHOLDER> tokens before use
# Simulator: <SIMULATOR>
# Template:  makefile_skeleton.mk
# Generated: <GENERATED_DATE>
# ==============================================================================

# ------------------------------------------------------------------------------
# Variables
# ------------------------------------------------------------------------------
SIMULATOR    = <SIMULATOR>
TOP          = <TOP_MODULE>
TEST        ?= <DEFAULT_TEST>
SEED        ?= random
VERBOSITY   ?= UVM_MEDIUM
FLIST        = <FLIST_PATH>
COV_DIR      = coverage
COV_REPORT   = coverage_txt

COMPILE_CMD      = <COMPILE_CMD>
COMPILE_COV_CMD  = <COMPILE_COV_CMD>
RUN_CMD          = <RUN_CMD>
COV_REPORT_CMD   = <COV_REPORT_CMD>
CLEAN_CMD        = <CLEAN_CMD>

TESTNAME_FILE = testname.f
TESTS         = $(shell cat $(TESTNAME_FILE))

# ------------------------------------------------------------------------------
# Targets
# ------------------------------------------------------------------------------

.PHONY: compile compile_cov run run_cov regression_cov coverage clean help

## compile — Compile without coverage instrumentation
compile:
	$(COMPILE_CMD)

## compile_cov — Compile with coverage instrumentation
compile_cov:
	$(COMPILE_COV_CMD)

## run — Run a single test without coverage
run:
	$(RUN_CMD) +UVM_TESTNAME=$(TEST) +ntb_random_seed=$(SEED) +UVM_VERBOSITY=$(VERBOSITY)

## run_cov — Run a single test with coverage collection
run_cov:
	$(RUN_CMD) +UVM_TESTNAME=$(TEST) +ntb_random_seed=$(SEED) +UVM_VERBOSITY=$(VERBOSITY) -cm line+cond+tgl+fsm+branch+assert

## regression_cov — Run all tests listed in testname.f with coverage
regression_cov: compile_cov
	@for t in $(TESTS); do \
		echo "===== Running $$t ====="; \
		$(RUN_CMD) +UVM_TESTNAME=$$t +ntb_random_seed=random +UVM_VERBOSITY=$(VERBOSITY) \
			-cm line+cond+tgl+fsm+branch+assert \
			-cm_dir $(COV_DIR)/$$t.vdb; \
	done

## coverage — Merge databases and generate text report
coverage:
	$(COV_REPORT_CMD)

## clean — Remove all generated artifacts
clean:
	$(CLEAN_CMD)

## help — Show available targets
help:
	@echo "Targets:"
	@echo "  compile          Compile without coverage"
	@echo "  compile_cov      Compile with coverage"
	@echo "  run              Run single test (TEST=<name> SEED=<seed>)"
	@echo "  run_cov          Run single test with coverage"
	@echo "  regression_cov   Run all tests with coverage"
	@echo "  coverage         Generate coverage report"
	@echo "  clean            Remove generated artifacts"
