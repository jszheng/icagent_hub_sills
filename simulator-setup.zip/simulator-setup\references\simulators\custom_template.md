# Simulator: <your_tool_name>
#
# Instructions:
#   1. Copy this file to references/simulators/<your_tool_name>.md
#   2. Fill in each field below
#   3. Set "simulator": "<your_tool_name>" in input_config.json
#   4. Pipeline will auto-detect and use your template
#
# All fields are key: value format, one per line.
# Lines starting with # are comments.

## Environment
# module_name: the name used in "module load <name>" (leave empty if not using modules)
module_name:
# check_command: shell command to verify tool is available (e.g. "which <tool_binary>")
check_command:
# env_var: environment variable that points to tool installation (e.g. TOOL_HOME)
env_var:
# vendor: tool vendor name
vendor:

## Compile
# compile: full compile command (without flist, that's appended automatically)
compile:
# compile_cov: compile command with coverage enabled
compile_cov:
# flist_flag: flag to specify file list (e.g. "-f flist" or "-F flist")
flist_flag: -f flist
# incdir_flag: flag to add include directory (e.g. "+incdir+" or "-incdir")
incdir_flag:

## Run
# run: command to start simulation (e.g. "./simv" or "xrun -R")
run:
# run_cov: run command with coverage collection enabled
run_cov:
# testname_flag: flag to specify UVM test name (e.g. "+UVM_TESTNAME=")
testname_flag: +UVM_TESTNAME=
# seed_flag: flag to specify random seed
seed_flag:
# timeout_flag: flag to set simulation timeout
timeout_flag: +UVM_TIMEOUT=
# log_flag: flag to specify log file
log_flag: -l
# cm_name_flag: flag to name coverage test (for merging)
cm_name_flag:

## Coverage Report
# cov_report: command to generate text coverage report
cov_report:
# cov_merge: command to merge multiple coverage databases
cov_merge:

## Waveform
# wave_dump: flag or command to enable waveform dump
wave_dump:
# wave_tool: waveform viewer tool name
wave_tool:

## Error Pattern
# error_pattern: regex to match error lines in compile/sim log
error_pattern:
# warning_pattern: regex to match warning lines
warning_pattern:
# error_example: one example error line from this tool
error_example:

## Clean
# clean: shell command to remove all generated files
clean:
