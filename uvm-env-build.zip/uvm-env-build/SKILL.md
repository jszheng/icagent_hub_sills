---
name: uvm-env-build
description: Use when the user needs to generate a UVM verification environment from spec analysis results. Produces: interfaces, transactions, drivers, monitors, agents, scoreboard, virtual sequencer, environment, sequences, vseq_base, package, base test, and testbench top. Coverage collector is NOT generated here -it is produced by coverage-closure (Stage 7). No EDA compilation in this stage -code generation only.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# UVM Environment Build

Generate complete UVM verification environment code from Stage 1 analysis products.

## Boundaries

- Only creates/modifies files in `uvm_tb/` and `sim/` directories
- **Never modifies RTL source code**
- If `uvm_tb/` files already exist: warn user before overwriting
- All macros centralized in `tb_define.v` -no scattered `define` in individual files
- No EDA tool invocation -compilation verification is Stage 5's responsibility

## Input

| Item | Required | Source |
|------|----------|--------|
| spec_analysis.json | Yes | Stage 1 output or user-provided equivalent |
| fsm_analysis.json | No | Stage 1 output (used for agent topology decisions -e.g., identifying configurable protocol parameters that require dynamic config tracking in monitors) |
| input_config.json | No | Project root (for simulator/clock settings) |

**Standalone mode**: user provides a spec_analysis.json (conforming to Stage 1 schema) or describes interfaces/registers verbally.

### Input Validation

Before starting, verify:
- `spec_analysis.json` exists and has required fields: `design_name`, `interfaces` (non-empty), `registers`, `clock_reset`
- If any required field is missing, report to user and suggest re-running Stage 1

## Workflow

### Step 0: Standalone Entry Check

If upstream artifacts are absent:
- `spec_analysis.json` missing ->prompt the user for:
  - Design interface list (protocol names, signal names, directions, widths)
  - Register map (name, offset, width, access type, reset value)
  - Clock/reset names and polarity
  - Or provide a spec document for inline extraction
- `fsm_analysis.json` missing ->proceed without FSM-driven topology decisions (agent topology determined from interface info only)
- `input_config.json` missing ->use defaults: `simulator: auto`, `clock_freq_mhz: 50`, infer `design_name` from user description

### Commands

```bash
# Input: docs/spec_analysis.json (from Stage 1 or user-provided)
# Output: uvm_tb/*.sv, sim/flist
```

### Step 1: Determine Agent Topology

For each interface in `spec_analysis.interfaces[]`:

| Question | Answer ->Decision |
|----------|-------------------|
| Does the TB need to actively drive this interface? | Yes ->ACTIVE agent (driver + sequencer + monitor) |
| Does the TB only observe this interface? | Yes ->PASSIVE agent (monitor only) |
| Is it bidirectional but DUT-initiated? | ACTIVE agent, sequence controls when to respond |

**Dynamic Config Check (MANDATORY)**:
If `spec_analysis.registers[]` contains ANY RW register that affects protocol behavior on another interface (e.g., baud rate, clock divider, frame format, parity mode), the monitor on that protocol interface MUST implement dynamic config tracking via `uvm_analysis_imp` connected to the bus monitor. See [env-architecture-patterns.md](references/env-architecture-patterns.md) "Dynamic Config Tracking Pattern". Static config from `build_phase` alone is NOT sufficient -it will cause false scoreboard mismatches when tests write config registers mid-simulation.

### Step 2: Define Transaction Classes

Per agent, create a `uvm_sequence_item` with:
- Fields matching interface signals (from `spec_analysis.interfaces[].signals`)
- `constraint` blocks for valid ranges
- `do_compare()`, `do_print()`, `convert2string()` methods

### Step 3: Define Scoreboard Architecture

Standard dual-port comparison pattern:
- Port A: from input-side monitor ->push to expected queue
- Port B: from output-side monitor ->pop expected, compare with actual
- `check_phase`: verify expected queue is empty

See [env-architecture-patterns.md](references/env-architecture-patterns.md) Section 3 for TLM connection pattern.

**Reference model derivation** (critical -this is the scoreboard's core logic):
- See [env-architecture-patterns.md](references/env-architecture-patterns.md) Section 8 for derivation patterns
- Use the decision tree to select the correct pattern based on design type
- Pattern A (register read-back), Pattern B (TX/RX loopback), Pattern C (FIFO pass-through) may be combined
- Reference model must be derived from Spec, never from RTL implementation

### Step 4: Define Config DB Layout

```
testbench_top (module):
  set: virtual interface ->"uvm_test_top.env.<agent>*", "vif_<name>"

test (uvm_test):
  set: config object ->"env.<agent>*", "cfg"

agent (uvm_agent):
  get: virtual interface ->"", "vif_<name>"
  get: config object ->"", "cfg"
```

Key naming convention:
- Virtual interface: `"vif_<protocol>"` (e.g., `"vif_apb"`, `"vif_uart"`)
- Config object: `"cfg"`

Every `get()` must have a matching `set()`.
Fail on `get()` miss must be `uvm_fatal`, never silent skip.

### Step 5: Define Package Organization

Include order must satisfy dependency (depended-on first):

```
1. Macro definitions (tb_define.v)
2. Transaction classes
3. Config objects
4. Agent internals (driver, monitor, sequencer)
5. Agent wrapper
6. Scoreboard
7. Virtual sequencer
8. Environment
9. Sequences (per agent), Virtual sequence base class (vseq_base)
10. Base test
11. Coverage collector (placeholder -actual covergroups generated by Stage 7 coverage-closure)
```

Interface files (.sv with `interface` keyword) compile outside the package.

### Step 6: Generate Code Files

**Macro naming rule**: All macros in `tb_define.v` must use UPPER_CASE with underscores (e.g., `CLK_PERIOD`, `ADDR_WIDTH`, `DATA_WIDTH`). Lowercase or mixed-case macros are not allowed. This is enforced in the Step 7 completeness check.

| File | Content |
|------|---------|
| `uvm_tb/tb_define.v` | All macro definitions (centralized, no duplicates) |
| `uvm_tb/<proto>_interface.sv` | SV interface per protocol |
| `uvm_tb/<proto>_transaction.sv` | Transaction class per agent |
| `uvm_tb/<proto>_config.sv` | Config object per agent |
| `uvm_tb/<proto>_driver.sv` | Driver per active agent |
| `uvm_tb/<proto>_monit.sv` | Monitor per agent |
| `uvm_tb/<proto>_agent.sv` | Agent wrapper |
| `uvm_tb/<project>_scoreboard.sv` | Scoreboard |
| `uvm_tb/<project>_virtual_sequencer.sv` | Virtual sequencer |
| `uvm_tb/<project>_env.sv` | Environment |
| `uvm_tb/<proto>_sequences.sv` | Sequences per agent (base seq + common seqs) |
| `uvm_tb/<project>_vseq_base.sv` | Virtual sequence base class (required by Stage 3) |
| `uvm_tb/<project>_virtual_sequences.sv` | Common virtual sequences (configure, basic TX/RX) |
| `uvm_tb/<project>_pkg.sv` | Package (all includes) |
| `uvm_tb/<project>_base_test.sv` | Base test class |
| `uvm_tb/testbench.sv` | Testbench top module |
| `sim/flist` | Compile file list |

### Step 7: Component Completeness Check

Run self-check before declaring output ready:

| Check | Condition | Auto-fix |
|-------|-----------|----------|
| Every active agent has driver + sequencer + monitor | Missing ->| Add stub |
| Every passive agent has monitor only | Has driver ->| Flag warning |
| Every class has factory registration | Missing `uvm_component_utils` or `uvm_object_utils` ->| Add macro |
| Every build_phase calls `super.build_phase(phase)` | Missing ->| Add call |
| Every config_db `get()` has matching `set()` | Mismatch ->| Flag error with paths |
| Package include order satisfies dependencies | Out of order ->| Reorder |
| No duplicate macro definitions | Duplicate ->| Remove, keep only tb_define.v |
| All macros are UPPER_CASE | Lowercase macro name found ->| Rename to UPPER_CASE |
| flist includes all files in correct order | Missing file ->| Add to flist |
| Dynamic config tracking | Design has RW config regs affecting protocol monitor ->monitor has `uvm_analysis_imp` for bus writes | Add analysis imp + write() method to monitor, connect in env |

## Output

| Item | Path |
|------|------|
| UVM environment code | `uvm_tb/*.sv` |
| Macro definitions | `uvm_tb/tb_define.v` |
| Compile file list | `sim/flist` |
| Component checklist result | Printed summary (PASS/FAIL per check) |

## Self-Correction

- Step 7 checklist is mandatory before output
- If any check fails with auto-fix available: apply fix, re-run check
- If any check fails without auto-fix: report to user with specific file + line
- Maximum 3 self-correction rounds; after that, output with warnings

**Escalation trigger**: Produce `escalation_report.json` when ANY of:
- config_db set/get mismatch remains after 3 rounds (key name or type conflict)
- Interface port width cannot be resolved from spec_analysis (ambiguous signal width)
- Package include circular dependency detected (cannot be auto-reordered)

Format follows the unified escalation schema (defined in spec-to-testplan/references/output-schema.md#escalation_reportjson). Human action: resolve config_db naming, clarify signal widths, break circular dependency manually.

## Standards Reference

- IEEE 1800.2-2020: component hierarchy, factory, config_db, phases, TLM
- IEEE 1800-2017: interface, modport, virtual interface
- UVM Cookbook (Mentor/Siemens): agent architecture, scoreboard patterns
- Verification Academy: environment topology best practices

## References

- [env-architecture-patterns.md](references/env-architecture-patterns.md) -Read during Steps 1-5 for UVM topology, scoreboard TLM, config_db layout, and package organization patterns
- [output-schema.md](references/output-schema.md) -Read after Step 7 to verify component checklist format matches expected output

### Code Skeletons (assets/skeletons/)

Template files used during Step 6 code generation. Each skeleton contains UVM boilerplate with `<PLACEHOLDER>` markers to be replaced with design-specific values:

- `interface_skeleton.sv`, `transaction_skeleton.sv`, `config_skeleton.sv`
- `driver_skeleton.sv`, `monitor_skeleton.sv`, `agent_skeleton.sv`
- `scoreboard_skeleton.sv`, `env_skeleton.sv`, `pkg_skeleton.sv`
- `base_test_skeleton.sv`, `testbench_skeleton.sv`, `tb_define_skeleton.v`
- [flist_template.f](assets/templates/flist_template.f) -compile file list template
