`ifndef <PROTO>_INTERFACE_SV
`define <PROTO>_INTERFACE_SV

interface <PROTO>_interface(input logic <CLK>, input logic <RST>);

  // --- Signal declarations ---
  <SIGNAL_LIST>
  // Example:
  // logic        sig_a;
  // logic [7:0]  sig_b;

  // --- Clocking blocks (optional, for driver/monitor timing) ---
  // clocking drv_cb @(posedge <CLK>);
  //   default input #1 output #1;
  //   <DRIVER_CLOCKING_SIGNALS>
  // endclocking

  // clocking mon_cb @(posedge <CLK>);
  //   default input #1;
  //   <MONITOR_CLOCKING_SIGNALS>
  // endclocking

  // --- Modports ---
  // modport DRV (clocking drv_cb, input <CLK>, input <RST>);
  // modport MON (clocking mon_cb, input <CLK>, input <RST>);

endinterface : <PROTO>_interface

`endif
