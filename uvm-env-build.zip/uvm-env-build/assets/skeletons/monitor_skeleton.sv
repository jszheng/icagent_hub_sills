`ifndef <PROTO>_MONITOR_SV
`define <PROTO>_MONITOR_SV

class <PROTO>_monitor extends uvm_monitor;

  `uvm_component_utils(<PROTO>_monitor)

  virtual <PROTO>_interface vif;
  <PROTO>_config cfg;

  uvm_analysis_port #(<PROTO>_transaction) ap;

  // ======================================================================
  // DYNAMIC CONFIG TRACKING (required when design has RW config registers
  // that affect this monitor's sampling behavior, e.g. baud rate, frame length)
  //
  // If this monitor's protocol is configurable at runtime via bus writes:
  //   1. Declare config fields here (baud_rate, frame_length, etc.)
  //   2. Declare uvm_analysis_imp for bus transactions
  //   3. Implement write() to update config fields on register writes
  //   4. In env connect_phase: bus_agt.mon.ap.connect(this_agt.mon.config_imp)
  //
  // If this monitor is NOT affected by runtime config: remove this section.
  // ======================================================================

  // Dynamic config fields — updated by write() when bus writes config registers
  // <DYNAMIC_CONFIG_FIELDS>
  // Example:
  // bit [16:0] baud_rate    = DEFAULT_BAUD;
  // bit [3:0]  frame_length = 4'd8;

  // Analysis imp to receive bus transactions for config tracking
  // uvm_analysis_imp #(<BUS>_transaction, <PROTO>_monitor) config_imp;

  function new(string name = "<PROTO>_monitor", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ap = new("ap", this);
    // config_imp = new("config_imp", this);  // Uncomment if dynamic config needed
    if (!uvm_config_db #(<PROTO>_config)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", {"Config not set for ", get_full_name()})
    vif = cfg.vif;
  endfunction

  // Dynamic config update — called when bus monitor sees a config register write
  // Uncomment and implement if this monitor needs runtime config tracking.
  //
  // function void write(<BUS>_transaction tr);
  //   if (tr.write) begin
  //     case (tr.addr)
  //       BAUD_REG_ADDR:  baud_rate    = tr.data;
  //       FRAME_REG_ADDR: frame_length = tr.data[3:0];
  //     endcase
  //   end
  // endfunction

  virtual task run_phase(uvm_phase phase);
    // Wait for reset de-assertion
    <WAIT_RESET>
    // Example:
    // @(posedge vif.<RST>);

    forever begin
      <PROTO>_transaction tr;
      tr = <PROTO>_transaction::type_id::create("tr");

      // --- Sample transaction from interface ---
      // Replace <SAMPLE_LOGIC> with protocol-specific sampling logic.
      // ap.write(tr) must be INSIDE a valid-transaction condition.
      // Do NOT call ap.write(tr) unconditionally — it floods the scoreboard.
      <SAMPLE_LOGIC>
      // Example:
      // @(posedge vif.<CLK>);
      // if (vif.valid) begin
      //   tr.data  = vif.data;
      //   tr.rw    = vif.rw;
      //   ap.write(tr);
      // end
    end
  endtask

endclass : <PROTO>_monitor

`endif
