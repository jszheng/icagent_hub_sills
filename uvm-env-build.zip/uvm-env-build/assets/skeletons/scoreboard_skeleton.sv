`ifndef <DESIGN>_SCOREBOARD_SV
`define <DESIGN>_SCOREBOARD_SV

// Declare TLM analysis imp suffixes for dual-port scoreboard
`uvm_analysis_imp_decl(_<PORT_A>)
`uvm_analysis_imp_decl(_<PORT_B>)

class <DESIGN>_scoreboard extends uvm_scoreboard;

  `uvm_component_utils(<DESIGN>_scoreboard)

  // --- TLM analysis ports ---
  uvm_analysis_imp_<PORT_A> #(<TX_A_TYPE>, <DESIGN>_scoreboard) <PORT_A>_imp;
  uvm_analysis_imp_<PORT_B> #(<TX_B_TYPE>, <DESIGN>_scoreboard) <PORT_B>_imp;

  // --- Expected queue ---
  <TX_A_TYPE> expected_q[$];

  // --- Counters ---
  int match_count;
  int mismatch_count;

  function new(string name = "<DESIGN>_scoreboard", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    <PORT_A>_imp = new("<PORT_A>_imp", this);
    <PORT_B>_imp = new("<PORT_B>_imp", this);
    match_count    = 0;
    mismatch_count = 0;
  endfunction

  // --- Port A write: store as expected ---
  virtual function void write_<PORT_A>(<TX_A_TYPE> tr);
    <TX_A_TYPE> tr_copy;
    $cast(tr_copy, tr.clone());
    expected_q.push_back(tr_copy);
    `uvm_info(get_type_name(), $sformatf("[<PORT_A>] Stored expected: %s", tr.convert2string()), UVM_MEDIUM)
  endfunction

  // --- Port B write: compare against expected ---
  virtual function void write_<PORT_B>(<TX_B_TYPE> tr);
    <TX_A_TYPE> exp;

    if (expected_q.size() == 0) begin
      `uvm_error(get_type_name(), $sformatf("[<PORT_B>] Received actual but expected queue is empty: %s", tr.convert2string()))
      mismatch_count++;
      return;
    end

    exp = expected_q.pop_front();

    // <COMPARE_LOGIC>
    // Replace this block with design-specific comparison logic.
    // See references/env-architecture-patterns.md Section 8 for derivation patterns:
    //   Pattern A: Register read-back (APB/AHB/AXI slave)
    //   Pattern B: TX/RX loopback (UART/SPI/I2C)
    //   Pattern C: FIFO pass-through
    // Use the decision tree to select the appropriate pattern.
    if (exp.data == tr.data) begin
      match_count++;
      `uvm_info(get_type_name(), $sformatf("MATCH: %s", tr.convert2string()), UVM_MEDIUM)
    end else begin
      mismatch_count++;
      `uvm_error(get_type_name(), $sformatf("MISMATCH: exp=%s act=%s", exp.convert2string(), tr.convert2string()))
    end
  endfunction

  // --- check_phase: final verification ---
  virtual function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (expected_q.size() > 0)
      `uvm_error(get_type_name(), $sformatf("%0d unmatched expected transactions remain", expected_q.size()))
    `uvm_info(get_type_name(), $sformatf("Scoreboard Summary: %0d matches, %0d mismatches", match_count, mismatch_count), UVM_LOW)
  endfunction

endclass : <DESIGN>_scoreboard

`endif
