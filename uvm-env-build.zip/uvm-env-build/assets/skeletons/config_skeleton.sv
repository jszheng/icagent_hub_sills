`ifndef <PROTO>_CONFIG_SV
`define <PROTO>_CONFIG_SV

class <PROTO>_config extends uvm_object;

  `uvm_object_utils(<PROTO>_config)

  // --- Configuration fields ---
  uvm_active_passive_enum is_active = UVM_ACTIVE;

  <CONFIG_FIELDS>
  // Example:
  // bit has_coverage = 1;
  // bit has_checks   = 1;
  // int unsigned timeout_cycles = 1000;

  // --- Virtual interface handle ---
  virtual <PROTO>_interface vif;

  function new(string name = "<PROTO>_config");
    super.new(name);
  endfunction

endclass : <PROTO>_config

`endif
