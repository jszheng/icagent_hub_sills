`ifndef <PROTO>_TRANSACTION_SV
`define <PROTO>_TRANSACTION_SV

class <PROTO>_transaction extends uvm_sequence_item;

  // --- Fields ---
  <FIELD_DECLARATIONS>
  // Example:
  // rand bit [7:0]  data;
  // rand bit        rw;    // 0=read, 1=write
  //      bit [7:0]  rdata; // non-rand: driven by DUT

  // --- Constraints ---
  <CONSTRAINTS>
  // Example:
  // constraint c_data { data inside {[0:255]}; }

  `uvm_object_utils_begin(<PROTO>_transaction)
    <FIELD_MACROS>
    // Example:
    // `uvm_field_int(data,  UVM_ALL_ON)
    // `uvm_field_int(rw,    UVM_ALL_ON)
    // `uvm_field_int(rdata, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "<PROTO>_transaction");
    super.new(name);
  endfunction

  // --- do_copy ---
  virtual function void do_copy(uvm_object rhs);
    <PROTO>_transaction rhs_;
    if (!$cast(rhs_, rhs))
      `uvm_fatal("CAST", "Failed to cast rhs to <PROTO>_transaction")
    super.do_copy(rhs);
    <COPY_FIELDS>
    // Example:
    // this.data  = rhs_.data;
    // this.rw    = rhs_.rw;
    // this.rdata = rhs_.rdata;
  endfunction

  // --- do_compare ---
  virtual function bit do_compare(uvm_object rhs, uvm_comparer comparer);
    <PROTO>_transaction rhs_;
    if (!$cast(rhs_, rhs))
      return 0;
    return (super.do_compare(rhs, comparer) &&
            <COMPARE_FIELDS>);
    // Example:
    // (this.data  == rhs_.data) &&
    // (this.rw    == rhs_.rw)   &&
    // (this.rdata == rhs_.rdata));
  endfunction

  // --- convert2string ---
  virtual function string convert2string();
    return $sformatf("<CONVERT2STRING_FORMAT>");
    // Example:
    // return $sformatf("rw=%0b data=0x%0h rdata=0x%0h", rw, data, rdata);
  endfunction

  // --- do_print ---
  virtual function void do_print(uvm_printer printer);
    super.do_print(printer);
    <PRINT_FIELDS>
    // Example:
    // printer.print_field_int("data",  data,  8, UVM_HEX);
    // printer.print_field_int("rw",    rw,    1, UVM_BIN);
    // printer.print_field_int("rdata", rdata, 8, UVM_HEX);
  endfunction

endclass : <PROTO>_transaction

`endif
