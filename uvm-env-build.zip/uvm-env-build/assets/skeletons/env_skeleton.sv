`ifndef <DESIGN>_ENV_SV
`define <DESIGN>_ENV_SV

class <DESIGN>_env extends uvm_env;

  `uvm_component_utils(<DESIGN>_env)

  // --- Agents ---
  <AGENT_DECLARATIONS>
  // Example:
  // <PROTO_A>_agent  <PROTO_A>_agt;
  // <PROTO_B>_agent  <PROTO_B>_agt;

  // --- Scoreboard ---
  <DESIGN>_scoreboard scoreboard;

  // --- Coverage collector (optional) ---
  <COVERAGE_DECLARATION>
  // Example:
  // <DESIGN>_coverage coverage;

  // --- Virtual sequencer ---
  <DESIGN>_virtual_sequencer v_sqr;

  // --- Configs ---
  <CONFIG_DECLARATIONS>
  // Example:
  // <PROTO_A>_config  <PROTO_A>_cfg;
  // <PROTO_B>_config  <PROTO_B>_cfg;

  function new(string name = "<DESIGN>_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // --- Get configs from config_db ---
    <CONFIG_DB_GETS>
    // Example:
    // if (!uvm_config_db #(<PROTO_A>_config)::get(this, "", "<PROTO_A>_cfg", <PROTO_A>_cfg))
    //   `uvm_fatal("NOCFG", "<PROTO_A>_cfg not found")

    // --- Propagate configs to agents ---
    <CONFIG_DB_SETS>
    // Example:
    // uvm_config_db #(<PROTO_A>_config)::set(this, "<PROTO_A>_agt*", "cfg", <PROTO_A>_cfg);

    // --- Create agents ---
    <AGENT_CREATES>
    // Example:
    // <PROTO_A>_agt = <PROTO_A>_agent::type_id::create("<PROTO_A>_agt", this);

    // --- Create scoreboard ---
    scoreboard = <DESIGN>_scoreboard::type_id::create("scoreboard", this);

    // --- Create coverage ---
    <COVERAGE_CREATE>
    // Example:
    // coverage = <DESIGN>_coverage::type_id::create("coverage", this);

    // --- Create virtual sequencer ---
    v_sqr = <DESIGN>_virtual_sequencer::type_id::create("v_sqr", this);
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    // --- Connect agent analysis ports to scoreboard ---
    <SCOREBOARD_CONNECTS>
    // Example:
    // <PROTO_A>_agt.ap.connect(scoreboard.<PORT_A>_imp);
    // <PROTO_B>_agt.ap.connect(scoreboard.<PORT_B>_imp);

    // --- Connect agent analysis ports to coverage ---
    <COVERAGE_CONNECTS>
    // Example:
    // <PROTO_A>_agt.ap.connect(coverage.analysis_export);

    // --- Connect virtual sequencer to agent sequencers ---
    <VSEQ_CONNECTS>
    // Example:
    // v_sqr.<PROTO_A>_sqr = <PROTO_A>_agt.sqr;
    // v_sqr.<PROTO_B>_sqr = <PROTO_B>_agt.sqr;
  endfunction

endclass : <DESIGN>_env

`endif
