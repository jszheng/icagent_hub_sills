`ifndef <DESIGN>_BASE_TEST_SV
`define <DESIGN>_BASE_TEST_SV

class <DESIGN>_base_test extends uvm_test;

  `uvm_component_utils(<DESIGN>_base_test)

  <DESIGN>_env env;

  // --- Agent configs ---
  <CONFIG_DECLARATIONS>
  // Example:
  // <PROTO_A>_config  <PROTO_A>_cfg;
  // <PROTO_B>_config  <PROTO_B>_cfg;

  function new(string name = "<DESIGN>_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // --- Create configs ---
    <CONFIG_CREATES>
    // Example:
    // <PROTO_A>_cfg = <PROTO_A>_config::type_id::create("<PROTO_A>_cfg");
    // <PROTO_A>_cfg.is_active = UVM_ACTIVE;

    // --- Get virtual interfaces from config_db ---
    <VIF_GETS>
    // Example:
    // if (!uvm_config_db #(virtual <PROTO_A>_interface)::get(this, "", "<VIF_KEY_A>", <PROTO_A>_cfg.vif))
    //   `uvm_fatal("NOVIF", "<VIF_KEY_A> not found in config_db")

    // --- Set configs into config_db for env ---
    <CONFIG_SETS>
    // Example:
    // uvm_config_db #(<PROTO_A>_config)::set(this, "env", "<PROTO_A>_cfg", <PROTO_A>_cfg);

    // --- Create environment ---
    env = <DESIGN>_env::type_id::create("env", this);
  endfunction

  virtual function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    uvm_top.print_topology();
  endfunction

  virtual task run_phase(uvm_phase phase);
    super.run_phase(phase);
    // Base test does nothing in run_phase; subclasses override.
  endtask

  virtual function void report_phase(uvm_phase phase);
    uvm_report_server svr;
    super.report_phase(phase);
    svr = uvm_report_server::get_server();
    if (svr.get_severity_count(UVM_FATAL) + svr.get_severity_count(UVM_ERROR) > 0)
      `uvm_info(get_type_name(), "** TEST FAILED **", UVM_NONE)
    else
      `uvm_info(get_type_name(), "** TEST PASSED **", UVM_NONE)
  endfunction

endclass : <DESIGN>_base_test

`endif
