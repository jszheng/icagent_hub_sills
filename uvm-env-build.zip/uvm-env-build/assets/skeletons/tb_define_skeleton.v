`ifndef TB_DEFINE_V
`define TB_DEFINE_V

// ============================================================
// Centralized macro definitions for <DESIGN> verification
// All design-specific macros go here — do NOT duplicate in
// individual UVM files.
// ============================================================

// --- Data widths ---
`define DATA_WIDTH  <DATA_WIDTH>
`define ADDR_WIDTH  <ADDR_WIDTH>

// --- Clock ---
`define CLK_PERIOD  <CLK_PERIOD_NS>   // ns
`define CLK_FREQ    <CLK_FREQ_MHZ>    // MHz

// --- Register addresses ---
<REGISTER_DEFINES>
// Example:
// `define REG_CTRL    <CTRL_OFFSET>
// `define REG_STATUS  <STATUS_OFFSET>
// `define REG_DATA    <DATA_OFFSET>

// --- Protocol parameters ---
<PROTOCOL_DEFINES>
// Example:
// `define MAX_BURST_LEN  <MAX_BURST>
// `define TIMEOUT_CYCLES <TIMEOUT>

// --- Simulation control ---
`define SIM_TIMEOUT  <SIM_TIMEOUT_NS>  // ns, global simulation timeout

`endif
