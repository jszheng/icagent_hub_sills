`ifndef TESTBENCH_SV
`define TESTBENCH_SV

`include "tb_define.v"

module testbench;

  import uvm_pkg::*;
  `include "uvm_macros.svh"
  import <DESIGN>_pkg::*;

  // --- Clock and reset ---
  reg <CLK>;
  reg <RST>;

  // --- Clock generation ---
  parameter CLK_PERIOD = <CLK_PERIOD_NS>;  // ns

  initial begin
    <CLK> = 0;
    forever #(CLK_PERIOD/2) <CLK> = ~<CLK>;
  end

  // --- Reset generation ---
  initial begin
    <RST_ASSERT>
    // Example for active-low reset:
    // <RST> = 0;
    // #(CLK_PERIOD * 10);
    // <RST> = 1;
  end

  // --- Interface instantiation ---
  <INTERFACE_INSTANCES>
  // Example:
  // <PROTO_A>_interface <PROTO_A>_if(.clk(<CLK>), .rst(<RST>));
  // <PROTO_B>_interface <PROTO_B>_if(.clk(<CLK>), .rst(<RST>));

  // --- DUT instantiation ---
  <DUT_MODULE> <DUT_INSTANCE> (
    <DUT_PORT_MAP>
    // Example:
    // .clk    (<CLK>),
    // .rst_n  (<RST>),
    // .data_i (<PROTO_A>_if.data),
    // .data_o (<PROTO_B>_if.data)
  );

  // --- config_db set ---
  initial begin
    <CONFIG_DB_SETS>
    // Example:
    // uvm_config_db #(virtual <PROTO_A>_interface)::set(null, "*", "<VIF_KEY_A>", <PROTO_A>_if);
    // uvm_config_db #(virtual <PROTO_B>_interface)::set(null, "*", "<VIF_KEY_B>", <PROTO_B>_if);

    run_test();
  end

  // --- Waveform dump (conditional — enable with +define+DUMP_WAVES) ---
  `ifdef DUMP_WAVES
  initial begin
    $fsdbDumpfile("wave.fsdb");
    $fsdbDumpvars(0, testbench);
  end
  `endif

endmodule : testbench

`endif
