`ifndef <PROTO>_DRIVER_SV
`define <PROTO>_DRIVER_SV

class <PROTO>_driver extends uvm_driver #(<PROTO>_transaction);

  `uvm_component_utils(<PROTO>_driver)

  virtual <PROTO>_interface vif;
  <PROTO>_config cfg;

  function new(string name = "<PROTO>_driver", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  // --- build_phase: get virtual interface from config_db ---
  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db #(<PROTO>_config)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", {"Config not set for ", get_full_name()})
    vif = cfg.vif;
  endfunction

  // --- connect_phase ---
  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
  endfunction

  // --- run_phase: main drive loop ---
  virtual task run_phase(uvm_phase phase);
    <PROTO>_transaction tr;

    // Wait for reset de-assertion
    <WAIT_RESET>
    // Example:
    // @(posedge vif.<RST>);
    // @(posedge vif.<CLK>);

    forever begin
      seq_item_port.get_next_item(tr);

      // --- Drive transaction onto interface ---
      <DRIVE_LOGIC>
      // Example:
      // @(posedge vif.<CLK>);
      // vif.data <= tr.data;
      // vif.valid <= 1'b1;
      // @(posedge vif.<CLK>);
      // vif.valid <= 1'b0;

      seq_item_port.item_done();
    end
  endtask

endclass : <PROTO>_driver

`endif
