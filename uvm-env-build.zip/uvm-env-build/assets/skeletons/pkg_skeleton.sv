`ifndef <DESIGN>_PKG_SV
`define <DESIGN>_PKG_SV

package <DESIGN>_pkg;

  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // ============================================================
  // Include order matters: dependencies must come before dependents.
  // Order: transaction -> config -> driver -> monitor -> agent ->
  //        scoreboard -> coverage -> virtual_sequencer ->
  //        env -> sequences -> base_test -> tests
  // ============================================================

  // --- 1. Transactions (no dependencies) ---
  <TRANSACTION_INCLUDES>
  // `include "<PROTO_A>_transaction.sv"
  // `include "<PROTO_B>_transaction.sv"

  // --- 2. Configs (depend on transactions) ---
  <CONFIG_INCLUDES>
  // `include "<PROTO_A>_config.sv"
  // `include "<PROTO_B>_config.sv"

  // --- 3. Drivers (depend on transaction + config) ---
  <DRIVER_INCLUDES>
  // `include "<PROTO_A>_driver.sv"
  // `include "<PROTO_B>_driver.sv"

  // --- 4. Monitors (depend on transaction + config) ---
  <MONITOR_INCLUDES>
  // `include "<PROTO_A>_monit.sv"
  // `include "<PROTO_B>_monit.sv"

  // --- 5. Agents (depend on driver + monitor + config) ---
  <AGENT_INCLUDES>
  // `include "<PROTO_A>_agent.sv"
  // `include "<PROTO_B>_agent.sv"

  // --- 6. Scoreboard (depends on transactions) ---
  <SCOREBOARD_INCLUDE>
  // `include "<DESIGN>_scoreboard.sv"

  // --- 7. Coverage (depends on transactions) ---
  <COVERAGE_INCLUDE>
  // `include "<DESIGN>_coverage.sv"

  // --- 8. Virtual sequencer (depends on agents) ---
  <VSEQUENCER_INCLUDE>
  // `include "<DESIGN>_virtual_sequencer.sv"

  // --- 9. Environment (depends on all above) ---
  <ENV_INCLUDE>
  // `include "<DESIGN>_env.sv"

  // --- 10. Sequences (depend on transaction + virtual sequencer) ---
  <SEQUENCE_INCLUDES>
  // `include "<PROTO_A>_sequences.sv"
  // `include "<PROTO_B>_sequences.sv"
  // `include "<DESIGN>_virtual_sequences.sv"

  // --- 11. Base test (depends on env + sequences) ---
  <BASE_TEST_INCLUDE>
  // `include "<DESIGN>_base_test.sv"

  // --- 12. Tests (depend on base_test + sequences) ---
  <TEST_INCLUDES>
  // `include "<DESIGN>_tests.sv"

endpackage : <DESIGN>_pkg

`endif
