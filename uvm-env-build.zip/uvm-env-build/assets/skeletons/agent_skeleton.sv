`ifndef <PROTO>_AGENT_SV
`define <PROTO>_AGENT_SV

class <PROTO>_agent extends uvm_agent;

  `uvm_component_utils(<PROTO>_agent)

  <PROTO>_config    cfg;
  <PROTO>_driver    drv;
  <PROTO>_monitor   mon;
  uvm_sequencer #(<PROTO>_transaction) sqr;

  uvm_analysis_port #(<PROTO>_transaction) ap;

  function new(string name = "<PROTO>_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    if (!uvm_config_db #(<PROTO>_config)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", {"Config not set for ", get_full_name()})

    // Monitor is always instantiated
    mon = <PROTO>_monitor::type_id::create("mon", this);

    // Driver and sequencer only in ACTIVE mode
    if (cfg.is_active == UVM_ACTIVE) begin
      drv = <PROTO>_driver::type_id::create("drv", this);
      sqr = uvm_sequencer #(<PROTO>_transaction)::type_id::create("sqr", this);
    end
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    // Connect analysis port
    ap = mon.ap;

    // Connect driver to sequencer in ACTIVE mode
    if (cfg.is_active == UVM_ACTIVE) begin
      drv.seq_item_port.connect(sqr.seq_item_export);
    end
  endfunction

endclass : <PROTO>_agent

`endif
