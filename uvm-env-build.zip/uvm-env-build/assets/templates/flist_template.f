// ============================================================
// File list for <DESIGN> UVM verification environment
// Compile order: defines -> interfaces -> package -> testbench
// ============================================================

// --- Timescale ---
+timescale=1ns/1ps

// --- Include paths ---
+incdir+<UVM_TB_DIR>
+incdir+<RTL_DIR>

// --- Defines ---
<UVM_TB_DIR>/tb_define.v

// --- RTL source files ---
<RTL_FILES>
// Example:
// <RTL_DIR>/<MODULE_A>.sv
// <RTL_DIR>/<MODULE_B>.sv
// <RTL_DIR>/<TOP_MODULE>.sv

// --- SV Interfaces ---
<INTERFACE_FILES>
// Example:
// <UVM_TB_DIR>/<PROTO_A>_interface.sv
// <UVM_TB_DIR>/<PROTO_B>_interface.sv

// --- Assertion bind (if applicable) ---
<BIND_FILE>
// Example:
// <UVM_TB_DIR>/<DESIGN>_bind.sv

// --- UVM Package (includes all UVM classes) ---
<UVM_TB_DIR>/<DESIGN>_pkg.sv

// --- Testbench top ---
<UVM_TB_DIR>/testbench.sv
