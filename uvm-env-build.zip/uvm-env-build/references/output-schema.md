# Stage 2 Output Schema

## Component Checklist Result

Stage 2 prints a structured checklist summary. Expected format:

| Check | Status | Detail |
|-------|--------|--------|
| Agent topology complete | PASS/FAIL | "N active agents, M passive agents" |
| Factory registration | PASS/FAIL | "All N classes registered" or "Missing: class_name" |
| Config_db consistency | PASS/FAIL | "All set/get pairs matched" or "Mismatch: key_name" |
| Package include order | PASS/FAIL | "Dependency order satisfied" or "Out of order: file_a before file_b" |
| Macro centralization | PASS/FAIL | "All macros in tb_define.v" or "Duplicate: MACRO_NAME in file" |
| Flist completeness | PASS/FAIL | "All N files listed" or "Missing: file_name" |

## Generated Files

| File | Purpose | Validation |
|------|---------|------------|
| `uvm_tb/tb_define.v` | Centralized macros | No duplicate `define` |
| `uvm_tb/*_interface.sv` | SV interfaces | One per protocol |
| `uvm_tb/*_transaction.sv` | UVM transactions | Has `uvm_object_utils` |
| `uvm_tb/*_config.sv` | Config objects | Has `uvm_object_utils` |
| `uvm_tb/*_driver.sv` | Drivers | Has `uvm_component_utils` |
| `uvm_tb/*_monit.sv` | Monitors | Has `uvm_component_utils` |
| `uvm_tb/*_agent.sv` | Agent wrappers | Has `uvm_component_utils` |
| `uvm_tb/*_scoreboard.sv` | Scoreboard | Has TLM ports connected |
| `uvm_tb/*_virtual_sequencer.sv` | Virtual sequencer | Has sub-sequencer handles |
| `uvm_tb/*_env.sv` | Environment | Instantiates all components |
| `uvm_tb/*_pkg.sv` | Package | Includes all classes in order |
| `uvm_tb/*_base_test.sv` | Base test | Has `uvm_component_utils` |
| `uvm_tb/testbench.sv` | Testbench top | DUT + interface + config_db set |
| `sim/flist` | File list | All files in compile order |
