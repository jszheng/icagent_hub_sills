---
name: chip-design-rtl
description: Use when planning or writing synthesizable RTL, defining module boundaries and interfaces, running lint or CDC/RDC checks, checking pre-synthesis quality, or preparing an RTL handoff package for downstream verification and synthesis. Trigger even if the user only mentions SystemVerilog coding, lint cleanup, CDC issues, module planning, or RTL signoff.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-rtl: RTL Design and Signoff

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. **Lint**: Verilator and Slang are the recommended default lint tools — no license required, fast iteration
2. **Cross-check**: sv2v + Icarus Verilog provides a second open-source lint/elaboration check
3. **CDC/RDC**: no mature open-source alternative exists — commercial tools (SpyGlass, JasperGold) are required for production CDC/RDC analysis; this is clearly marked
4. Detection order: open-source tool commands are checked before commercial ones
5. When both open-source and commercial tools are detected, open-source is presented as the recommended default

---

## Use Mode

This skill supports two modes:

**Full RTL design flow:**
- Follow the 6-stage orchestrated flow from module planning through RTL signoff
- Enforce coding standards and quality gates at each stage
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules when answering targeted questions
- Reference QoR metrics or common issues without running the full flow

**Critical constraints:**
- Do not advance past lint_check with lint errors > 0
- Do not advance past cdc_rdc_analysis with unwaived CDC violations
- Structural timing issues (WNS < −0.5 ns persistent) require module planning revisit, not just RTL patching

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| lint | `verilator`, `slang`, `spyglass`, `hal` | Required (at least one; open-source recommended) |
| cdc | `spyglass`, `jg` | Optional (recommended for multi-clock designs; **no open-source alternative**) |

### Tool Execution

Open-source tools (recommended for lint):

| Tool | Lint command | CDC command | Type |
|------|-------------|-------------|------|
| Verilator | `verilator --lint-only -Wall -Wno-DECLFILENAME <files>` | — | Open-source (recommended) |
| Slang | `slang --lint-only <files>` | — | Open-source |
| sv2v + Icarus | `sv2v --top <mod> <files> > out.v && iverilog -Wall out.v` | — | Open-source (cross-check) |

Commercial tools (optional):

| Tool | Lint command | CDC command | Type |
|------|-------------|-------------|------|
| SpyGlass | `spyglass -batch -goal lint/lint_rtl` | `spyglass -batch -goal cdc/cdc_setup` | Commercial — Synopsys |
| HAL | `hal -f <filelist>` | — | Commercial — Cadence |
| JasperGold CDC | — | `jg` | Commercial — Cadence |

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `lint` capability is configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which verilator`, `which slang` first (open-source), then `which spyglass`, `which hal` (commercial)
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. Required capability with no tool detected → inform user and stop; suggest installing Verilator (`apt install verilator`) or Slang as open-source option
7. Optional `cdc` capability with no tool → inform user that no open-source CDC tool exists; continue (CDC check will be skipped unless commercial tool available)

---

## Stage Workflow

### Stage 1: module_planning

Define module boundaries, interfaces, and hierarchy before writing RTL.

**Domain Rules:**
1. Top-down decomposition: start with top-level module, recurse to leaf cells
2. Each module: single clear responsibility (single responsibility principle)
3. Define all port lists before coding (direction, width, type)
4. Identify all clock domains per module; mark CDC crossings explicitly
5. Identify all reset domains; mark synchronous vs asynchronous
6. Parameterise widths and depths wherever possible
7. No logic in top-level integration modules — wiring only
8. Separate datapath and control into distinct sub-modules

**Module Descriptor Template (per module):**
```
module_name:    <name>
purpose:        <one sentence>
clock_domains:  [clk_sys, clk_mem, ...]
reset_domains:  [rst_n_sys, ...]
cdc_crossings:  [clk_sys→clk_mem: <signal>, ...]
ports:
  inputs:   [port_name: width, ...]
  outputs:  [port_name: width, ...]
sub_modules:    [<sub1>, <sub2>, ...]
```

**QoR Metrics:**
- All CDC crossings explicitly identified
- No module with dual responsibility (separation check by hand)
- Port list complete before rtl_coding begins

**Output Required:**
- Module hierarchy tree
- Module descriptor per module
- Interface/port list document

---

### Stage 2: rtl_coding

Implement all modules following synthesis-safe SystemVerilog conventions.

**Domain Rules — General:**
1. Always use `logic` type (not wire/reg distinction)
2. All ports: explicitly typed and directioned
3. `default_nettype none` at top of every file
4. No latches: all `always_comb` blocks must have complete case and assignment coverage
5. No blocking assignments (`=`) in `always_ff` blocks
6. No non-blocking assignments (`<=`) in `always_comb` blocks
7. One always block per register or coherent register group
8. Reset all registers explicitly; synchronous reset preferred for ASIC

**Domain Rules — Naming Conventions:**
- Clocks:        `clk_[domain]`
- Resets:        `rst_n_[domain]` (active-low) or `rst_[domain]`
- Active-low:    `signal_n` suffix
- Registered:    `signal_q` suffix
- Next-state:    `signal_d` suffix
- Parameters:    `UPPER_SNAKE_CASE`
- Modules/Signals: `lower_snake_case`

**Domain Rules — Synthesis Safety:**
1. No delays (`#`) in RTL — simulation only
2. No `initial` blocks in ASIC RTL
3. Use `unique case` with explicit don't-cares instead of `casez`/`casex`
4. Flag any net with fanout > 32 for buffering intent review
5. No combinational loops — will cause synthesis errors
6. Pipeline registers: clearly marked with `_q` suffix at each stage

**Domain Rules — CDC:**
1. Two-FF synchroniser for every single-bit CDC crossing
2. Async FIFO for multi-bit CDC data paths
3. Gray-coded pointers for async FIFO crossing
4. Never sample asynchronous data directly in synchronous logic

**Common Issues & Fixes:**

| Issue | Fix |
|-------|-----|
| Latch inferred in always_comb | Ensure all outputs assigned in every branch of case/if; use default assignments at top of block |
| Implicit wire warnings from Verilator | Add `` `default_nettype none `` at top of each file |
| Multi-bit CDC functional errors | Add Gray encoding to bus before crossing; 2-FF synchroniser alone is insufficient for multi-bit |
| Blocking assignment in always_ff | Replace `=` with `<=` throughout; check all nested if/case paths |

**QoR Metrics:**
- Compile: 0 errors
- No latches in design (confirmed by lint)
- All named signals follow naming convention

**Output Required:**
- RTL source files (`.sv`) per module
- SVA assertion files per module
- Inline comments on all non-obvious logic

---

### Stage 3: lint_check

Run lint analysis on all RTL files and resolve issues before proceeding.

**Domain Rules:**
1. ERROR level (must fix): latches, incomplete sensitivity lists, undriven outputs, multiply-driven signals, X-propagation sources
2. WARNING level (review): unused ports, truncated assignments, bit-width mismatches, constant conditions
3. All waivers: must include signal name, rule ID, justification, approver
4. No ERROR-level waivers without architect approval
5. All waivers logged in `lint_waivers.csv`

**Recommended Flags (open-source — use these by default):**
```bash
# Verilator lint (recommended first-pass)
verilator --lint-only -Wall -Wno-DECLFILENAME <files>
# -Wno-DECLFILENAME: suppresses false positive where file name ≠ module name

# Slang strict driver check (recommended second-pass, catches what Verilator misses)
slang --allow-use-before-declare --strict-driver-checking <files>
# --strict-driver-checking catches multi-driven signals that Verilator misses

# sv2v + Icarus cross-check (recommended third-pass)
sv2v --top <module> <files> > out.v && iverilog -Wall out.v
# catches SV elaboration issues in tools that don't support SV directly
```

**Best practice**: run Verilator first, then Slang, then sv2v+Icarus — three open-source passes catch the majority of lint issues without any commercial license.

**SpyGlass vs JasperGold CDC (commercial only — no open-source alternative for CDC):**
- SpyGlass CDC: more false positives on Gray-encoded buses, but broader structural coverage → use first
- JasperGold CDC: fewer false positives, may miss some structural patterns → use to confirm waivers

**QoR Metrics:**
- ERROR count: must be 0 before proceeding
- WARNING count: all reviewed; waived with documented justification
- All RTL files checked (not just top-level)

**Output Required:**
- Lint report (per file, per rule)
- Waiver file (`lint_waivers.csv`)
- Clean lint summary

---

### Stage 4: cdc_rdc_analysis

Verify all clock and reset domain crossings are correctly implemented.

**CDC Rules:**
1. Every CDC crossing: approved synchroniser primitive
2. Single-bit control: 2-FF synchroniser minimum
3. Multi-bit data: async FIFO or handshake protocol
4. Pulse crossings: pulse stretcher + synchroniser
5. Zero CDC violations (unwaived) before proceeding

**RDC Rules:**
1. All reset domains explicitly defined in constraints
2. Reset de-assertion: synchronous to receiving clock domain
3. No combinational logic between reset sources
4. Retention registers: correct UPF annotation
5. Async reset flops require explicit reset-removal SDC constraints (`set_max_delay -datapath_only` from reset de-assertion to first flop clock edge)

See [references/rtl-rules.md](references/rtl-rules.md) for common CDC/RDC issues and fixes.

**QoR Metrics:**
- CDC violations (unwaived): 0
- RDC violations (unwaived): 0
- All clock domains verified in tool constraints

**Output Required:**
- CDC/RDC report
- Synchroniser instance list
- Waiver file

---

### Stage 5: rtl_signoff

Final review and package of RTL for downstream handoff.

**Sign-off Checklist:**
- [ ] All modules from planning implemented
- [ ] Lint: 0 errors, all warnings reviewed and waived
- [ ] CDC: 0 unwaived violations
- [ ] RDC: 0 unwaived violations
- [ ] All ports connected in integration
- [ ] SVA assertions in place for key properties
- [ ] Code review completed
- [ ] File list uses relative paths (absolute paths break downstream flows)
- [ ] Compile order documented

**Output Required:**
- RTL file package (all `.sv` files)
- File list (`filelist.f`) with relative paths
- Compile order document
- Assertion library (`.sva` files)
- RTL sign-off record

---

## Sign-off Hard Gates

RTL signoff requires ALL of these conditions:

- `lint_errors == 0` (zero ERROR-level lint issues)
- `cdc_violations_unwaived == 0` (all CDC crossings verified)
- `rdc_violations_unwaived == 0` (all reset crossings verified)
- `all_modules_implemented == true` (no placeholder modules)

**Critical note:**
Do not accept ERROR-level lint waivers without architect sign-off. Do not advance to synthesis handoff with any unwaived CDC/RDC violations — these cause functional failures that are extremely difficult to debug post-tape-out.

---

See [references/rtl-rules.md](references/rtl-rules.md) for tool-specific flags (Verilator, Slang, sv2v+Icarus).

---

## Loop-Back Rules

- `lint_check` FAIL (errors > 0) → retry `rtl_coding` (max 5×)
- `cdc_rdc_analysis` FAIL (unwaived violations) → retry `rtl_coding` (max 3×)
- `rtl_signoff` FAIL (missing modules) → return to `module_planning` (max 1×)
- `rtl_signoff` FAIL (quality issues) → retry `rtl_coding` (max 2×)

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and known tool quirks. Use this to inform stage decisions — for example, known Verilator flag combinations or CDC false-positive patterns for specific bus encodings.

During a full RTL design flow, it is useful to record key outcomes such as lint/CDC/synthesis QoR, loop-back counts, and issues encountered at each stage. If the project uses a persistent knowledge system, these can be written out for reuse across designs. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/rtl-rules.md](references/rtl-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/rtl-flow.md](references/rtl-flow.md) — broader flow narrative
- [../chip-design-architecture/scripts/qor_trends.py](../chip-design-architecture/scripts/qor_trends.py) — cross-run QoR trend utility (shared)
