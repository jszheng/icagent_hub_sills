# RTL Flow Reference

This standalone flow is derived from the original RTL design plugin and its matching flow document.

## Flow Overview

Input:
- architecture or microarchitecture definition
- interface requirements
- clock/reset strategy

Output:
- synthesizable RTL
- lint and CDC/RDC clean status
- synthesis sanity results
- RTL handoff package

## Core idea

The flow is intentionally staged so structural decisions happen before code volume grows. Lint, CDC/RDC, and synthesis checks act as gates that keep low-quality RTL from flowing downstream.
