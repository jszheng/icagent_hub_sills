# RTL Rules Reference

## Stage Sequence

`module_planning -> rtl_coding -> lint_check -> cdc_rdc_analysis -> synth_check -> rtl_signoff`

## Loop-back Rules

- lint errors -> `rtl_coding` (max 5x)
- unwaived CDC/RDC violations -> `rtl_coding` (max 3x)
- synthesis WNS below threshold -> `rtl_coding` (max 2x)
- synthesis area too far above estimate -> `module_planning` (max 1x)
- signoff reveals missing structural content -> `module_planning` (max 1x)
- signoff reveals RTL quality issues -> `rtl_coding` (max 2x)

## High-level Rules

### module_planning
- define modules, interfaces, hierarchy, clock domains, and reset domains first
- make interface intent explicit before implementation

### rtl_coding
- use synthesizable SystemVerilog rules only
- maintain naming, reset, and interface consistency
- keep code ready for lint and synthesis from the start

### lint_check
- treat lint as a hard gate for real errors
- separate style issues from functional hazards, but do not ignore structural problems

### cdc_rdc_analysis
- unwaived CDC/RDC violations block progress
- document clock and reset crossings intentionally rather than leaving them implicit

### synth_check
- use synthesis sanity checks to catch structural QoR problems early
- severe timing or area misses can indicate a planning problem, not just a coding problem

### rtl_signoff
- sign off only when the design is complete, consistent, and ready for verification/synthesis handoff

## Best fit for this reference

This file should carry:
- coding and naming rules
- lint / CDC / RDC gating rules
- synthesis precheck thresholds
- common RTL failure patterns
- tool-specific guidance and useful flags

## Common CDC/RDC Issues and Fixes

| Issue | Fix |
|-------|-----|
| Multi-bit CDC violations despite FIFO | Verify Gray encoding is applied to pointer before domain crossing; check FIFO full/empty flags are also synchronized |
| Spurious CDC violations on Gray-encoded buses | Waive in SpyGlass with documented Gray-encoding justification; verify with JasperGold CDC |
| Reset-removal STA violations | Add `set_max_delay -datapath_only` constraint from reset pin to first synchronous flop |

## Tool-Specific Flags (Open-Source)

**Verilator lint (recommended):**
```bash
verilator --lint-only -Wall -Wno-DECLFILENAME <files>
```
- `-Wall` catches implicit wire declarations, missing sensitivity list entries
- `-Wno-DECLFILENAME` suppresses false positive where filename ≠ module name; keep all other `-Wall` checks

**Slang strict mode:**
```bash
slang --allow-use-before-declare --strict-driver-checking <files>
```
- `--strict-driver-checking` catches multi-driven signals that Verilator misses

**sv2v + Icarus cross-check:**
```bash
sv2v --top <module> <files> > out.v && iverilog -Wall out.v
```
- Useful for catching SV elaboration issues in tools without full SV support
