# Verification Rules Reference

## Stage Sequence

`tb_architecture -> test_planning -> uvm_tb_build -> directed_tests -> constrained_random -> coverage_analysis -> formal_assist -> regression_signoff`

## Loop-back Rules

- TB build compile failures -> retry TB build work (max 3x)
- directed testing finds DUT bug -> stop and hand back to RTL
- functional coverage below closure target -> `constrained_random` (max 5x)
- code line coverage below threshold -> `directed_tests` (max 3x)
- regression failures -> `constrained_random` or targeted debug (max 3x)

## High-level Rules

### tb_architecture
- define agents, monitors, scoreboards, checkers, and coverage intent first

### test_planning
- map features to tests, scenarios, and coverage points
- decide what is baseline, what is stress, and what is closure work

### uvm_tb_build
- make the environment compile and connect cleanly before scaling stimulus

### directed_tests
- prove core behavior deterministically
- use these tests to isolate bugs and create a stable baseline

### constrained_random
- use randomization to close meaningful gaps, not to mask unstable behavior

### coverage_analysis
- analyze functional and code coverage together
- classify gaps as real, unreachable, or blocked by bugs/spec issues

### formal_assist
- use formal selectively to resolve stubborn structural coverage gaps or prove unreachable logic

### regression_signoff
- sign off only when regression quality and coverage closure both meet the plan

## Best fit for this reference

This file should carry:
- UVM architecture guidance
- V-plan and coverage rules
- bug triage and closure policy
- simulator / coverage tool notes
- common UVM failure patterns

---

## Waveform Dump Rules

**Open-source default — VCD format + GTKWave:**
- Use `$dumpfile("waves.vcd")` / `$dumpvars(0, top)` — standard IEEE 1364, works with all simulators
- View with GTKWave: `gtkwave waves.vcd`
- Verilator: `--trace` flag enables VCD output; `--trace-fst` for FST format (smaller, faster, also GTKWave-compatible)

**Commercial option — FSDB format + Verdi (only when Verdi explicitly selected):**
- Use `$fsdbDumpfile` / `$fsdbDumpvars` — requires Verdi PLI
- VCS compile must include Verdi PLI: `-P $(VERDI_HOME)/share/PLI/VCS/LINUX64/novas.tab $(VERDI_HOME)/share/PLI/VCS/LINUX64/pli.a`
- Xcelium: use `-access +rwc -input dump.tcl` with `database -open waves.fsdb -shm; probe -create -all -depth all -fsdb`

---

## Common UVM TB Build Issues & Fixes

| Issue | Fix |
|-------|-----|
| UVM factory override failures → `uvm_fatal` at sim start | Register overrides in `build_phase` before `super.build_phase()`. Type name strings are case-sensitive. |
| Scoreboard sees no transactions | Check monitor writes to analysis port; verify scoreboard subscribes correctly |
| Driver not driving | Check sequencer-driver connection; verify sequences are started |
| Verilator UVM phasing limitation | `uvm_objection` timeout-based drain time not supported — use explicit event-based drain instead |

---

## Common Constrained-Random Issues & Fixes

| Issue | Fix |
|-------|-----|
| Functional coverage closure stalls | Analyze uncovered bins — if they require specific ordering of >3 events, write a directed test targeting that sequence instead of adding more random seeds |
| Random tests hit same coverage repeatedly | Add bias constraints toward uncovered bins; use coverage-driven test selection (CDTS) |
| Assertion-based coverage not integrated | Wire SVA cover points to coverage database to avoid double-counting them as functional coverage |

---

## Common Formal Assist Issues & Fixes

| Issue | Fix |
|-------|-----|
| Vacuous proofs | Over-constrained assumptions invalidate the proof — verify with vacuity check; disable assumptions one by one to confirm property still fails |
| Formal cannot reach deep pipeline states | Increase BMC bound to pipeline depth + margin; consider abstraction or helper assertions |

---

## Common Regression Signoff Issues & Fixes

| Issue | Fix |
|-------|-----|
| Regression pass rate drops after coverage closure | New tests may expose latent bugs; classify and route back to RTL fix |
| Regression fail rate > 0% at signoff gate | Loop back to constrained-random to stabilize; do not waive regression failures without root-cause analysis |

---

## Tool-Specific Flags

### Open-Source (recommended)

**Verilator (recommended):**
```bash
verilator --coverage --coverage-line --coverage-toggle -Wno-UNOPTFLAT
```
- Enables line, toggle, and user coverage
- `-Wno-UNOPTFLAT` suppresses expected warnings from UVM dynamic connections
- Coverage export: `verilator_coverage --write-info <info> <dat>` then `genhtml` for HTML report
- Waveform: add `--trace` for VCD or `--trace-fst` for FST (smaller files, faster writes)

**Verilator UVM limitations (be aware):**
- `uvm_objection` timeout-based drain time not supported — use explicit event-based drain instead
- Some SystemVerilog class features may require `--timing` flag (Verilator 5.x+)

**cocotb + Verilator (open-source Python-based verification):**
- cocotb does not natively export Verilator coverage to UCDB format
- Use `verilator_coverage --write-info` to convert coverage data
- cocotb + Icarus also supported: `MODULE=test_module cocotb-run iverilog ...`

**Icarus Verilog:**
```bash
iverilog -g2012 -f filelist.f -o sim && vvp sim
```
- No built-in coverage — use cocotb or manual coverage collection
- VCD waveform output via `$dumpfile` / `$dumpvars`

### Commercial (optional)

**VCS (commercial — Synopsys):**
```bash
vcs -sverilog +vcs+lic+wait +UVM_NO_RELNOTES -cm line+cond+fsm+tgl
```
- `+vcs+lic+wait` prevents license timeout in batch regressions
- `-cm` flags enable all coverage types (line, condition, FSM, toggle)

**Xcelium (commercial — Cadence):**
```bash
xrun -uvm -coverage all -covworkdir <dir>
```
- `-covworkdir` must be consistent across runs for merge to succeed
