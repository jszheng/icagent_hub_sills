# Verification Flow Reference

## Flow Overview

Input:
- RTL and interface understanding
- verification goals and feature list

Output:
- verification plan
- stable TB architecture
- directed and random tests
- coverage analysis
- regression signoff result

## Core idea

This flow treats planning, baseline correctness, random closure, and signoff as separate concerns. It is designed to prevent teams from confusing high activity with high verification confidence.
