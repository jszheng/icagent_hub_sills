---
name: chip-design-verification
description: Use when planning or executing functional verification for a chip block or subsystem, defining a V-plan, building a UVM environment, writing directed or constrained-random tests, closing coverage, or deciding verification signoff. Trigger even if the user only mentions testbench architecture, regressions, coverage gaps, formal assist, or verification closure.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-verification: UVM Functional Verification

## Open-Source First Philosophy

This skill follows an **open-source first** strategy:

1. **Simulation**: Verilator is the recommended default simulator — fastest compile-run cycle, built-in coverage, no license required. Icarus Verilog is a secondary open-source option for quick functional checks
2. **cocotb**: Python-based testbench framework via cocotb is a fully open-source alternative to commercial UVM environments when used with Verilator or Icarus
3. **Waveform**: VCD is the default open-source waveform format, viewable with GTKWave. FSDB (Synopsys proprietary) is only used when Verdi is explicitly selected
4. **Coverage**: Verilator provides line, toggle, and user-defined coverage natively. Full FSM and condition coverage require commercial tools — this is clearly marked
5. **UVM support**: Verilator has limited UVM phasing support (no `uvm_objection` timeout-based drain) — this limitation is documented, not hidden
6. Detection order: open-source tool commands are checked before commercial ones

---

## Use Mode

This skill supports two modes:

**Full verification campaign:**
- Follow the complete 8-stage orchestrated flow from TB architecture through regression signoff
- Track coverage, bugs, and verification completeness across stages
- Loop back on failures according to the rules below

**Single-stage consultation:**
- Use individual stage rules when answering targeted questions
- Reference specific QoR metrics or common issues without running the full flow

**Critical constraint:**
- Do not proceed to coverage closure or regression signoff while P0 or P1 bugs remain open
- Suspend the flow when DUT bugs are found during directed testing — wait for RTL fix confirmation before continuing

---

## Required Capabilities

| Capability | Candidates (detected via `which`) | Required/Optional |
|------------|----------------------------------|-------------------|
| simulation | `verilator`, `iverilog`, `vcs`, `xrun`, `vsim` | Required (at least one; open-source recommended) |
| waveform | `gtkwave`, `verdi`, `simvision`, `indago` | Optional (GTKWave recommended) |

### Tool Execution

Open-source simulators (recommended):

| Tool | Compile | Run | Coverage flags | Type |
|------|---------|-----|----------------|------|
| Verilator | `verilator --cc --exe --build -f filelist.f` | `./obj_dir/V<top>` | `--coverage` | Open-source (recommended) |
| Icarus | `iverilog -g2012 -f filelist.f -o sim` | `vvp sim` | — | Open-source |

Commercial simulators (optional):

| Tool | Compile | Run | Coverage flags | Type |
|------|---------|-----|----------------|------|
| VCS | `vcs -sverilog -full64 +vcs+lic+wait -f filelist.f` | `./simv +UVM_TESTNAME=<test>` | `-cm line+cond+fsm+tgl` | Commercial — Synopsys |
| Xcelium | `xrun -sv -f filelist.f -uvm` | (compile+run integrated) | `-coverage all` | Commercial — Cadence |
| QuestaSim | `vlog -sv -f filelist.f` then `vsim -c <top>` | `run -all` | `-coverage` | Commercial — Siemens |

See [references/verification-rules.md](references/verification-rules.md) for waveform dump configuration (VCD/GTKWave for open-source, FSDB/Verdi for commercial).

### Tool Selection Strategy

1. Read `tool-config.json` if it exists; check if `simulation` capability is configured
2. **If configured → must use that tool, not any other tool. No substitution allowed.**
3. If not configured → run `which verilator`, `which iverilog` first (open-source), then `which vcs`, `which xrun`, `which vsim` (commercial)
4. List all detected tools to user, **open-source candidates shown first with `[recommended]` tag**; ask user to confirm which to use
5. Write confirmed selection to `tool-config.json` (append if file exists)
6. Required capability with no tool detected → inform user and stop; suggest installing Verilator (`apt install verilator`) or Icarus Verilog (`apt install iverilog`) as open-source option

---

## Stage Workflow

### Stage 1: tb_architecture

Define the UVM testbench structure before writing code.

**Domain Rules:**
1. Follow UVM 1.2 standard (IEEE 1800.2)
2. One UVM agent per DUT interface — each agent contains driver, monitor, and sequencer
3. Active agents drive stimulus; passive agents monitor only
4. Scoreboard checks DUT output against reference model output
5. Reference model: functional model of DUT in SystemVerilog or C++ via DPI
6. Coverage collector: separate component from scoreboard
7. Virtual sequencer coordinates multi-agent stimulus scenarios
8. All TB parameters via `uvm_config_db` — no hardcoded values in components

**UVM Hierarchy Template:**
```
uvm_test
  └─ uvm_env
       ├─ agent_A (active)   driver + monitor + sequencer
       ├─ agent_B (passive)  monitor only
       ├─ scoreboard
       ├─ coverage_collector
       └─ virtual_sequencer
```

**QoR Metrics:**
- All DUT interfaces covered by an agent
- Reference model adequate to check all DUT outputs
- TB compile: 0 errors

**Output Required:**
- TB architecture diagram
- UVM component list and hierarchy
- Interface-to-agent mapping table

---

### Stage 2: test_planning

Produce a comprehensive verification plan (V-plan) mapping every spec requirement to tests or properties.

**Domain Rules:**
1. Every functional requirement → at least one directed test
2. Every interface → protocol compliance test
3. Error/exception cases: explicit directed tests (not left to random)
4. Corner cases: boundary values, max/min, overflow, underflow
5. Concurrency: multi-threaded stimulus for pipeline stress
6. Back-pressure: tests under flow control conditions
7. Reset: in-operation resets, reset during active transaction
8. Define covergroups before writing tests

**V-Plan Entry Template (per feature):**
```
feature_id:   F001
description:  AXI write burst handling
tests:        [direct_single_write, burst_len_256, narrow_transfer]
assertions:   [axi_valid_stable, axi_handshake_check]
covergroups:  [burst_len_cg, burst_type_cg]
priority:     P0
```

**QoR Metrics:**
- Requirement coverage: 100% of spec features mapped
- P0 tests: must pass before random testing begins
- Estimated test count: reasonable vs schedule

**Output Required:**
- V-plan document
- Covergroup definitions
- Assertion list with expected behavior

---

### Stage 3: uvm_tb_build

Build all UVM testbench components following UVM methodology.

**Domain Rules — Sequences:**
1. Base sequence: minimum valid transaction
2. Extended sequences: specific scenarios from V-plan
3. Sequence library: register all sequences for random selection
4. Never hardcode values — use randomized fields with constraints

**Domain Rules — Drivers:**
1. Drive signals cycle-accurate to protocol specification
2. Handle back-pressure: check ready/valid correctly
3. Protocol assertion in driver to catch illegal stimulus early

**Domain Rules — Scoreboard:**
1. Predict expected output from reference model before DUT output arrives
2. Report mismatches with full context (stimulus, expected, actual)
3. Track: total checks, pass, fail, untriggered

**Domain Rules — SVA Assertions:**
1. Protocol assertions: in interface bind, not DUT
2. Functional assertions: in checker or bind module
3. All assertions: clearly named with descriptive failure message

**QoR Metrics:**
- TB compile: 0 errors, 0 warnings
- Sanity test: passes with known-good RTL
- All components active in simulation log

See [references/verification-rules.md](references/verification-rules.md) for common UVM TB build issues and fixes.

**Output Required:**
- UVM component source files
- SVA assertion files (bind-based)
- Compile script

---

### Stage 4: directed_tests

Implement deterministic tests for each V-plan entry.

**Domain Rules:**
1. One directed test per V-plan entry — tests must be deterministic
2. Each test verifies the exact functional requirement it targets (no catch-all tests)
3. Error/exception paths: explicit stimulus to trigger each one
4. Corner cases: boundary values, max/min, overflow, underflow — one test each
5. Reset during active transaction: at least one test per interface
6. P0 tests must all pass before constrained-random phase begins
7. **DUT bug found during directed test: suspend flow immediately** — do not continue to constrained-random; flag RTL fix required and wait for confirmation

**QoR Metrics:**
- All V-plan features covered by at least one directed test
- P0 directed tests: 100% pass before proceeding
- 0 UVM FATAL or ERROR during directed test phase

**Output Required:**
- Directed test source files (one UVM sequence per feature)
- Directed test pass/fail report
- Bug report (if any DUT bugs found)

---

### Stage 5: constrained_random

Use constrained-random stimulus to expand coverage.

**Domain Rules:**
1. Constraint blocks: randomize all stimulus fields within protocol-legal ranges
2. Bias constraints: weight toward uncovered coverage bins identified in prior runs
3. Seeds: use at least 10 distinct seeds before evaluating coverage
4. Scoreboards active throughout: every transaction checked against reference model
5. Any UVM FATAL: stop immediately — do not accumulate errors across seeds
6. Any scoreboard mismatch: classify as DUT bug or testbench bug before continuing
7. Run until coverage targets are met or max seed budget exhausted

**QoR Metrics:**
- Functional coverage: trending toward 100% across seeds
- No persistent scoreboard mismatches (classify and fix before more seeds)
- Regression pass rate: 100% (no failing seeds)

See [references/verification-rules.md](references/verification-rules.md) for common constrained-random issues and fixes.

**Output Required:**
- Coverage report (merged across all seeds run so far)
- Uncovered bin list for directed test closure
- Seed log (seed number, pass/fail, coverage achieved)

---

### Stage 6: coverage_analysis

Analyze coverage and drive closure.

**Coverage Targets:**

| Type | Target | Priority |
|------|--------|----------|
| Functional (V-plan) | 100% | P0 |
| Code Line | ≥ 95% | P1 |
| Code Branch | ≥ 90% | P1 |
| Code Toggle | ≥ 85% | P2 |
| FSM State | 100% | P0 |
| FSM Transition | ≥ 95% | P0 |
| Assertion triggered | 100% | P1 |

**Closure Strategy:**
1. Identify uncovered bins after N random seeds
2. Write targeted directed tests for hard-to-hit bins
3. Adjust constraints to bias toward uncovered areas
4. Waive unreachable bins with justification (dead code)

**Waiver Discipline:**
- Unreachable code: justify with static analysis evidence
- Don't-care state combinations: document in V-plan
- All waivers: approved by verification lead before signoff

**QoR Metrics:**
- Functional coverage: 100% (no unwaived misses)
- Code coverage: per targets above
- Waiver file: all entries approved by verification lead

**Output Required:**
- Coverage report (merged across all seeds)
- Uncovered bin list with closure plan
- Waiver file

---

### Stage 7: formal_assist

Use formal property verification to close gaps simulation cannot efficiently reach.

**Use Cases for Formal:**
1. Protocol compliance: prove handshake never violates
2. Deadlock freedom: prove no state where valid=1 and ready never comes
3. Liveness: every request eventually gets a response
4. One-hot FSM: state encoding never has 0 or >1 bits set
5. Coverage closure: hit bins unreachable by simulation

**Domain Rules:**
1. Write properties in concurrent SVA
2. Group properties by feature in separate .sva files
3. Constrain environment with assumptions that match valid stimulus
4. Run vacuity check: assumption disabled → property should NOT hold
5. Bound liveness properties (`##[1:BOUND]`)

See [references/verification-rules.md](references/verification-rules.md) for common formal assist issues and fixes.

**QoR Metrics:**
- All properties: PROVEN or clearly UNREACHABLE
- No vacuous proofs
- Additional coverage bins closed vs simulation baseline

**Output Required:**
- SVA property file
- Formal run report (proven/failed/vacuous per property)
- CEX waveform descriptions for any failures

---

### Stage 8: regression_signoff

Define and manage regression suite to confirm DUT correctness before RTL signoff.

**Regression Tiers:**

| Tier | Trigger | Duration | Contents |
|------|---------|----------|----------|
| Smoke | Every RTL commit | < 30 min | P0 directed tests |
| Nightly | Every night | < 8 hr | All directed + 100 random seeds |
| Weekly | Weekly gate | < 48 hr | Full suite, 1000 seeds |
| Sign-off | Tape-out gate | Unlimited | Full suite, 10,000 seeds |

**Pass Criteria:**
- 0 simulation failures (excluding waived known bugs)
- 0 UVM FATAL or UVM ERROR messages
- All coverage targets met
- Formal: all P0 properties proven
- All P0/P1 bugs: closed

See [references/verification-rules.md](references/verification-rules.md) for common regression signoff issues and fixes.

**Output Required:**
- Regression pass/fail report
- Final merged coverage report
- Open bug list
- Sign-off checklist

---

## Sign-off Hard Gates

Verification signoff requires ALL of these conditions:

- `functional_coverage_pct == 100` (no unwaived misses)
- `regression_failures == 0` (all seeds pass)
- `open_p0_bugs == 0` (all P0 bugs closed)
- `open_p1_bugs == 0` (all P1 bugs closed)
- `uvm_fatal_count == 0` (no fatal errors in final regression)

**Critical note:**
Do not proceed to regression signoff with any P0 or P1 bugs open. Re-opening a regression signoff after a deferred P0 fix costs a full regression re-run.

---

See [references/verification-rules.md](references/verification-rules.md) for tool-specific flags and simulator configuration details.

---

## Loop-Back Rules

- `uvm_tb_build` compile failures → retry `uvm_tb_build` (max 3×)
- `directed_tests` finds DUT bug → suspend flow, wait for RTL fix
- `coverage_analysis` functional coverage < 100% → return to `constrained_random` (max 5×)
- `coverage_analysis` code line coverage < 95% → return to `directed_tests` (max 3×)
- `regression_signoff` failures → return to `constrained_random` (max 3×)

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior failure patterns, successful tool flags, and known tool quirks. Use this to inform stage decisions — for example, known Verilator phasing limitations or coverage stall patterns.

During a full verification campaign, it is useful to record key outcomes such as coverage state, bug counts, and issues encountered at each stage. If the project uses a persistent knowledge system, these can be written out for reuse across campaigns. The specific format and file paths for that are a project-level concern — this skill does not require a fixed memory layout to function.

---

## References

- [references/verification-rules.md](references/verification-rules.md) — extended stage details and orchestrator context
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/verification-flow.md](references/verification-flow.md) — broader flow narrative
- [../chip-design-architecture/scripts/qor_trends.py](../chip-design-architecture/scripts/qor_trends.py) — cross-run QoR trend utility (shared)
