# Common Simulation Failures Reference

## UVM Message Severity

Diagnosis should start from the highest severity and work downward:

| Severity | Meaning | Action |
|----------|---------|--------|
| `UVM_FATAL` | Unrecoverable setup error, simulation aborts immediately | Fix first — nothing else runs until FATAL is resolved |
| `UVM_ERROR` | Functional failure, simulation continues until `max_quit_count` | Fix after all FATALs are resolved |
| `UVM_WARNING` | Potential issue, non-blocking | Review after errors are clean |
| `UVM_INFO` | Informational trace | Use for diagnosis, not a problem itself |

**Key rule:** A single `UVM_FATAL` can mask all downstream `UVM_ERROR` messages. Always fix FATALs first.

## UVM_FATAL Classification

| Failure Type | Typical Log Keywords | Root Cause | Fix Path |
|-------------|---------------------|------------|----------|
| `config_db_miss` | `Failed to get`, `config_db`, `does not exist` | Key typo, wrong scope, `set()` not called, wrong type parameter | Match `set()` and `get()` calls — same key string, same type, correct hierarchical scope |
| `sequence_timeout` | `Timeout waiting`, `sequence body did not complete` | Wait condition never satisfied, missing response from DUT | Check DUT is responding, check wait condition, increase timeout |
| `phase_objection` | `objection`, `phase ready to end`, `OBJTN_ZERO` | `raise_objection` called but `drop_objection` never reached | Ensure every `raise` has a matching `drop`, check for early return paths |
| `factory_create_fail` | `Cannot create`, `factory`, `type not registered` | Class not registered with factory, wrong type name string | Add `uvm_component_utils` / `uvm_object_utils`, check type name |
| `tlm_connection` | `Connection`, `TLM`, `not connected`, `port is not bound` | Analysis port or export not connected in `connect_phase` | Add missing `.connect()` call in environment `connect_phase` |
| `type_cast_fail` | `$cast`, `dynamic cast failed`, `type mismatch` | Wrong transaction type on TLM port, incorrect sequence_item cast | Verify transaction type consistency across agent components |

## Scoreboard Mismatch Classification

| Mismatch Type | Symptom | Root Cause | Fix Path |
|--------------|---------|-----------|----------|
| **Data value mismatch** | `expected=0x41 actual=0x82` — values differ by bit-reversal or shift | Bit order (MSB-first vs LSB-first), encoding mismatch, wrong register offset | Check spec for bit ordering convention, verify register map in reference model |
| **Transaction count mismatch** | `expected 10 transactions, got 8` | Monitor sampling window wrong, transactions dropped, duplicate sampling | Check monitor triggering condition, verify no double-sampling on clock edges |
| **Timing mismatch** | Correct values but wrong order | Reordering in pipeline, async crossing, out-of-order completion | Add transaction ID tracking, use ordered/unordered comparison mode |
| **Field mismatch** | Some fields match, others don't | `pack()`/`unpack()` field order wrong, missing field in comparison | Check `do_compare()` or field macros, verify pack order matches protocol |

## Simulation Timeout Classification

| Timeout Type | Symptom | Root Cause | Fix Path |
|-------------|---------|-----------|----------|
| **Global timeout** | `UVM_FATAL: Timeout reached` at configured limit | Objection not dropped — test never finishes | Search for unmatched `raise_objection`, add `drop_objection` in all exit paths |
| **Sequence stuck** | Sequence body hangs, no new transactions | `wait` condition never satisfied, missing event trigger | Check wait conditions, verify DUT is producing expected signals |
| **Driver stuck** | Driver waiting for sequence item, none arriving | No sequence running on sequencer, sequencer not started | Check test `run_phase` starts sequences, verify sequencer is connected |
| **DUT no response** | Driver sends stimulus, monitor sees nothing back | FSM stuck in reset or idle, clock not toggling, reset held active | Check reset deasserts, verify clock is running, check FSM state |
| **Drain time insufficient** | Simulation ends before last transactions are compared | `set_drain_time` too short, pipeline latency not accounted for | Increase drain time: `phase.phase_done.set_drain_time(this, 500ns)` |

## X/Z Propagation Checklist

When `X` or `Z` values appear on DUT outputs or in scoreboard comparisons, check these in order:

1. **Reset complete before first transaction?**
   - Verify reset is asserted for sufficient cycles
   - Verify reset is deasserted before the first bus transaction
   - Check `reset_phase` or initial block in testbench

2. **All interface signals connected?**
   - Every signal in every SV interface must connect to DUT ports
   - Unconnected inputs default to `X` in VCS (or `Z` depending on `+xprop` mode)

3. **Uninitialized storage?**
   - DUT internal registers/memories may be `X` until written
   - Read-before-write produces `X` — verify test writes before reading

4. **Cross-clock domain without synchronizer?**
   - If DUT has multiple clock domains, signals crossing domains without synchronization may sample metastable values
   - Check if DUT has synchronizers; if not, this is a design issue (report, don't fix)

5. **Tri-state or open-drain signals?**
   - Some protocols use open-drain signaling
   - Verify pullup/pulldown in testbench for tri-state nets

## Real UVM Log Examples (UART design — replace names for your design)

### config_db Miss
```
UVM_FATAL @ 0: uvm_test_top.env.apb_agent [APB_AGT] Failed to get virtual interface from config_db. Key='vif_apb' Scope='uvm_test_top.env.apb_agent.*'
```
**Diagnosis:** The `set()` call in `testbench.sv` uses a different scope or key name.
**Fix:** Verify `uvm_config_db#(virtual apb_interface)::set(null, "uvm_test_top.env.apb_agent*", "vif_apb", apb_if);` in testbench matches the `get()` call exactly.

### Scoreboard Mismatch
```
UVM_ERROR @ 52000: uvm_test_top.env.scoreboard [SCB] Data mismatch: expected=8'h41 actual=8'h00
  Transaction #3: APB read from addr=0x00 (RBR)
  Expected from UART RX model, Actual from APB monitor
```
**Diagnosis:** Output data not received by DUT. Check if TX sequence actually sent data, check protocol configuration, check internal FIFO status.
**Fix:** Verify protocol parameters are configured correctly before transmitting, ensure sufficient time for transaction to complete.

### Phase Objection Timeout
```
UVM_FATAL @ 1000000000: reporter [PHASE_TIMEOUT] Default timeout of 1s reached. All objections:
  uvm_test_top.env.apb_agent.sequencer [count=1]
```
**Diagnosis:** A sequence raised an objection but never dropped it — likely stuck waiting for a condition.
**Fix:** Check the sequence body for `wait` statements that may never complete. Add timeout guards:
```systemverilog
fork
  seq.body();
  #100us $fatal(1, "Sequence timeout");
join_any
```

### Factory Create Failure
```
UVM_FATAL @ 0: reporter [FACTORY] Cannot create component of type 'apbuart_coverage' — type not registered with factory.
```
**Diagnosis:** Class `apbuart_coverage` missing factory registration macro.
**Fix:** Add `` `uvm_component_utils(apbuart_coverage) `` inside the class body.

## VCS Simulation Options

| Option | Purpose |
|--------|---------|
| `+xprop` | Strict X propagation — X on condition propagates X to outputs (recommended for RTL debug) |
| `+UVM_TIMEOUT=<ns>,YES` | Set global simulation timeout (e.g., `+UVM_TIMEOUT=5000000,YES` for 5ms) |
| `+UVM_VERBOSITY=UVM_HIGH` | Increase message verbosity for debugging |
| `+UVM_MAX_QUIT_COUNT=10` | Stop after 10 `UVM_ERROR` messages instead of running to completion |
| `+ntb_random_seed=<N>` | Set specific random seed for reproducibility |
| `+fsdb+autoflush` | Auto-flush FSDB waveform for post-mortem debug |
| `-debug_access+all` | Enable full debug access for Verdi |

## Waveform Debug Escalation Guide

### When to Escalate to Waveform Analysis

Log-based diagnosis covers approximately 60% of debug scenarios. Escalate to waveform inspection when:

| Condition | Log symptom | Why waveform is needed |
|-----------|-------------|----------------------|
| Scoreboard data mismatch persists after 2 fix rounds | `MISMATCH: exp=0xNN act=0xMM` | Need to trace data through DUT pipeline cycle by cycle |
| X/Z propagation source unclear | `X` or `Z` in comparisons | Need to trace which signal first goes X and propagate path |
| Timing-dependent failure (passes on some seeds) | Intermittent `UVM_ERROR` | Need to observe signal timing relative to clock edges |
| FSM stuck (DUT no response) | Timeout with no output transactions | Need to observe FSM state register and transition conditions |
| Protocol violation assertion fires | `SVA_ERROR` with no clear log context | Need to see signal waveforms around assertion failure time |

### Key Signal Groups to Inspect

When recommending waveform inspection to the user, specify which signals to examine:

| Debug scenario | Signal group | What to look for |
|---------------|-------------|-----------------|
| **Register read-back mismatch** | Bus interface (PADDR, PWDATA, PRDATA, PSEL, PENABLE, PWRITE, PREADY) | Correct address decode, write-then-read timing, PREADY assertion |
| **TX/RX data mismatch** | Serial TX line, RX line, baud clock, internal shift register | Bit timing, start/stop bit, parity bit correctness |
| **FSM stuck** | State register, next-state logic inputs, clock, reset | Which state the FSM is in, why transition condition is not met |
| **X propagation** | Reset signal, clock signal, DUT internal registers | First cycle where X appears, reset duration adequacy |
| **Config register** | Config register outputs, write strobe, address decoder | Whether config actually updates on write |

### Waveform Launch Commands

Include in `escalation_report.json` when waveform debug is recommended:

**VCS + Verdi:**
```bash
# Compile with debug access (add to Makefile compile flags if not present)
+fsdbfile+sim/wave.fsdb +fsdb+autoflush -debug_access+all

# Open waveform after simulation
verdi -ssf sim/wave.fsdb -nologo &
```

**VCS + DVE:**
```bash
# Compile with VPD dump
+vpdfile+sim/wave.vpd -debug_access+all

# Open waveform
dve -vpd sim/wave.vpd &
```

**Xcelium + SimVision:**
```bash
# Run with SHM dump
-access +rwc -input probe.tcl

# Open waveform
simvision sim/waves.shm &
```

### Escalation Report Waveform Section

When escalating to waveform debug, the `escalation_report.json` should include:
```json
{
  "waveform_debug": {
    "recommended": true,
    "reason": "string — why log analysis is insufficient",
    "signals_to_inspect": ["string — signal paths"],
    "time_window": "string — approximate simulation time range to focus on (e.g., '50us-60us')",
    "launch_command": "string — simulator-specific waveform viewer command"
  }
}
```
