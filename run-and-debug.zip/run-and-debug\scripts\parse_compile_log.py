#!/usr/bin/env python3
"""Parse EDA compile logs and classify errors into structured JSON.

Supports VCS, Xcelium, and Questa. Auto-detects simulator from log content.

Usage:
    python3 parse_compile_log.py <compile_log_path>

Output (stdout):
    JSON object with classified errors and systemic issue detection.
"""

import json
import re
import sys
from collections import Counter


# ---------------------------------------------------------------------------
# Simulator detection
# ---------------------------------------------------------------------------

def detect_simulator(text):
    """Return 'vcs', 'xcelium', 'questa', or 'unknown'."""
    if "Chronologic VCS" in text or "vcs+" in text or "Error-[" in text:
        return "vcs"
    if "xmvlog" in text or "xrun" in text or "xmelab" in text or "xmsim" in text:
        return "xcelium"
    if "QuestaSim" in text or "vlog " in text or "** Error: (vlog-" in text:
        return "questa"
    return "unknown"


# ---------------------------------------------------------------------------
# Error patterns per simulator
# ---------------------------------------------------------------------------

VCS_PATTERNS = [
    (r"Error-\[SE\]",                          "syntax"),
    (r"Error-\[TYCMPAT\]",                     "type_mismatch"),
    (r"Error-\[IUACUNF\]",                     "undeclared"),
    (r"Error-\[UMCRO\]",                       "undefined_macro"),
    (r"Error-\[URGIO\]",                       "undeclared"),
    (r"Error-\[ICPD\]",                        "include"),
    (r"Error-\[SFCOF\]",                       "include"),
    (r"Error-\[PCWM-L\]",                      "connection"),
    (r"Error-\[PCTI\]",                        "connection"),
    (r"Error-\[CNST-LHS\]",                    "syntax"),
    (r"Error-\[ENUMERR\]",                     "type_mismatch"),
    (r"Error-\[DUPIMP\]",                      "syntax"),
    (r"Error-\[MFNF\]",                        "include"),
    (r"Error-\[",                               "other"),
]

XCELIUM_PATTERNS = [
    (r"xm\w+:\s*\*E,ILLPAR",                   "syntax"),
    (r"xm\w+:\s*\*E,TYCMPAT",                  "type_mismatch"),
    (r"xm\w+:\s*\*E,UNDIDN",                   "undeclared"),
    (r"xm\w+:\s*\*E,UNDMCR",                   "undefined_macro"),
    (r"xm\w+:\s*\*E,NOFNIN",                   "include"),
    (r"xm\w+:\s*\*E,CUVMPW",                   "connection"),
    (r"xm\w+:\s*\*E,CUVUNF",                   "connection"),
    (r"xm\w+:\s*\*E,EXPRPA",                   "syntax"),
    (r"xm\w+:\s*\*E,NOTPAR",                   "syntax"),
    (r"xm\w+:\s*\*E,PORTCO",                   "connection"),
    (r"xm\w+:\s*\*E,",                         "other"),
]

QUESTA_PATTERNS = [
    (r"\*\* Error: \(vlog-2110\)",              "undeclared"),
    (r"\*\* Error: \(vlog-7027\)",              "type_mismatch"),
    (r"\*\* Error: \(vlog-2892\)",              "include"),
    (r"\*\* Error: \(vlog-2163\)",              "syntax"),
    (r"\*\* Error: \(vlog-2388\)",              "undefined_macro"),
    (r"\*\* Error: \(vlog-2730\)",              "connection"),
    (r"\*\* Error: \(vlog-2244\)",              "undeclared"),
    (r"\*\* Error: \(vlog-2605\)",              "syntax"),
    (r"\*\* Error: \(vlog-\d+\)",               "other"),
    (r"\*\* Error:",                            "other"),
]

GENERIC_PATTERNS = [
    (r"[Ee]rror.*[Ss]yntax",                   "syntax"),
    (r"[Ee]rror.*[Tt]ype",                      "type_mismatch"),
    (r"[Ee]rror.*[Uu]ndeclared",                "undeclared"),
    (r"[Ee]rror.*[Uu]ndefined\s+macro",         "undefined_macro"),
    (r"[Ee]rror.*[Nn]ot\s+found",               "include"),
    (r"[Ee]rror",                               "other"),
]


def get_patterns(simulator):
    """Return the pattern list for the detected simulator."""
    if simulator == "vcs":
        return VCS_PATTERNS
    if simulator == "xcelium":
        return XCELIUM_PATTERNS
    if simulator == "questa":
        return QUESTA_PATTERNS
    return GENERIC_PATTERNS


# ---------------------------------------------------------------------------
# Error extraction
# ---------------------------------------------------------------------------

def classify_line(line, patterns):
    """Return the error category for a line, or None if no match."""
    for regex, category in patterns:
        if re.search(regex, line):
            return category
    return None


def extract_errors(lines, patterns):
    """Walk through log lines and collect classified errors."""
    errors = []
    for lineno, line in enumerate(lines, start=1):
        category = classify_line(line, patterns)
        if category is not None:
            errors.append({
                "line": lineno,
                "category": category,
                "text": line.rstrip(),
            })
    return errors


# ---------------------------------------------------------------------------
# Systemic detection
# ---------------------------------------------------------------------------

SYSTEMIC_SUGGESTIONS = {
    "syntax": "Multiple syntax errors may indicate a missing file or broken include chain. Check flist order.",
    "type_mismatch": "Multiple type mismatches suggest an interface or transaction definition changed without updating consumers. Check docs/spec_analysis.json interfaces section and uvm_tb/*_interface.sv.",
    "undeclared": "Multiple undeclared identifiers suggest a package is not compiled or not imported. Ensure the project package file is in flist before testbench.sv.",
    "undefined_macro": "Multiple undefined macros suggest tb_define.v is missing from flist or compiled too late. Move it to the first position.",
    "include": "Multiple include errors suggest incorrect -incdir paths in Makefile or flist.",
    "connection": "Multiple connection errors suggest an interface definition changed. Re-check interface port lists.",
    "factory": "Multiple factory errors suggest package compilation order issue. Ensure all classes are registered.",
    "phase": "Multiple phase errors suggest a UVM version mismatch or base class change.",
    "other": "Multiple unclassified errors — manual review recommended.",
}


def detect_systemic(errors, threshold=5):
    """Detect categories with more than `threshold` occurrences."""
    counts = Counter(e["category"] for e in errors)
    systemic = []
    for category, count in counts.items():
        if count > threshold:
            systemic.append({
                "category": category,
                "count": count,
                "suggestion": SYSTEMIC_SUGGESTIONS.get(category, "Review errors in this category."),
            })
    # Sort by count descending for readability
    systemic.sort(key=lambda s: -s["count"])
    return systemic


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        print("Usage: parse_compile_log.py <compile_log_path>", file=sys.stderr)
        sys.exit(1)

    log_path = sys.argv[1]

    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except FileNotFoundError:
        print(f"Error: file not found: {log_path}", file=sys.stderr)
        sys.exit(1)

    lines = text.splitlines()
    simulator = detect_simulator(text)
    patterns = get_patterns(simulator)
    errors = extract_errors(lines, patterns)
    systemic = detect_systemic(errors)

    report = {
        "simulator": simulator,
        "log": log_path,
        "total_errors": len(errors),
        "errors": errors,
        "systemic": systemic,
    }

    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
