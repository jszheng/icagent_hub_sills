# Stage 5 Output Schema

## compile_report.json

```json
{
  "stage": "run-and-debug",
  "phase": "compile",
  "timestamp": "ISO-8601",
  "simulator": "vcs | xcelium | questa | unknown",
  "rounds": [
    {
      "round": "integer",
      "total_errors": "integer",
      "errors_by_category": {"syntax": 0, "type_mismatch": 0, "undeclared": 0, "...": 0},
      "fixes_applied": [
        {"file": "string", "line": "integer", "category": "string", "fix": "string"}
      ],
      "systemic_issues": [
        {"category": "string", "count": "integer", "suggestion": "string"}
      ]
    }
  ],
  "final_status": "clean | errors_remaining | escalated",
  "remaining_errors": "integer"
}
```

## sim_report.json

```json
{
  "stage": "run-and-debug",
  "phase": "simulate",
  "timestamp": "ISO-8601",
  "tests": [
    {
      "test_name": "string",
      "result": "PASS | FAIL",
      "failure_type": "null | uvm_fatal | uvm_error | timeout | mismatch | x_propagation",
      "failure_layer": "null | testcase | environment | checker | rtl_spec_mismatch",
      "fix_applied": "string | null",
      "rounds": "integer"
    }
  ],
  "overall": "all_pass | some_fail | escalated"
}
```

## escalation_report.json

```json
{
  "stage": "run-and-debug",
  "timestamp": "ISO-8601",
  "round": "integer",
  "unresolved_errors": [
    {
      "category": "string",
      "file": "string",
      "line": "integer",
      "description": "string",
      "attempted_fix": "string | null",
      "reason_escalated": "string"
    }
  ],
  "recommendation": "string"
}
```
