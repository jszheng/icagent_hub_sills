# Common Compile Errors Reference

## Error Classification Table

| Category | Typical Root Cause | Fix Method | Priority |
|----------|--------------------|------------|----------|
| `syntax` | Missing semicolon, mismatched begin/end, unclosed string | Add missing token, balance delimiters | High (auto-fix safe) |
| `type_mismatch` | Assigning logic to int, wrong width, enum vs integral | Cast or change declaration to match | Medium (needs review) |
| `undeclared` | Identifier not imported, typo in name, scope issue | Add import, fix spelling, check scope | High |
| `undefined_macro` | Macro used but `tb_define.v` not included or macro missing | Add macro to `tb_define.v` or fix include | High (auto-fix safe) |
| `include` | File not in search path, wrong relative path, circular include | Fix flist `-incdir`, fix path | High (auto-fix safe) |
| `connection` | Port width mismatch, interface modport wrong, missing port | Match port declaration to instantiation | Medium (needs review) |
| `factory` | Missing `uvm_component_utils`/`uvm_object_utils`, wrong macro | Add correct factory registration macro | High (auto-fix safe) |
| `phase` | Wrong phase method signature, missing `super.build_phase()` call | Fix method signature per UVM LRM | Medium (needs review) |

## Compile Order Guidance

### Recommended flist Order

```
// 1. Macro definitions (must be first)
uvm_tb/tb_define.v

// 2. RTL design files
design/<design_defines>.v
design/<design_top>.v

// 3. Interface definitions
uvm_tb/<proto_a>_interface.sv
uvm_tb/<proto_b>_interface.sv

// 4. UVM library (usually via +incdir or -ntb_opts uvm)
// VCS: -ntb_opts uvm-1.2
// Xcelium: -uvm

// 5. Package (imports all UVM TB classes)
uvm_tb/<project>_pkg.sv

// 6. Testbench top
uvm_tb/testbench.sv
```

### Common Compile Order Problems

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| All UVM classes "not found" | `uvm_pkg` not imported or UVM library not loaded | Add `-ntb_opts uvm-1.2` (VCS) or `-uvm` (Xcelium) |
| All project classes "not found" | Package file not compiled or compiled too late | Move `<project>_pkg.sv` before `testbench.sv` in flist |
| Macro undefined everywhere | `tb_define.v` not first in flist | Move `tb_define.v` to top of flist |
| Interface "not a type" | Interface compiled after module that uses it | Move interface files before package/testbench |
| Circular dependency | File A includes B, B includes C, C includes A | Use package-based compilation, remove circular includes |

## Systemic Error Detection

| Pattern | Interpretation | Action |
|---------|---------------|--------|
| Same category > 5 errors | Root cause is upstream, not in individual files | Find and fix the single upstream cause (missing import, compile order, missing macro file) |
| Fix one, break three | Compile order issue or interface mismatch rippling | Rollback fix, examine compile order and interface contracts |
| All classes "not found" | Package not compiled or not imported | Check flist for `<project>_pkg.sv`, check `import <project>_pkg::*` in testbench top |
| All macros undefined | `tb_define.v` missing from flist or compiled too late | Move `tb_define.v` to first position in flist |
| Many "type incompatible" | Interface definition changed but consumers not updated | Check `docs/spec_analysis.json` interfaces section and `uvm_tb/*_interface.sv`, update all consumers |

## Real EDA Log Examples (UART design — replace names for your design)

### Syntax Error
```
Error-[SE] Syntax error
  Following verilog source has syntax error :
  "uvm_tb/apbuart_scoreboard.sv", 45: token is ';'
    expected: identifier, ...
      end // missing 'end' for previous 'begin'
    ;
```
**Category:** `syntax`
**Fix:** Add missing `end` before the flagged line.

### Type Incompatible
```
Error-[TYCMPAT] Type incompatible
  "uvm_tb/apb_driver.sv", 78:
  Incompatible complex type assignment
  Type of source expression is incompatible with type of target expression.
  The type of the target is 'logic [7:0]', while the source is 'logic [31:0]'.
```
**Category:** `type_mismatch`
**Fix:** Adjust width — either truncate source or widen target. Verify intent against spec.

### Identifier Undeclared
```
Error-[IUACUNF] Identifier undeclared
  "uvm_tb/apbuart_env.sv", 32:
  Identifier 'apb_agent' has not been declared yet. If this error is not
  expected, please make sure that the package which defines 'apb_agent'
  is included.
```
**Category:** `undeclared`
**Fix:** Ensure project package includes the agent file and is compiled before `testbench.sv`.

### Undefined Macro
```
Error-[UMCRO] Undefined macro
  "uvm_tb/apbuart_tests.sv", 15:
  Macro `UART_CLK_PERIOD is not defined.
```
**Category:** `undefined_macro`
**Fix:** Add `UART_CLK_PERIOD` definition to `uvm_tb/tb_define.v`.

### Xcelium Examples (same UART design)

### Illegal Parameter
```
xmvlog: *E,ILLPAR (uvm_tb/apb_driver.sv,45|22): illegal actual parameter to a task/function: expecting expression.
```
**Category:** `syntax`
**Fix:** Check function call arguments — likely passing a type where an expression is expected.

### Type Mismatch
```
xmvlog: *E,TYCMPAT (uvm_tb/uart_driver.sv,92|15): type mismatch in assignment: target is 'logic [7:0]', source is 'logic [31:0]'.
```
**Category:** `type_mismatch`
**Fix:** Same as VCS — adjust width, verify intent.

### Undefined Identifier
```
xmvlog: *E,UNDIDN (uvm_tb/apbuart_env.sv,28|4): undefined identifier 'uart_agent'.
```
**Category:** `undeclared`
**Fix:** Check package includes and compile order.

### Questa Examples (same UART design)

### Illegal Reference
```
** Error: (vlog-2110) uvm_tb/apbuart_scoreboard.sv(52): Illegal reference to net "expected_data".
```
**Category:** `undeclared`
**Fix:** Declare `expected_data` as a variable (not net) or check scope.

### Type Mismatch
```
** Error: (vlog-7027) uvm_tb/apb_driver.sv(88): Type mismatch in port connection. Port 'data' expects 'logic [7:0]' but is connected to 'logic [31:0]'.
```
**Category:** `type_mismatch`
**Fix:** Match port width to connection width.

### Missing Include
```
** Error: (vlog-2892) uvm_tb/testbench.sv(5): File 'apbuart_pkg.sv' not found on any of the include paths.
```
**Category:** `include`
**Fix:** Add `-incdir uvm_tb` to compile options or use full path in flist.
