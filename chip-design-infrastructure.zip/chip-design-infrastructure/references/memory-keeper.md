# Memory Keeper Reference

This file preserves the original `memory-keeper` plugin logic as a reusable reference for the standalone infrastructure skill.

## Purpose

Distil accumulated `experiences.jsonl` records into updated `knowledge.md` summaries for chip-design domains. Use it after enough orchestrator runs have accumulated new issue/fix patterns, tool flags, or metric history.

## Invocation Intent

Equivalent source usage:
- `--domain <name>` for one domain
- `--all` for all eligible domains
- `--min-records <n>` to require a minimum evidence threshold

## Distillation Workflow

### 1. Load experiences
- Read `memory/<domain>/experiences.jsonl`
- Skip the domain if the file is missing, empty, or below threshold
- Ignore malformed lines but log warnings
- Group records into:
  - issue/fix pairs
  - tool flag candidates
  - metric ranges
  - free-form notes

### 2. Distil knowledge
- Read the existing `memory/<domain>/knowledge.md`
- Add new failure patterns not already captured
- Add successful tool flags observed repeatedly
- Add tool or PDK quirks supported by evidence
- Annotate repeated confirmations
- Mark contradictions explicitly instead of silently overwriting older knowledge
- Update the distillation timestamp

### 3. Report
Produce a concise per-domain report showing:
- records read
- date range
- sign-off rate
- new entries per section
- how many prior entries were annotated or corrected
- which domains were skipped due to insufficient evidence

## Merge Policy

- New issue/fix pattern -> add under failure patterns
- Existing entry confirmed repeatedly -> annotate with confirmation count
- Existing entry contradicted repeatedly -> preserve it visibly and add corrected guidance
- Single-record observations should only be promoted when the evidence is strong and sign-off was achieved

## Use inside this standalone skill

Use this reference whenever a user wants the environment skill to learn from prior runs rather than just detect tools and package wrappers.
