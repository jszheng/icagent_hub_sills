# Infrastructure Knowledge

This standalone skill does not have a domain-specific `memory/infrastructure/knowledge.md` in the source repository.

To preserve the original plugin's reusable knowledge, this file distills the shared memory model from `memory/README.md`.

## Two-tier Memory Model

### Tier 1: `experiences.jsonl`
Append-only JSONL. One record per completed or abandoned orchestrator run. This is the machine-parseable evidence log.

### Tier 2: `knowledge.md`
A distilled human-readable summary of recurring failure patterns, successful flags, and tool or PDK quirks. Orchestrators should read this at session start.

## Experience Record Shape

Each record should capture:
- timestamp
- domain
- design name
- tool used
- completed stages
- loop-back counts
- key metrics
- issues encountered
- fixes applied
- whether sign-off was achieved
- free-form notes

## Domain Metric Families

The original project tracks different key metrics per domain, for example:
- architecture: selected architecture, estimated frequency, estimated area
- synthesis: WNS, cell count, area, LEC mismatches
- verification: functional coverage, regression failures, assertion activity
- sta: setup/hold/TNS/failing paths
- pd: WNS, DRC, LVS, GDS area

## Operational Guidance

- Read the domain's `knowledge.md` before starting a flow.
- Append an experience record when a flow ends, even on interruption or escalation.
- Distil new evidence into `knowledge.md` periodically rather than letting JSONL logs grow without feedback.
- Preserve contradictions explicitly instead of deleting older guidance silently.

## Why this matters in the standalone skill

This skill is intended to be portable into other chip-design environments. The memory model is therefore part of the reusable contract, not just an implementation detail of the original plugin repo.
