# Infrastructure Rules Reference

## Open-Source First Principle

All detection and presentation follows open-source first ordering:
- Open-source tool commands are detected before commercial ones within each capability
- Open-source candidates are listed first with `[recommended]` tag in user-facing output
- When no open-source alternative exists for a capability (CDC/RDC, DFT, IR/EM), this is clearly stated

## Stage Sequence

`tool_discovery → environment_validation`

## Detection Rules

1. Check module system: `$MODULESHOME` set or `modulecmd` in PATH → run `module avail 2>&1`
2. For every candidate tool: `which <command>` for PATH detection — **open-source commands checked first, then commercial**
3. Tools not in PATH but in module avail → `AVAILABLE_VIA_MODULE`
4. Tools in PATH → `FOUND` with path and version
5. Tools not found anywhere → `NOT_FOUND`

## User Confirmation Rules

- Every detected tool must be confirmed by the user before recording as active
- Never auto-select, even if only one candidate exists
- Open-source tools shown first with `[recommended]` tag; commercial tools shown after
- User may select multiple tools per capability
- User may skip any capability
- Missing tools: suggest open-source installation first, then module load or admin contact for commercial

## tool-config.json Rules

- Created by infrastructure skill (full scan) or incrementally by any downstream skill
- Each capability is an array (may contain 0, 1, or multiple confirmed tools)
- `not_configured` lists capabilities with no confirmed tool
- `user_actions` lists suggested commands for missing tools
- If file already exists when a skill runs: read it, check needed capabilities, only prompt for gaps

## Loop-back Rules

- Module system not found → proceed without module detection (WARN, non-fatal)
- User declines all tools for a capability → record empty array, continue
- `tool-config.json` already exists → ask user: re-detect all or keep existing
- Downstream skill finds missing capability → detect + prompt for that capability only, append to file

## Capability Classification

Each downstream skill declares capabilities as:
- **Required**: skill cannot proceed without at least one confirmed tool
- **Optional**: skill can proceed, but some features will be unavailable

---

## Capability-Tool Mapping Tables

All EDA tools are organized by **capability**. Within each capability, **open-source candidates are listed first** (recommended), followed by commercial alternatives.

### Simulation

| Candidate | Command | Type |
|-----------|---------|------|
| Verilator | `verilator` | Open-source (recommended) |
| Icarus Verilog | `iverilog` | Open-source |
| VCS | `vcs` | Commercial — Synopsys |
| Xcelium | `xrun` | Commercial — Cadence |
| QuestaSim | `vsim` | Commercial — Siemens |

### Waveform / Debug

| Candidate | Command | Type |
|-----------|---------|------|
| GTKWave | `gtkwave` | Open-source (recommended) |
| Verdi | `verdi` | Commercial — Synopsys |
| SimVision | `simvision` | Commercial — Cadence |
| Indago | `indago` | Commercial — Cadence |

### Lint

| Candidate | Command | Type |
|-----------|---------|------|
| Verilator lint | `verilator` | Open-source (recommended) |
| Slang | `slang` | Open-source |
| SpyGlass | `spyglass` | Commercial — Synopsys |
| HAL | `hal` | Commercial — Cadence |

### CDC / RDC

> **No mature open-source alternative exists.** Commercial tool required for production CDC/RDC analysis.

| Candidate | Command | Type |
|-----------|---------|------|
| SpyGlass CDC | `spyglass` | Commercial — Synopsys |
| JasperGold CDC | `jg` | Commercial — Cadence |
| Questa CDC | `questa_cdc` | Commercial — Siemens |

### Synthesis

| Candidate | Command | Type |
|-----------|---------|------|
| Yosys | `yosys` | Open-source (recommended) |
| Design Compiler | `dc_shell` | Commercial — Synopsys |
| Fusion Compiler | `fc_shell` | Commercial — Synopsys |
| Genus | `genus` | Commercial — Cadence |

### STA (Static Timing Analysis)

| Candidate | Command | Type |
|-----------|---------|------|
| OpenSTA | `sta` | Open-source (recommended) |
| PrimeTime | `pt_shell` | Commercial — Synopsys |
| Tempus | `tempus` | Commercial — Cadence |

### Formal — FPV (formal_fpv)

| Candidate | Command | Type |
|-----------|---------|------|
| SymbiYosys | `sby` | Open-source (recommended) |
| VC Formal | `vcf` | Commercial — Synopsys |
| JasperGold | `jg` | Commercial — Cadence |
| Questa Formal | `qformal` | Commercial — Siemens |

### Formal — Equivalence / LEC (formal_equiv)

| Candidate | Command | Type |
|-----------|---------|------|
| Yosys equiv | `yosys` | Open-source (recommended) |
| Formality | `formality` | Commercial — Synopsys |
| Conformal LEC | `lec` | Commercial — Cadence |

### Physical Design

| Candidate | Command | Type |
|-----------|---------|------|
| OpenROAD | `openroad` | Open-source (recommended) |
| IC Compiler 2 | `icc2_shell` | Commercial — Synopsys |
| Fusion Compiler | `fc_shell` | Commercial — Synopsys |
| Innovus | `innovus` | Commercial — Cadence |

### DFT

> **No mature open-source alternative exists.** Commercial tool required for production DFT insertion and ATPG.

| Candidate | Command | Type |
|-----------|---------|------|
| TetraMAX / TestMAX | `tmax` | Commercial — Synopsys |
| Modus | `modus` | Commercial — Cadence |
| Tessent | `tessent` | Commercial — Siemens |

### DRC / LVS

| Candidate | Command | Type |
|-----------|---------|------|
| KLayout | `klayout` | Open-source (recommended) |
| ICV | `icv` | Commercial — Synopsys |
| Pegasus | `pegasus` | Commercial — Cadence |
| Calibre | `calibre` | Commercial — Siemens |

### Parasitic Extraction

| Candidate | Command | Type |
|-----------|---------|------|
| OpenRCX (via OpenROAD) | `openroad` | Open-source (recommended for digital; limited analog accuracy) |
| StarRC | `starrc` | Commercial — Synopsys |
| Quantus | `quantus` | Commercial — Cadence |

### Power Analysis

| Candidate | Command | Type |
|-----------|---------|------|
| OpenSTA power (limited) | `sta` | Open-source (basic static power only) |
| OpenROAD power | `openroad` | Open-source (IR drop analysis via PDNSim) |
| PrimeTime PX | `pt_shell` | Commercial — Synopsys |
| PrimeSim | `primesim` | Commercial — Synopsys |
| Voltus | `voltus` | Commercial — Cadence |

### IR/EM Analysis

> **No mature open-source alternative for full-chip IR/EM signoff.** OpenROAD PDNSim provides basic IR drop estimation but is not a substitute for production EM analysis.

| Candidate | Command | Type |
|-----------|---------|------|
| OpenROAD PDNSim | `openroad` | Open-source (IR drop estimation only) |
| RedHawk | `redhawk` | Commercial — Ansys |

### Performance Modeling

| Candidate | Command | Type |
|-----------|---------|------|
| gem5 | `gem5` | Open-source |
| McPAT | `mcpat` | Open-source |
| CACTI | `cacti` | Open-source |

### HLS

| Candidate | Command | Type |
|-----------|---------|------|
| Bambu | `bambu` | Open-source (recommended) |
| Vitis HLS | `vitis_hls` | Commercial — AMD/Xilinx |
| Stratus | `stratus` | Commercial — Cadence |
| Catapult | `catapult` | Commercial — Siemens |

### FPGA

| Candidate | Command | Type |
|-----------|---------|------|
| Yosys + nextpnr | `yosys`, `nextpnr` | Open-source (recommended) |
| Vivado | `vivado` | Commercial — AMD/Xilinx |
| Quartus | `quartus_sh` | Commercial — Intel |

### Compiler Toolchain

| Candidate | Command | Type |
|-----------|---------|------|
| LLVM/Clang | `clang`, `llc` | Open-source (recommended) |
| GCC | `gcc` | Open-source |
| Arm Compiler | `armclang` | Commercial — Arm |

### Firmware Debug

| Candidate | Command | Type |
|-----------|---------|------|
| OpenOCD | `openocd` | Open-source (recommended) |
| J-Link | `JLinkGDBServer` | Commercial — SEGGER |
| TRACE32 | `t32marm` | Commercial — Lauterbach |

---

## Module-to-Tool Mapping Table

Open-source tools (detected first):

| Command | Module name patterns (case-insensitive) |
|---------|----------------------------------------|
| `verilator` | `verilator` |
| `iverilog` | `iverilog`, `icarus` |
| `slang` | `slang` |
| `yosys` | `yosys` |
| `sby` | `symbiyosys`, `sby` |
| `openroad` | `openroad` |
| `sta` | `opensta` |
| `klayout` | `klayout` |
| `gtkwave` | `gtkwave` |
| `bambu` | `bambu` |
| `nextpnr` | `nextpnr` |
| `gcc` | `gcc` |
| `llc` | `llvm` |
| `openocd` | `openocd` |
| `gem5` | `gem5` |

Commercial tools (detected after open-source):

| Command | Module name patterns (case-insensitive) |
|---------|----------------------------------------|
| `vcs` | `vcs`, `synopsys/vcs` |
| `xrun` | `xcelium`, `cadence/xcelium` |
| `vsim` | `questa`, `questasim`, `mentor/questa` |
| `dc_shell` | `syn`, `synopsys/syn`, `design-compiler` |
| `fc_shell` | `fusioncompiler`, `synopsys/fusioncompiler` |
| `genus` | `genus`, `cadence/genus` |
| `innovus` | `innovus`, `cadence/innovus` |
| `pt_shell` | `pt`, `synopsys/pt`, `primetime` |
| `tempus` | `tempus`, `cadence/tempus` |
| `formality` | `fm`, `synopsys/fm`, `formality` |
| `verdi` | `verdi`, `synopsys/verdi` |
| `spyglass` | `spyglass`, `synopsys/spyglass` |
| `jg` | `jaspergold`, `cadence/jaspergold` |
| `calibre` | `calibre`, `mentor/calibre` |
| `tessent` | `tessent`, `mentor/tessent` |
| `icv` | `icv`, `synopsys/icv` |
| `starrc` | `starrc`, `synopsys/starrc` |
| `redhawk` | `redhawk`, `ansys/redhawk` |
| `tmax` | `testmax`, `synopsys/testmax`, `tmax` |
| `primesim` | `primesim`, `synopsys/primesim` |
| `vivado` | `vivado`, `xilinx/vivado` |
| `quartus_sh` | `quartus`, `intel/quartus` |

---

## Presentation Format Example

```
=== EDA Tool Configuration (open-source first) ===

simulation:
  [1] verilator 5.024 (/usr/bin/verilator)              FOUND [recommended]
  [2] iverilog 12.0 (/usr/bin/iverilog)                  FOUND
  [3] vcs V-2023.12-SP1 (/eda/synopsys/vcs/.../bin/vcs) FOUND
  Use which? (1/2/3/all/skip):

synthesis:
  [1] yosys 0.40 (/usr/bin/yosys)                       FOUND [recommended]
  Use? (y/n):

lint:
  [1] verilator 5.024 (/usr/bin/verilator)               FOUND [recommended]
  [2] slang 6.0 (/usr/bin/slang)                         FOUND
  Use which? (1/2/both/skip):

cdc_rdc:
  No open-source tools available for this capability.
  [1] spyglass V-2023.12-SP2                             AVAILABLE_VIA_MODULE
  → To use, first run: module load spyglass/V-2023.12-SP2
  Activate? (y/n):

dft:
  No open-source tools available for this capability.
  [1] tessent 2025.3-p1                                  AVAILABLE_VIA_MODULE
  → To use, first run: module load tessent/2025.3-p1
  Activate? (y/n):
```

---

## Missing Tool Notification Strategy

| Situation | Action |
|-----------|--------|
| Not found, open-source alternative exists | Show: "Not detected. Install open-source alternative: `sudo apt install <pkg>` or `pip install <pkg>`" |
| Not found, module available | Show: "Available via module: `<name>/<version>`. Run: `module load <name>/<version>`" |
| Not found, no module, no open-source | Show: "Not detected. No open-source alternative available. Contact EDA admin for commercial license, or verify PATH/module configuration" |
| Found via module but not loaded | Show: "Available but not loaded. Run: `module load <name>/<version>`" |
