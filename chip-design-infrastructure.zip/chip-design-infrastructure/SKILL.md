---
name: chip-design-infrastructure
description: Use when setting up or auditing a digital chip design environment, detecting available EDA tools, or preparing tool configuration for downstream chip design skills. Trigger even when the user only mentions workstation setup, tool availability, missing tools, or EDA environment readiness.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# chip-design-infrastructure: EDA Environment Detection & Configuration

## Open-Source First Philosophy

This skill and all downstream chip-design skills follow an **open-source first** strategy:

1. **Detection order**: open-source tool commands are checked before commercial ones
2. **Presentation order**: open-source candidates are listed first in every capability group
3. **Recommendation**: when both open-source and commercial tools are detected, open-source is presented as the recommended default (user still chooses)
4. **No-license fallback**: if no commercial license is available, an open-source-only flow is fully supported for capabilities that have mature open-source tools
5. **Honest gaps**: capabilities with no mature open-source alternative (CDC/RDC, DFT, IR/EM) are clearly marked — do not pretend open-source coverage exists where it does not

---

## Use Mode

This skill supports two modes:

**Full environment setup:**
- Follow the 2-stage flow: tool discovery → environment validation
- Detects all available EDA tools, presents findings to user, lets user confirm each tool
- Writes `tool-config.json` for downstream skills to consume

**Single capability check:**
- Any downstream skill can independently detect tools for its own capabilities
- This skill is a convenience entry point, not a prerequisite

**Critical constraint:**
- Every detected tool must be confirmed by the user before it is recorded as active
- Never auto-select any tool, even if only one candidate is found

---

## Capability-Tool Mapping

See [references/infrastructure-rules.md](references/infrastructure-rules.md) for the full Capability-Tool Mapping tables covering 15 capability categories.

---

## Stage Workflow

### Stage 1: tool_discovery

Detect all available EDA tools and present findings to user for confirmation.

**Detection Rules (must execute in this exact order, do not skip any step):**

1. **Step 1 — Collect module avail**: run `module avail 2>&1`, parse all `<name>/<version>` entries, store as `available_modules` list
2. **Step 2 — PATH detection (open-source first)**: for every candidate command in the Capability-Tool Mapping, run `which <command>` — **detect open-source candidates before commercial ones within each capability**:
   - Found → record as `FOUND` with path; run `<command> --version` or equivalent for version
   - Not found → continue to Step 3
3. **Step 3 — Cross-reference against modules**: for every candidate NOT found in PATH, look up its module patterns in the Module-to-Tool Mapping Table below; if any pattern matches an entry in `available_modules`:
   - Record as `AVAILABLE_VIA_MODULE` with module name and version
   - Show user: "Available via module: `module load <name>/<version>`"
4. **Step 4 — Mark remaining**: candidates not found in PATH and not in module avail → record as `NOT_FOUND`

**Critical**: do NOT report a tool as `NOT_FOUND` without first checking Step 3. Module-available tools are valid candidates and must be presented to the user.

**Module-to-Tool Mapping Table:**

See [references/infrastructure-rules.md](references/infrastructure-rules.md) for the Module-to-Tool Mapping Table.

**Output Required:**
- `tool-status.json` — all detected tools with status, path, version, module info

---

### Stage 2: environment_validation

Present all findings to user and let user confirm tool selection per capability.

**Interaction Rules:**

1. Group detected tools by capability
2. For each capability, list all detected tools (FOUND + AVAILABLE_VIA_MODULE), **open-source candidates listed first with `[recommended]` tag**
3. **Every tool must be confirmed by the user**, regardless of how many candidates exist:
   - Multiple candidates → ask user to choose which one(s) to use; open-source shown first
   - Single candidate → ask user to confirm whether to use it
   - Zero candidates → inform user, suggest `module load` command if module available, or suggest installing the open-source alternative
4. User may select multiple tools for one capability (e.g., both Verilator and VCS for simulation)
5. User may skip a capability entirely
6. After user confirms all selections, write `tool-config.json`

**Presentation Format:**

Present tools grouped by capability, open-source first with `[recommended]` tag. See [references/infrastructure-rules.md](references/infrastructure-rules.md) for format example.

**Missing Tool Notification Strategy:**

See [references/infrastructure-rules.md](references/infrastructure-rules.md) for missing tool notification strategy.

**Output Required:**
- `tool-config.json` — user-confirmed tool selections
- Summary of missing capabilities with remediation guidance

---

## tool-config.json Schema

```json
{
  "generated_by": "chip-design-infrastructure",
  "generated_at": "<ISO-8601 timestamp>",
  "open_source_first": true,
  "capabilities": {
    "simulation": [
      {"tool": "verilator", "path": "/usr/bin/verilator", "version": "5.024", "type": "open-source"}
    ],
    "synthesis": [
      {"tool": "yosys", "path": "/usr/bin/yosys", "version": "0.40", "type": "open-source"}
    ],
    "sta": [
      {"tool": "sta", "path": "/usr/bin/sta", "version": "2.6.0", "type": "open-source"}
    ],
    "formal_fpv": [
      {"tool": "sby", "path": "/usr/bin/sby", "version": "0.42", "type": "open-source"}
    ],
    "formal_equiv": [
      {"tool": "yosys", "path": "/usr/bin/yosys", "version": "0.40", "type": "open-source"}
    ],
    "cdc": [],
    "...": "..."
  },
  "not_configured": ["cdc", "dft"],
  "user_actions": [
    "cdc: no open-source alternative — contact EDA admin for SpyGlass or JasperGold license",
    "dft: no open-source alternative — contact EDA admin for Tessent or TetraMAX license"
  ]
}
```

- `capabilities.<name>` is an array: empty means user skipped or no tool found; may contain multiple tools if user selected more than one
- `type` field records whether a tool is `"open-source"` or `"commercial"`
- `not_configured` lists capabilities with no confirmed tool
- `user_actions` lists suggested commands for missing capabilities

---

## Sign-off

Infrastructure setup is complete when:

- `tool-status.json` written (full detection results)
- `tool-config.json` written (user-confirmed selections)
- All user selections confirmed interactively (no auto-selections)
- Missing capability remediation guidance printed for any gaps

There are no hard gates on which specific tools must be present. The user decides what they need.

---

## Loop-Back Rules

- Module system not found → proceed without module detection (WARN)
- User declines all tools for a capability → record empty, continue (downstream skill will re-prompt if needed)
- `tool-config.json` already exists → ask user: re-detect all, or keep existing and only fill gaps

---

## Downstream Skill Integration

Other skills do NOT depend on this skill running first. Each skill independently:

1. Reads `tool-config.json` if it exists
2. Checks whether its required capabilities are configured
3. If not → detects only the tools it needs (open-source first), asks user, appends to `tool-config.json`

See each skill's "Required Capabilities" section for details.

---

## Memory Usage

At session start, if `references/knowledge.md` exists and is non-empty, read it for prior tool quirks and known environment issues. Use this to inform detection decisions.

---

## References

- [references/infrastructure-rules.md](references/infrastructure-rules.md) — detection rules, module mapping, tool-config schema
- [references/knowledge.md](references/knowledge.md) — prior failure patterns and tool quirks
- [references/memory-keeper.md](references/memory-keeper.md) — experience distillation workflow
