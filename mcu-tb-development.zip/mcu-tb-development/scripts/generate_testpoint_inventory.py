import json
import sys


def main() -> int:
    modules = sys.argv[1:] or ["gpio", "uart", "timer"]
    testpoints = []
    for index, module in enumerate(modules, start=1):
        testpoints.append(
            {
                "id": f"TP{index:02d}",
                "module": module,
                "type": "basic",
                "description": f"{module} primary behavior",
            }
        )
    json.dump({"testpoints": testpoints}, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
