## Inputs and assumptions

- MCU peripheral bus summary
- GPIO, UART, timer scenario list
- basic reset and interrupt intent

## Testcase groups

- smoke access
- reset and recovery
- interrupt behavior
- peripheral boundary behavior

## Sequence layering

- bus primitive sequences
- peripheral operation sequences
- cross-peripheral scenario wrappers

## Configuration variation coverage

- UART baud and framing variations
- timer mode variations
- GPIO direction and interrupt mode variations

## First implementation batch

1. smoke access
2. reset and recovery
3. one interrupt path per major peripheral
