## Testpoint inventory summary

- `TP01` GPIO direction register programming
- `TP02` GPIO interrupt clear behavior
- `TP03` UART transmit and receive smoke path
- `TP04` UART framing-error recovery
- `TP05` timer rollover interrupt generation

## Notes

- start from one smoke, one interrupt, and one boundary point per major peripheral
- keep IDs stable so later regression and coverage stages can refer back to them
