# Testcase Plan: [Design Name]

## Inputs and assumptions

State the spec version used, which peripherals are covered, and any assumptions about DUT readiness. List open questions that may affect test coverage.

## Testcase groups

| Group | Peripheral | Examples | Priority | Seed count |
|-------|-----------|----------|----------|------------|
| Register access | GPIO | Reset value check, R/W, RO | P1 | 1 |
| ... | ... | ... | ... | ... |

Priority levels: **P1** (must pass for smoke), **P2** (nightly regression), **P3** (weekly/stress).

## Sequence layering

Describe the sequence hierarchy:
- **Base layer**: Single-transaction primitives (read, write, poll)
- **Protocol layer**: Multi-transaction sequences (write-then-readback, interrupt trigger-and-clear)
- **Scenario layer**: Cross-peripheral interactions (timer triggers UART, GPIO interrupt during DMA)

## Configuration variation coverage

List register/mode bits that change DUT behavior and must be varied across tests. For each, note whether it is covered by parameterized tests or needs dedicated testcases.

## First implementation batch

List the specific testcases to implement first (P1 smoke set). For each:
- Test name
- What it verifies (one sentence)
- Expected pass criteria
