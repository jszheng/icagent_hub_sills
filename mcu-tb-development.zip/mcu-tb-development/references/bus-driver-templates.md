# Bus Driver Templates

Task-based bus read/write drivers for directed testbenches.

## AHB-Lite Driver

```systemverilog
task ahb_write(input [31:0] addr, input [31:0] data);
  // Address phase
  @(posedge HCLK);
  HSEL   <= 1'b1;
  HTRANS <= 2'b10;  // NONSEQ
  HWRITE <= 1'b1;
  HADDR  <= addr;
  HSIZE  <= 3'b010; // 32-bit
  // Data phase — HSEL must stay asserted until HREADY
  @(posedge HCLK);
  HWDATA <= data;
  HTRANS <= 2'b00;  // IDLE for next beat
  // Wait for slave to accept
  wait(HREADY);
  @(posedge HCLK);
  // Deassert after transfer completes
  HSEL   <= 1'b0;
endtask

task ahb_read(input [31:0] addr, output [31:0] data);
  // Address phase
  @(posedge HCLK);
  HSEL   <= 1'b1;
  HTRANS <= 2'b10;  // NONSEQ
  HWRITE <= 1'b0;
  HADDR  <= addr;
  // Data phase — HSEL stays asserted
  @(posedge HCLK);
  HTRANS <= 2'b00;  // IDLE for next beat
  // Wait for slave to respond
  wait(HREADY);
  data = HRDATA;
  @(posedge HCLK);
  // Deassert after transfer completes
  HSEL   <= 1'b0;
endtask
```

## APB Driver

```systemverilog
task apb_write(input [11:0] addr, input [31:0] data);
  // Setup phase
  @(posedge PCLK);
  PSEL    <= 1'b1;
  PWRITE  <= 1'b1;
  PADDR   <= addr;
  PWDATA  <= data;
  // Access phase
  @(posedge PCLK);
  PENABLE <= 1'b1;
  // Wait for slave ready
  @(posedge PCLK);
  wait(PREADY);
  // Deassert
  PSEL    <= 1'b0;
  PENABLE <= 1'b0;
endtask

task apb_read(input [11:0] addr, output [31:0] data);
  // Setup phase
  @(posedge PCLK);
  PSEL    <= 1'b1;
  PWRITE  <= 1'b0;
  PADDR   <= addr;
  // Access phase
  @(posedge PCLK);
  PENABLE <= 1'b1;
  // Wait for slave ready, then sample read data
  @(posedge PCLK);
  wait(PREADY);
  data = PRDATA;
  // Deassert
  PSEL    <= 1'b0;
  PENABLE <= 1'b0;
endtask
```

## Usage in tests

```systemverilog
initial begin
  @(posedge rst_n);
  repeat(5) @(posedge clk);

  // Write GPIO direction register
  apb_write(12'h000, 32'hFF);
  // Read back
  apb_read(12'h000, rdata);
  if (rdata !== 32'hFF) $display("TEST_FAILED: GPIO DIR readback mismatch");
end
```

## Notes

- Drivers use non-blocking assignments (`<=`) for control signals within clocked tasks
- AHB-Lite: HSEL must remain asserted during the data phase until HREADY — deassert only after the transfer completes
- Wait for HREADY/PREADY before sampling read data
- These are for directed tests. For UVM, wrap in a driver class (see uvm-structure-guide.md)
