# Incremental Fix Rules — Testbench

## Scope Control

| Diagnosis | Fix scope | Cascade |
|---|---|---|
| Wrong expected value in checker | Fix checker file only | Recompile + re-sim |
| Missing checker for a register | Add check in existing checker file | Recompile + re-sim |
| Wrong stimulus timing | Fix test file only | Recompile + re-sim |
| Missing test for a peripheral | Add new test file + update filelist | Recompile |
| False pass (test passed but shouldn't) | Add missing assertion/checker | Recompile + re-sim |
| TB compile error | Fix syntax in affected file | Recompile |

## Key Rule

TB fixes NEVER cascade to synthesis, PnR, or signoff. TB is independent of implementation.

## RTL vs TB Issue

If triage says the failure is in RTL (not TB), do NOT change the TB to mask the RTL bug. Route to `mcu-rtl-development` instead.

Ground truth for expected values is always the **spec**, not the RTL.

## Backup

Same as RTL: backup modified files to `backup/<timestamp>/`.
