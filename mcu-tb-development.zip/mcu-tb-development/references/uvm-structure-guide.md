# UVM Structure Guide

UVM infrastructure hierarchy for MCU SoC verification.

## Directory Layout

```
tb/uvm/
  env/
    mcu_env.sv            — top-level environment
    mcu_env_pkg.sv        — package with all imports
  agents/
    ahb_agent/
      ahb_agent.sv        — agent (driver + monitor + sequencer)
      ahb_driver.sv       — drives AHB transactions
      ahb_monitor.sv      — observes AHB bus
      ahb_sequencer.sv    — sequence item routing
      ahb_seq_item.sv     — transaction object
    apb_agent/
      apb_agent.sv
      apb_driver.sv
      apb_monitor.sv
      apb_sequencer.sv
      apb_seq_item.sv
  sequences/
    base_seq.sv           — base sequence class
    reg_access_seq.sv     — register read/write sequences
    peripheral_seq.sv     — peripheral-specific sequences
  scoreboard/
    mcu_scoreboard.sv     — spec-based reference checker
  tests/
    base_test.sv          — base test (configures env)
    reg_test.sv           — register access test
    func_test.sv          — functional test
    stress_test.sv        — stress/corner case test
```

## Key Classes

### Agent

```systemverilog
class ahb_agent extends uvm_agent;
  ahb_driver    drv;
  ahb_monitor   mon;
  ahb_sequencer sqr;

  function void build_phase(uvm_phase phase);
    drv = ahb_driver::type_id::create("drv", this);
    mon = ahb_monitor::type_id::create("mon", this);
    sqr = ahb_sequencer::type_id::create("sqr", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    drv.seq_item_port.connect(sqr.seq_item_export);
  endfunction
endclass
```

### Scoreboard

```systemverilog
class mcu_scoreboard extends uvm_scoreboard;
  uvm_analysis_imp #(ahb_seq_item, mcu_scoreboard) ahb_imp;

  // Expected values from spec (not RTL)
  int expected_regs[bit[31:0]];

  function void write(ahb_seq_item t);
    if (t.write)
      expected_regs[t.addr] = t.data;
    else begin
      if (expected_regs.exists(t.addr) && t.data !== expected_regs[t.addr])
        `uvm_error("SCB", $sformatf("Mismatch at 0x%08x: exp=0x%08x got=0x%08x",
                   t.addr, expected_regs[t.addr], t.data))
    end
  endfunction
endclass
```

### Test

```systemverilog
class reg_test extends base_test;
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // Configure env for register test
  endfunction

  task run_phase(uvm_phase phase);
    reg_access_seq seq = reg_access_seq::type_id::create("seq");
    phase.raise_objection(this);
    seq.start(env.ahb_agt.sqr);
    phase.drop_objection(this);
  endtask
endclass
```

## Build Order

When generating UVM infrastructure, create in this order:
1. Sequence items (data objects)
2. Drivers and monitors (BFM logic)
3. Agents (bundle driver + monitor + sequencer)
4. Scoreboard (spec-based reference model)
5. Environment (instantiate agents + scoreboard)
6. Sequences (stimulus generation)
7. Tests (configure env + run sequences)

## MCU-Specific Notes

- AHB agent drives CPU master port
- APB agents per peripheral (GPIO, UART, Timer, etc.)
- Scoreboard register model built from spec register map, not RTL
- Interrupt monitoring via dedicated monitor on IRQ signals
- Clock/reset agent for controlled reset injection
