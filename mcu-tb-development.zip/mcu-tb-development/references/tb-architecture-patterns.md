# TB Architecture Patterns

## Directed Test (Simple, Non-UVM)

```
tb_top.sv
  ├── clock/reset generation
  ├── DUT instantiation
  ├── bus_driver (task-based AHB/APB read/write)
  ├── checker (spec-based expected values)
  └── test sequence (stimulus + check calls)
```

Best for: early bring-up, register-level verification, quick iteration.

## UVM Architecture

```
uvm_env
  ├── ahb_agent (driver + monitor + sequencer)
  ├── apb_agent (per peripheral)
  ├── scoreboard (spec-based reference model)
  ├── coverage_collector
  └── virtual_sequencer

uvm_test extends uvm_test
  └── configures env, runs sequence
```

Best for: full-chip verification, coverage-driven closure, regression.

## Hybrid (Recommended for MCU)

Start with directed tests for bring-up, layer UVM on top for regression:

1. Phase 1: Directed TB with task-based drivers → quick compile-sim loop
2. Phase 2: Add UVM agents wrapping the same interface → reuse driver logic
3. Phase 3: Coverage-driven sequences → regression closure

## TB Top Template Structure

```systemverilog
module tb_top;
  // Clock generation
  reg clk;
  initial clk = 0;
  always #(CLK_PERIOD/2) clk = ~clk;

  // Reset
  reg rst_n;
  initial begin
    rst_n = 0;
    #(CLK_PERIOD * RESET_CYCLES);
    @(posedge clk);
    rst_n = 1;
  end

  // DUT
  <top_module> u_dut (
    .clk(clk),
    .rst_n(rst_n),
    ...
  );

  // Waveform dump
  initial begin
    $fsdbDumpfile("wave.fsdb");
    $fsdbDumpvars(0, tb_top);
  end

  // Test
  initial begin
    @(posedge rst_n);
    repeat(5) @(posedge clk);
    run_test();
  end
endmodule
```
