# Checker Patterns

## Register Read-Back Checker

Verifies that written values can be read back correctly.

```systemverilog
task check_reg_rw(input [31:0] addr, input [31:0] wdata, input string name);
  bus_write(addr, wdata);
  bus_read(addr, rdata);
  if (rdata !== wdata) begin
    $display("TEST_FAILED: %s write 0x%08x read 0x%08x", name, wdata, rdata);
    fail_count++;
  end
endtask
```

## Reset Value Checker

Verifies all registers have spec-defined reset values after reset.

```systemverilog
task check_reset_values();
  // For each register in spec:
  bus_read(ADDR_REG_X, rdata);
  assert(rdata == RESET_VALUE_X) else
    $display("TEST_FAILED: REG_X reset value mismatch: got 0x%08x, expected 0x%08x", rdata, RESET_VALUE_X);
endtask
```

## Interrupt Checker

Verifies interrupt behavior matches spec conditions.

```systemverilog
task check_interrupt(input string name, input trigger_action, input expected_irq);
  trigger_action();
  @(posedge clk);
  if (irq !== expected_irq)
    $display("TEST_FAILED: %s interrupt expected=%0b actual=%0b", name, expected_irq, irq);
endtask
```

## Timeout Protection

Every test must have a timeout:

```systemverilog
initial begin
  #(CLK_PERIOD * MAX_CYCLES);
  $display("TEST_TIMEOUT: exceeded %0d cycles", MAX_CYCLES);
  $finish;
end
```

## Pass/Fail Reporting

Every test must end with an explicit verdict:

```systemverilog
initial begin
  run_all_checks();
  if (fail_count == 0)
    $display("TEST_PASSED");
  else
    $display("TEST_FAILED: %0d checks failed", fail_count);
  $finish;
end
```
