---
name: mcu-tb-development
description: Plan testcase structure, generate testbench and UVM verification infrastructure, and apply incremental fixes for an MCU SoC design. Covers test planning (grouping, priorities, sequence hierarchy), TB code generation (directed tests, UVM agents, checkers), and targeted TB fixes from verification triage. Use when verification goals need to be turned into executable tests and testbench code.
license: PolyForm-Noncommercial-1.0.0
metadata:
  author: 中科麒芯
  organization: 中科麒芯智能技术（南京）有限公司
  homepage: https://www.ickylin.com/
  contact: info@ickylin.com
---

# MCU TB Development

Use this skill for all testbench-related engineering: planning test structure, generating TB code from spec, producing UVM infrastructure, and applying incremental fixes based on verification feedback.

## Boundaries

The following tasks are out of scope. Inform the user and, if the corresponding skill exists in the project, suggest routing there.

- Do **not** compile or simulate. (Companion skill: `mcu-compile-sim-run`)
- Do **not** generate RTL. (Companion skill: `mcu-rtl-development`)
- Do **not** diagnose failures. (Companion skill: `mcu-verification-triage`)

Testbench expected values are derived from the **spec**, not from RTL implementation. This prevents false positives.

## Three Modes

### Test Planning

Triggered when: verification goals exist but testcase structure is vague or fragmented. Produces test plan and test list.

### Full TB Generation

Triggered when: RTL exists, spec is stable, and no testbench files exist yet. Generates TB code based on test plan.

### Incremental Fix

Triggered when: a diagnostic result identifies testbench issues (wrong expected values, missing checkers, incorrect stimulus).

## Good Outcome

Produce:

- testcase plan with grouping, priorities, sequence layers
- test list JSON for regression (`doc/test_list.json`)
- testbench top with clock gen, reset, DUT instantiation
- self-checking infrastructure (checkers/scoreboard)
- directed test cases and/or UVM infrastructure
- simulation filelist (`sim/filelist_sim.f`)
- change manifest (for incremental fix mode)

## Input Artifacts

| Artifact | Source | Required |
|----------|--------|----------|
| Specification (spec.md) | User-provided or from spec planning stage | Yes |
| RTL filelist (filelist.f) | User-provided or from RTL development stage | Yes (for TB gen) |
| `eda_env.json` | From EDA env setup if available | Yes (waveform format) |
| Diagnostic result | User-provided (error log) or from verification triage | Yes (incremental fix) |

## Output Artifacts

| Artifact | Path | Description |
|----------|------|-------------|
| Test plan | `doc/test_plan.md` | Structured testcase plan |
| Test list | `doc/test_list.json` | Machine-readable test list for regression |
| TB top | `tb/tb_<top>.sv` | Testbench top module |
| Checkers | `tb/checker_*.sv` | Self-checking components |
| Directed tests | `tb/test_*.sv` | Individual test cases |
| UVM infrastructure | `tb/uvm_*/**/*.sv` | Agents, sequences, env (if UVM) |
| Sim filelist | `sim/filelist_sim.f` | RTL + TB combined filelist |
| Change manifest | `doc/tb_changes.json` | Files created/modified |

## Input Validation

### From spec.md

| Required section | What to check | Used for |
|---|---|---|
| Peripheral register map | Per-register: name, offset, width, reset value, access type | Checker expected values |
| Peripheral behavior | Functional description per peripheral | Directed test stimulus |
| Interrupt conditions | Per-IRQ: trigger condition, clear mechanism | Interrupt test generation |
| Memory map | Base address per slave | Bus driver address targets |
| Clock domains | Clock name, frequency | TB clock generation period |
| Reset behavior | Reset polarity, min hold cycles | TB reset sequence |

### From eda_env.json

| Required field | What to check | Used for |
|---|---|---|
| `selected_tools.simulator` | Not null | Waveform dump format selection |
| `selected_tools.waveform` | Name or null | Dump system call choice |

### From diagnostic result (incremental fix)

| Required field | What to check | Used for |
|---|---|---|
| `source` | Must be "tb". If "rtl", reject — this is an RTL issue, not a TB issue. Suggest the `mcu-rtl-development` skill if available, otherwise inform the user. | Confirming TB issue |
| `file` | Path to failing TB file | Locating file to fix |
| `error_type` | One of: wrong_expected, missing_checker, wrong_timing, false_pass | Fix strategy |
| `message` | Error description | Understanding the issue |
| `cascade_hint` | Cascade scope | Change manifest |

If `source` is not "tb", do not proceed.

## Workflow — Test Planning

### Step 1: Read spec for testable behaviors

Extract per-peripheral register operations, functional behavior, interrupt conditions, bus protocol requirements.

### Step 2: Group testcases by area

| Group | Examples | Priority |
|-------|---------|----------|
| Register access | Reset value check, R/W, RO, W1C per peripheral | P1 |
| Peripheral function | GPIO toggle, UART TX/RX, Timer overflow | P1 |
| Interrupt | Trigger, mask, clear, nesting | P1 |
| Bus protocol | Back-to-back, error inject, address boundary | P2 |
| Cross-peripheral | Interrupt during DMA, timer-triggered UART | P2 |
| Stress | Simultaneous access, rapid reset | P3 |

### Step 3: Define sequence layers and regression tiers

Sequence layers: base → protocol → scenario → stress.

Regression tiers: sanity (P1 basics), nightly (all P1+P2), weekly (all).

### Step 4: Write test list JSON

Write `doc/test_list.json` with per-test: name, group, peripheral, priority, seeds, uvm_test_class. This is consumed by `mcu-compile-sim-run` regression mode.

## Workflow — Full TB Generation

### Step 1: Read spec (NOT RTL) for expected values

### Step 2: Generate TB infrastructure

- TB top: clock gen, reset sequence, DUT instantiation, waveform dump
- Bus driver: AHB/APB read/write tasks
- Checkers: spec-based expected behavior per peripheral
- See [bus-driver-templates.md](references/bus-driver-templates.md) and [checker-patterns.md](references/checker-patterns.md)

### Step 3: Generate directed tests

Per peripheral: basic R/W test, functional test, interrupt test.

Every test must have explicit `TEST_PASSED`/`TEST_FAILED` reporting and timeout protection.

### Step 4: Generate UVM infrastructure (if required)

Follow [uvm-structure-guide.md](references/uvm-structure-guide.md): agents, sequences, scoreboard, tests.

### Step 5: Generate sim filelist

```
-f rtl/filelist.f
tb/tb_<top>.sv
tb/checker_*.sv
tb/test_*.sv
```

## Workflow — Incremental Fix

### Step 1: Validate diagnostic source is "tb"

### Step 2: Read only the affected TB file

### Step 3: Apply targeted fix (wrong expected → correct from spec; missing checker → add; wrong timing → fix delay)

### Step 4: Update filelist if new files added

### Step 5: Write change manifest (TB changes only cascade to recompile)

## Test Planning Rules

### Scenario priority

- Start with reset, smoke access, and primary bus reachability
- Next cover interrupt, error, and boundary behavior
- Delay wide stress matrices until the base scenario set is trustworthy

### Sequence layering

- Keep transaction primitives separate from scenario orchestration
- Avoid one testcase per tiny register toggle when one parameterized sequence can cover the space
- Reserve deep randomization for cases where the checker model is already mature

### Configuration variation

- Track which register or mode bits actually change behavior
- Group mode variants that reuse the same checker logic
- Mark combinations that can wait for regression rather than first-wave testcase implementation

## TB Coding Conventions

- SystemVerilog for all TB code
- Expected values from spec, not from RTL
- Explicit pass/fail: `$display("TEST_PASSED")` or `$display("TEST_FAILED: reason")`
- Timeout protection in every test
- No hardcoded magic numbers — use parameters
- All tests independently runnable

## Bundled References

- [tb-architecture-patterns.md](references/tb-architecture-patterns.md) — TB structure for different approaches
- [checker-patterns.md](references/checker-patterns.md) — spec-based checker templates
- [bus-driver-templates.md](references/bus-driver-templates.md) — AHB/APB driver task patterns
- [uvm-structure-guide.md](references/uvm-structure-guide.md) — UVM agent/env/test hierarchy
- [incremental-fix-rules.md](references/incremental-fix-rules.md) — TB fix scoping
## Bundled Assets

- [testcase-plan-template.md](assets/testcase-plan-template.md) — test plan output format
- [example-testcase-plan.md](assets/example-testcase-plan.md) — sample test plan output
- [sample-testcase-matrix.json](assets/sample-testcase-matrix.json) — structured testcase matrix example
- [example-testpoint-inventory.md](assets/example-testpoint-inventory.md) — sample testpoint inventory
- [testpoint-inventory-template.json](assets/testpoint-inventory-template.json) — testpoint inventory schema

## Bundled Scripts

- [generate_testpoint_inventory.py](scripts/generate_testpoint_inventory.py) — testpoint inventory generator

## Completion Gate

Test planning: test plan written, test_list.json produced, regression tiers defined.

Full TB gen: TB compiles with DUT, directed tests exist, self-checking in place, filelist complete.

Incremental fix: diagnosed issue fixed in specific file(s), no unrelated changes, manifest updated.

## Decision Rules

- Always derive expected values from spec, never from RTL.
- In incremental mode, never modify tests unrelated to the diagnosis.
- If diagnosis indicates RTL bug, do NOT fix TB to match the bug — inform the user this is an RTL issue.
- Back up modified files before overwriting.
